# System Architecture

AI-Powered Dataset Analysis Assistant: design document for the B.Tech training project.

> Diagrams use [Mermaid](https://mermaid.js.org/). They render automatically on GitHub and in the
> VS Code Markdown preview. For slides, paste a diagram into <https://mermaid.live> and export a PNG/SVG.

---

## 1. One-paragraph summary

The user uploads a CSV/Excel file, which is validated and loaded into a Pandas DataFrame **in memory**.
When the user asks a question, a **Large Language Model (LLM)** converts it into a small JSON
**analysis plan**. Python **validates** that plan against the real columns and a whitelist of
operations, **executes** it with Pandas, and builds a Plotly chart. The **verified result** (not the
dataset) is sent back to the LLM, which writes a short explanation. If no AI is configured, a
rule-based matcher produces the plan instead, so the app always works.

---

## 2. High-level architecture

```mermaid
flowchart TB
    U([User in browser])

    subgraph UI["Presentation layer · Streamlit (components/)"]
        H[Home]
        D[Dataset]
        C[AI Chat]
        V[Visualizations]
        I[Insights & Reports]
        S[(Session state<br/>in memory)]
    end

    subgraph CORE["Application layer · services/"]
        L[dataset_loader<br/>validate & parse]
        CE[chat_engine<br/>Analysis Controller]
        QP[query_planner<br/>validate & execute plan]
        RP[rule_planner<br/>offline planner]
        AE[analysis_engine<br/>Pandas calculations]
        CG[chart_generator<br/>Plotly]
        IN[insights<br/>statistics]
        DC[data_cleaner<br/>opt-in cleaning]
        RG[report_generator<br/>HTML]
        AI[ai_service<br/>provider interface]
    end

    subgraph EXT["External · optional"]
        CL[Anthropic Claude API]
        GM[Google Gemini API]
    end

    U --> H & D & C & V & I
    H & D --> L --> S
    D --> DC --> S
    C --> CE
    CE --> AI
    CE --> RP
    CE --> QP --> AE
    QP --> CG
    V --> CG
    I --> IN --> AE
    I --> RG
    I --> AI
    AI -.HTTPS.-> CL
    AI -.HTTPS.-> GM
```

### Layers

| Layer | Folder | Rule |
|---|---|---|
| Presentation | `components/` | Only Streamlit code: layout, widgets, session state. No calculations. |
| Application | `services/` | All logic. **No Streamlit imports**, so every function is unit-testable. |
| External | (network) | The LLM is optional and only ever sees plans, schemas and verified results. |

---

## 3. Modules and responsibilities

| Module | Responsibility | Key functions |
|---|---|---|
| `app.py` | Entry point; registers the five pages | `st.navigation` |
| `config.py` | All limits and settings, read from `.env` | `MAX_FILE_MB`, `AI_PROVIDER`… |
| `services/dataset_loader.py` | File-type/size/empty checks, CSV delimiter and encoding detection, Excel reading, header clean-up, numbers-as-text and date detection. Every change is recorded in `notes`. | `load_dataset()` |
| `services/analysis_engine.py` | **The only place numbers are calculated.** Overview, column info, statistics, filters, group-by, time trends, correlation, outliers. | `group_aggregate()`, `filter_rows()`, `time_trend()`… |
| `services/query_planner.py` | Defines the plan **JSON Schema**, validates plans, executes them, and produces `AnalysisResult` (summary + table + chart). Also renders equivalent Pandas code for transparency. | `validate_plan()`, `execute_plan()`, `plan_to_pandas()` |
| `services/rule_planner.py` | Keyword rules that build a plan without AI (offline mode). | `plan_from_rules()` |
| `services/ai_service.py` | `LLMProvider` interface with `ClaudeProvider` and `GeminiProvider`; prompts; schema description. | `plan_question()`, `explain_result()`, `write_insights()` |
| `services/chat_engine.py` | **Analysis Controller**: plan → check → compute → explain, with error handling at each step. | `answer_question()` |
| `services/chart_generator.py` | Plotly charts with a shared, colour-blind-safe style. | `bar_chart()`, `line_chart()`… |
| `services/insights.py` | Deterministic findings (top/bottom groups, trend, correlations, outliers, quality). | `compute_findings()` |
| `services/data_cleaner.py` | Suggests cleaning steps with their impact; applies only the selected ones. | `suggest_cleaning()`, `apply_cleaning()` |
| `services/report_generator.py` | Self-contained, HTML-escaped report. | `build_html_report()` |

---

## 4. How a question is answered

```mermaid
sequenceDiagram
    actor User
    participant UI as Chat page
    participant CE as chat_engine
    participant LLM as LLM (Claude/Gemini)
    participant QP as query_planner
    participant PD as Pandas engine

    User->>UI: "Which product has the highest revenue?"
    UI->>CE: answer_question(question, df)
    CE->>LLM: schema (column names + types) + question
    LLM-->>CE: JSON plan {operation: group_aggregate, group_by: Product, value_column: Revenue, aggregation: sum}
    CE->>QP: validate_plan(plan, df)
    alt invalid (unknown column, wrong type, unsupported)
        QP-->>CE: PlanError
        CE-->>UI: clarifying message (no numbers shown)
    else valid
        QP->>PD: df.groupby("Product")["Revenue"].sum()
        PD-->>QP: Laptop 1,750,000 · Mobile 825,000 · Tablet 240,000
        QP-->>CE: AnalysisResult (summary + table + chart)
        CE->>LLM: question + verified result (≤ 20 rows)
        LLM-->>CE: "Laptop generated the highest revenue, 1,750,000…"
        CE-->>UI: explanation + chart + table + Pandas code
    end
    UI-->>User: answer
```

Without an API key, the first LLM call is replaced by `rule_planner.plan_from_rules()` and the
second by the deterministic `AnalysisResult.summary`. Answers are labelled *Built-in rule matcher*.

### The analysis plan

The LLM must reply with JSON matching `PLAN_SCHEMA` (enforced with the provider's structured-output
feature where available, and always re-validated in Python):

```json
{
  "operation": "group_aggregate",
  "column": null, "group_by": "Product", "value_column": "Revenue", "date_column": null,
  "aggregation": "sum", "n": 5, "ascending": false, "freq": null,
  "chart_type": "bar", "x": null, "y": null,
  "filters": [{"column": "Region", "operator": "==", "value": "North"}],
  "message": null
}
```

**Supported operations (whitelist):** `dataset_summary`, `column_stats`, `aggregate`,
`group_aggregate`, `sort_rows`, `value_counts`, `count_rows`, `time_trend`, `correlation`,
`outliers`, `missing_values`, `duplicates`, `chart`, plus `clarify` and `unsupported` for questions
that can't or shouldn't be answered.

### Validation rules (`validate_plan`)

| Check | Example rejected |
|---|---|
| Operation must be in the whitelist | `"operation": "exec_python"` |
| Every column must exist (case/space-insensitive match) | `"column": "Profit Margin"` when there is no such column |
| Numeric aggregations need numeric columns | average of `Product` |
| Aggregation, frequency, chart type and filter operator must be from fixed lists | `"aggregation": "DROP TABLE"` |
| `n` is clamped to 1–100 | `"n": 10000` → 100 |
| Time trends need a date column | trend on a dataset without dates |
| Filter values must match the column type | `Revenue > "lots"` |

---

## 5. Data flow and the privacy boundary

```mermaid
flowchart LR
    F[Uploaded file] --> DF[(DataFrame<br/>in memory only)]
    DF --> SCH[Schema description:<br/>column names, types,<br/>numeric ranges,<br/>≤5 example values*]
    DF --> CALC[Pandas result<br/>≤20 rows]
    SCH --> LLM{{LLM API}}
    CALC --> LLM
    DF -. never sent .-x LLM
```

\* Example values can be disabled with `AI_SHARE_SAMPLE_VALUES=false`.

| Data | Stored on disk? | Sent to the AI? |
|---|---|---|
| Uploaded file / full DataFrame | No (memory only, per browser session) | **Never** |
| Column names and types | No | Yes |
| Example values of text columns | No | Optional (default on) |
| Calculated result (≤ 20 rows) | No | Yes, for the explanation |
| API key | Only in your local `.env` | Only to the provider, as authentication |

---

## 6. Session state (per browser tab)

| Key | Contents |
|---|---|
| `df` / `original_df` | Working DataFrame / as-loaded copy (for "Restore original") |
| `filename`, `load_notes`, `cleaning_log` | What was loaded and every change made |
| `messages`, `last_plan` | Chat history; previous plan for follow-up questions |
| `report_charts`, `ai_summary` | Items to include in the report |
| `ai_requests` | Counter enforcing `MAX_AI_REQUESTS_PER_SESSION` |
| `data_version` | Incremented on every data change; cache key for findings |

---

## 7. Error handling

| Where | Failure | What the user sees |
|---|---|---|
| Upload | Wrong type, empty, header-only, malformed CSV, corrupt Excel, too large | Red message naming the problem; previous data stays loaded |
| Planning (AI) | Bad key, rate limit, network, refusal, invalid JSON | Specific, safe message (no secrets, no stack trace) |
| Validation | Unknown column, wrong type, ambiguous | Yellow clarifying message listing valid columns |
| Execution | Filters match no rows | "No rows match…" (nothing invented) |
| Explanation (AI) | Provider fails after calculation | Calculated summary is shown, with a small warning |
| AI budget | Session limit reached | Automatically switches to offline mode |

---

## 8. Design decisions

| Decision | Alternatives considered | Reason |
|---|---|---|
| **LLM produces a JSON plan, not code** | Let the LLM write and `exec` Pandas code | Code execution is a security risk and hard to test. Plans are validated, testable and explainable. |
| **Pandas computes every number** | Send the data to the LLM and ask for the answer | LLMs make arithmetic mistakes and can't hold large datasets; Pandas is exact. |
| **Provider interface (`LLMProvider`)** | Hard-code one SDK | Swap Claude ↔ Gemini with one `.env` change; tests use a fake provider. |
| **Offline rule planner** | Disable chat without AI | The demo works without internet or billing; answers are clearly labelled. |
| **Streamlit** | React + Flask/FastAPI | One language, much less code, ideal for data apps and a student project. |
| **In-memory, no database** | SQLite from day one | Simpler and more private; persistence is a future enhancement. |
| **Opt-in cleaning with a log** | Auto-clean on upload | Users must know exactly how their data was changed. |

---

## 9. Testing strategy

| Test file | Covers |
|---|---|
| `tests/test_dataset_loader.py` | Every validation path, delimiters, header clean-up, type conversion, Excel |
| `tests/test_analysis.py` | Each calculation against hand-computed values; cleaning; findings |
| `tests/test_query_planner.py` | Schema, validation rejections, every operation runs, rule planner mapping |
| `tests/test_ai_service.py` | AI flow with a fake provider: hallucination caught, outages, privacy of prompts, report safety |

Run with `pytest -q`. No network or API key is needed.

---

## 10. Viva / presentation cheat-sheet

**Where exactly is AI used?** In two places: turning the question into a structured plan, and
explaining the verified result in plain English. Optionally also in rewriting findings as a summary.

**How do you stop the AI from making up numbers?** It never calculates. Pandas does. The AI gets the
calculated numbers and is instructed to use only those. The table and chart shown under every answer
come straight from Pandas.

**What if the AI invents a column?** `validate_plan()` checks every column against the DataFrame
and asks the user to clarify. There's a test for exactly this (`test_hallucinated_column_is_caught`).

**Could someone make it run malicious code?** No. There is no `eval`, `exec`, SQL or shell. The
plan can only select from a fixed list of operations with validated parameters.

**What does the AI see of my data?** Column names, types, numeric ranges, a few example category
values (optional), and small calculated results. Never the full file.

**What happens without internet or an API key?** The rule-based planner answers common questions,
and all dashboards, charts, insights and reports keep working.

**Is this machine learning?** It uses a pre-trained LLM for language understanding plus classical
statistics (aggregation, correlation, IQR outliers). No model is trained in this project.
