# User Guide: How to Operate the App

This guide walks through every screen of the AI-Powered Dataset Analysis Assistant.
For installation see the [README](../README.md); for the design see [ARCHITECTURE.md](ARCHITECTURE.md).

---

## Before you start (every time)

Open a terminal in the project folder:

```bash
cd ~/Downloads/ai-dataset-analysis-assistant
```

```bash
./run.sh
```

(`run.sh` uses the project's own Python environment in `~/.venvs/`, creating it on the first run.
Don't run plain `streamlit run app.py` without activating that environment: your system-wide
Streamlit is older, and the app will refuse to start.)

The app opens at **http://localhost:8501**. Keep the terminal open while you use it. `Ctrl+C` stops it.

The **sidebar** (left) is visible on every page and shows:
- the five pages (Home, Dataset, AI Chat, Visualizations, Insights & Reports);
- the **current dataset** (name and size) with *Remove dataset* and an uploader to replace it;
- the **AI status**: *AI on* (with the model name and requests used) or *Offline mode* (with the reason).

---

## Step 1: Home, load a dataset

![Home](screenshots/home.jpg)

Choose one:
- **Upload**: click *Upload* (or drag a file in) and pick a `.csv` or `.xlsx` file up to 50 MB.
- **Sample dataset**: click *Sales*, *Students*, *Employees (Excel)* or *Messy data* to try the app instantly.

If the file has a problem (wrong type, empty, broken), a red message explains what is wrong.

Once loaded, use the buttons *Explore dataset*, *Ask a question* or *View insights*.

> **Tip for your demo:** load **Messy data (CSV)** to show validation at work: blank and duplicate
> headers are renamed, `"1,200"` text becomes the number 1200, and duplicates and missing values are flagged.

---

## Step 2: Dataset, understand your data

![Dataset](screenshots/dataset.jpg)

- **Blue box**: every adjustment made while reading the file (e.g. *"'Order Date' looks like dates; converted"*). Your original file is never changed.
- **Metric tiles**: rows, columns, missing cells, missing %, duplicate rows, and column types.
- **Tabs**:

| Tab | What you see |
|---|---|
| Preview | The first 1,000 rows, plus a *Download current data (CSV)* button |
| Columns | Each column's type, missing count and %, unique values and an example |
| Statistics | Mean, std, min, quartiles, max for numbers; most common value for text |
| Missing values | Table and bar chart of missing values per column |
| Duplicates | Every row involved in duplication |
| Clean data | Optional cleaning (see below) |

### Cleaning (optional)

1. Open **Clean data**. Only the steps that would change something are listed, each with its impact
   (e.g. *Remove duplicate rows: removes 4 rows*).
2. Tick the steps you want and click **Apply selected steps**.
3. A yellow banner then reminds you that you are viewing a cleaned copy. All pages use the cleaned data.
4. **Restore original data** undoes everything.

---

## Step 3: AI Chat, ask questions

![AI Chat](screenshots/chat.jpg)

1. Type a question in the box at the bottom and press Enter, **or** click a suggested question.
   Suggestions are built from your column names, so they always work.
2. Each answer can contain:
   - a short explanation (**bold** numbers are the key results);
   - a **chart**, when it helps;
   - **Result table**: the exact numbers, with *Download as CSV*;
   - **How this was calculated**: the equivalent Pandas code and the validated analysis plan;
   - **Source**: which AI model wrote the text, or *Built-in rule matcher* in offline mode;
   - **Add to report**: puts the chart into your report.
3. **Follow-up questions** work in AI mode: after *"Revenue by product"*, ask *"now as a pie chart"*
   or *"only in the North region"*.
4. **Clear chat** (top right) starts over.

### What kinds of questions work?

| You want… | Ask like this |
|---|---|
| An overview | *Summarize this dataset* |
| One number | *What is the average revenue?* · *Total units sold* · *Highest unit price* |
| To compare groups | *Which product has the highest revenue?* · *Average revenue by region* |
| The top or bottom N | *Top 5 sales reps by revenue* · *Bottom 3 products by units sold* |
| A subset (AI mode) | *Total revenue in the North region* · *Orders with discount above 10%* |
| To count | *How many orders were placed in December?* (AI mode) |
| A trend | *Monthly revenue trend* · *Weekly order count* · *Revenue by quarter* |
| Relationships | *Correlation between numeric columns* · *Scatter of unit price vs revenue* |
| Data quality | *Are there missing values?* · *Find duplicate rows* · *Outliers in revenue* |
| A specific chart | *Pie chart of revenue by category* · *Histogram of customer rating* · *Box plot of revenue* |

**Good habits:**
- Use words close to your column names (*"units sold"* rather than *"volume"*).
- One question at a time. Split multi-step questions.
- If the assistant asks a clarifying question, answer it by asking again more precisely.

**It will not:** predict the future, explain *why* something happened, or use information that
isn't in your file. It tells you so instead of guessing.

### AI mode vs offline mode

| | AI mode (API key set) | Offline mode (no key) |
|---|---|---|
| Understands free-form wording | Yes | Simple phrasings that name a column |
| Filters ("in the North region") | Yes | No |
| Follow-up questions | Yes | No |
| Explanations | Written by the AI from verified numbers | Calculated summary sentence |
| Numbers, tables, charts | Pandas (identical) | Pandas (identical) |
| Cost | Provider's API pricing | Free; nothing leaves your computer |

---

## Step 4: Visualizations, build your own charts

![Visualizations](screenshots/visualizations.jpg)

1. Pick a **chart type**. Each option says what it is good for:

| Chart | Use it for | You choose |
|---|---|---|
| Bar | Comparing categories | Category column, value column, aggregation, top N |
| Line | Change over time | Date column, value, aggregation, day/week/month/quarter/year |
| Pie | Share of a total (few categories) | Like bar; small slices are grouped as "Other" |
| Histogram | Distribution of one number | Numeric column |
| Scatter | Relationship between two numbers | X, Y, optional colour column (top 3 + Other) |
| Box | Spread and outliers | Numeric column, optional split column |
| Heatmap | Correlation between many numeric columns | Columns to include |

2. Hover over the chart for exact values. Use the toolbar at the top right of the chart to zoom or save a PNG.
3. **Add to report** saves the chart for the report; **Download chart (HTML)** saves an interactive copy.

---

## Step 5: Insights & Reports

![Insights](screenshots/insights.jpg)

- **Key findings** (left) are calculated with plain statistics, with no AI involved:
  overview, top and bottom categories, monthly trend, strong correlations, unusual values, data quality.
- **AI summary** (right): click *Generate AI summary* to have the AI rewrite the findings as a short
  report. Its *"Worth investigating"* points are hypotheses, not facts.
- **Report**:
  - The list shows charts you added; *Remove* takes one out.
  - **Download full report (HTML)** saves a single file you can open in any browser, email, or print to PDF
    (browser → *Print* → *Save as PDF*).
  - **Download tables (CSV)**: column information, numeric statistics, missing values, findings.

The report contains: dataset summary, AI summary (if generated), findings, your charts, column
information, statistics, missing values and a list of every change made to the data.

---

## Frequently asked questions

**Is my file uploaded to the internet?**
It is processed only on your computer, in memory. In AI mode, only column names and types, a few
example values (optional) and small calculated results are sent to the AI provider. Never the whole file.

**Why does the sidebar say "Offline mode"?**
No API key is configured, or the session's AI request limit was reached. See README → *Configure the AI provider*.

**The answer seems wrong. What should I do?**
Open *How this was calculated*. If the plan used the wrong column or operation, rephrase the question
using the exact column name. The numbers themselves are always computed by Pandas from the data shown.

**Can I analyse two files together?**
Not yet. Load one at a time. Joining datasets is listed under future enhancements.

**How do I start fresh?**
Click *Remove dataset* in the sidebar, or refresh the browser tab.
