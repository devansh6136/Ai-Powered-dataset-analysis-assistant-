# AI-Powered Dataset Analysis Assistant

**Upload a CSV or Excel file and ask questions about it in plain English.**
The app profiles your data, answers questions with real calculations, draws charts,
finds key insights and exports an analysis report.

> Think of it as "ChatGPT for your spreadsheets", with one important difference:
> **every number is calculated by Python/Pandas from your actual data.** The AI only
> *understands* the question and *explains* the verified result. It never invents numbers.

B.Tech six-month training project · Python · Streamlit · Pandas · Plotly · LLM (Claude / Gemini)

![Home page](docs/screenshots/home.jpg)

---

## Contents

1. [Problem statement](#1-problem-statement)
2. [Objectives](#2-objectives)
3. [Features](#3-features)
4. [Technology stack](#4-technology-stack)
5. [Architecture](#5-architecture)
6. [Project structure](#6-project-structure)
7. [Installation](#7-installation)
8. [Configure the AI provider](#8-configure-the-ai-provider)
9. [Run the application](#9-run-the-application)
10. [How to use it](#10-how-to-use-it)
11. [Example questions](#11-example-questions)
12. [Run the tests](#12-run-the-tests)
13. [Where AI is used (and where it is not)](#13-where-ai-is-used-and-where-it-is-not)
14. [Security and privacy](#14-security-and-privacy)
15. [Known limitations](#15-known-limitations)
16. [Future enhancements](#16-future-enhancements)
17. [Troubleshooting](#17-troubleshooting)

More detail: [System architecture](docs/ARCHITECTURE.md) · [User guide (how to operate)](docs/USER_GUIDE.md)

---

## 1. Problem statement

Many people have useful data in Excel or CSV files: sales records, marks, employee lists.
To answer simple questions such as *"Which product earned the most?"* or *"Which month was worst?"*,
they need Excel formulas, pivot tables, Python, or a data analyst.

Large language models can understand such questions, but **they are unreliable at arithmetic
over thousands of rows** and may "hallucinate" numbers. This project combines the two:
the language model understands the question, and a deterministic Pandas engine calculates the answer.

## 2. Objectives

- Let non-programmers analyse structured data by asking questions in plain English.
- Guarantee that every number shown is calculated from the uploaded data.
- Automatically profile data quality: types, missing values, duplicates, outliers.
- Produce suitable charts and a downloadable report.
- Keep the system safe: no arbitrary code execution, minimal data sent to the AI.
- Keep the codebase simple enough for a student to understand and explain.

## 3. Features

| Area | What it does |
|---|---|
| **Upload & validation** | CSV and XLSX up to 50 MB. Detects empty, header-only, malformed and unsupported files. Detects delimiters (`, ; tab \|`) and text encodings. |
| **Automatic profiling** | Rows, columns, data types, missing values per column, duplicate rows, numeric and categorical statistics. Converts "numbers stored as text" (e.g. `"1,200"`) and date columns, and **tells you about every change**. |
| **Optional cleaning** | Remove duplicates or empty rows/columns, trim spaces, fill missing values. Nothing happens automatically; you choose the steps, see the impact, and can restore the original. |
| **AI chat** | Ask questions in English. Supports summaries, statistics, totals/averages, group comparisons, top-N/bottom-N, filters, counts, trends over time, correlations, outliers, missing values and duplicates. Follow-up questions work ("now show that as a pie chart"). |
| **Transparency** | Every answer has a *How this was calculated* panel showing the equivalent Pandas code and the validated analysis plan. |
| **Offline mode** | With no API key, a built-in rule matcher still answers common questions. These answers are clearly labelled as rule-based, never as AI. |
| **Visualizations** | Bar, line, pie, histogram, scatter, box plot and correlation heatmap, with a consistent, colour-blind-safe palette. |
| **Insights** | Deterministic findings: top and bottom categories, monthly trend, strong correlations, unusual values, data-quality issues. An optional AI summary rewrites them as a narrative. |
| **Reports** | Download a self-contained HTML report (summary, findings, charts, statistics), plus CSV exports of any result table. |

## 4. Technology stack

| Technology | Purpose |
|---|---|
| **Python 3.10+** | Application logic |
| **Streamlit** | Web interface (pages, chat, tables, downloads) |
| **Pandas** | Reading files and performing every calculation |
| **Plotly** | Interactive charts |
| **OpenPyXL** | Reading `.xlsx` files |
| **Anthropic Claude API** (default) or **Google Gemini API** | Understanding questions and writing explanations |
| **python-dotenv** | Loading API keys from `.env` |
| **pytest** | Automated tests (80+) |

No database, React, Node.js or Docker: it is a single Python application.

## 5. Architecture

```text
                         USER (browser)
                              │
                     ┌────────▼─────────┐
                     │  STREAMLIT UI    │  components/  (5 pages + sidebar)
                     └──┬────────────┬──┘
           upload file  │            │  ask a question
                        ▼            ▼
              ┌───────────────┐  ┌────────────────────────────┐
              │ dataset_loader│  │ chat_engine (controller)   │
              │ validate+parse│  │  1. plan   ──► LLM / rules │
              └──────┬────────┘  │  2. check  ──► validate    │
                     ▼           │  3. compute──► Pandas      │
            DataFrame in memory  │  4. explain──► LLM         │
                     │           └──────┬─────────────────────┘
                     ▼                  ▼
     ┌──────────────────────────────────────────────────┐
     │ analysis_engine (Pandas)  chart_generator (Plotly)│
     │ insights (statistics)     report_generator (HTML) │
     └──────────────────────────────────────────────────┘
```

**Key design decision:** the LLM returns a small JSON *plan* (for example
`{"operation": "group_aggregate", "group_by": "Product", "value_column": "Revenue", "aggregation": "sum"}`),
not code. The plan is validated against the real columns and a whitelist of operations,
then executed by Pandas. Read the full design, with diagrams, in **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)**.

## 6. Project structure

```text
ai-dataset-analysis-assistant/
├── app.py                     # Streamlit entry point (page navigation)
├── config.py                  # All settings and limits in one place
├── requirements.txt
├── .env.example               # Copy to .env and add your API key
├── .streamlit/config.toml     # Theme and upload limit
│
├── services/                  # Business logic. No Streamlit here, so it is all unit-testable
│   ├── dataset_loader.py      # Validate + read CSV/XLSX, detect types, report changes
│   ├── analysis_engine.py     # Every calculation (Pandas)
│   ├── query_planner.py       # Plan schema → validation → execution → result
│   ├── rule_planner.py        # Offline keyword-based planner (no AI)
│   ├── ai_service.py          # LLM provider interface (Claude, Gemini) + prompts
│   ├── chat_engine.py         # The analysis controller: plan → check → compute → explain
│   ├── chart_generator.py     # Plotly charts with one consistent style
│   ├── insights.py            # Deterministic findings
│   ├── data_cleaner.py        # Optional, user-approved cleaning steps
│   └── report_generator.py    # HTML report
│
├── components/                # Streamlit UI
│   ├── home_page.py  dataset_page.py  chat_interface.py
│   ├── visualizations_page.py  insights_page.py
│   ├── sidebar.py  state.py  styles.py  nav.py
│
├── tests/                     # pytest suite (loader, analysis, planner, AI with fake provider)
├── sample_data/               # Demo datasets (sales, students, employees, messy)
├── scripts/generate_sample_data.py
├── docs/                      # ARCHITECTURE.md, USER_GUIDE.md, screenshots
└── reports/                   # (unused by default; reports are downloaded, not stored)
```

## 7. Installation

Requirements: Python **3.10 or newer** (tested on 3.13), macOS, Windows or Linux.

> **Keep the project out of iCloud-synced folders** (Desktop / Documents) when your disk is nearly
> full: macOS then offloads files to iCloud and Python start-up takes minutes. `~/Projects/` is a good place.

**macOS / Linux: one command.** `run.sh` creates the Python environment on first run and installs everything:

```bash
cd ~/Downloads/ai-dataset-analysis-assistant
```

```bash
./run.sh
```

The environment is created in `~/.venvs/ai-dataset-analysis-assistant`, **outside the project folder on
purpose**: if the project is in an iCloud-synced folder (Desktop or Documents), iCloud offloads the
thousands of small library files and every start-up becomes extremely slow.

**Manual setup (macOS / Linux):**

```bash
python3 -m venv ~/.venvs/ai-dataset-analysis-assistant
```

```bash
source ~/.venvs/ai-dataset-analysis-assistant/bin/activate
```

```bash
pip install -r requirements.txt
```

### Windows

1. Install **Python 3.10 or newer** from <https://www.python.org/downloads/>. In the installer, tick
   **"Add python.exe to PATH"**.
2. Extract the project zip to a folder **outside OneDrive** (OneDrive can offload files just like iCloud),
   for example `C:\Projects\ai-dataset-analysis-assistant`.
3. Open **Command Prompt** (or PowerShell) in that folder and run:

```bat
run.bat
```

The first run creates a `.venv` folder and installs everything (takes a few minutes), then opens the app at
**http://localhost:8501**. Afterwards `run.bat` starts it in seconds. In PowerShell, type `.\run.bat`.

| Windows command | What it does |
|---|---|
| `run.bat` | Start the app |
| `run.bat check` | Test the AI provider in `.env` |
| `run.bat test` | Run the automated tests |
| `copy .env.example .env` | Create the settings file (then edit it with Notepad: `notepad .env`) |

Don't copy a `.venv` folder from a Mac: it can't run on Windows. `run.bat` removes it automatically.

## 8. Configure the AI provider

The app **runs without any API key** (offline rule-based mode). For full AI chat:

```bash
cp .env.example .env
```

(Windows: `copy .env.example .env`, then `notepad .env`.)

Open `.env` and fill in **one** provider (then verify it with `./run.sh check`):

```ini
AI_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-...        # from https://console.anthropic.com
# ANTHROPIC_MODEL=claude-opus-5-5   # optional; this is the default
```

or

```ini
AI_PROVIDER=gemini
GEMINI_API_KEY=...                  # from https://aistudio.google.com
GEMINI_MODEL=gemini-3.5-flash                 # optional; this is the default
GEMINI_FALLBACK_MODEL=gemini-3.5-flash-lite   # optional backup when the main model is busy
```

Notes:
- `.env` is listed in `.gitignore`. **Never commit your key.**
- API usage is billed by the provider. `MAX_AI_REQUESTS_PER_SESSION` (default 60) caps the requests one browser session can make.
- `AI_SHARE_SAMPLE_VALUES=false` stops sending example category values to the AI (see [privacy](#14-security-and-privacy)).
- Restart the app after editing `.env`.

## 9. Run the application

```bash
./run.sh
```

Your browser opens at **http://localhost:8501**. Press `Ctrl+C` in the terminal to stop.

Other commands:

| Command | What it does |
|---|---|
| `./run.sh check` | Tests the AI provider in `.env` with a few real questions |
| `./run.sh test` | Runs the automated test suite |

Manual alternative: activate the environment (`source ~/.venvs/ai-dataset-analysis-assistant/bin/activate`),
then run `streamlit run app.py`. **Don't run plain `streamlit` without activating it**: a system-wide
Streamlit may be too old, and the app will stop with an explanation.

To regenerate the demo datasets:

```bash
~/.venvs/ai-dataset-analysis-assistant/bin/python scripts/generate_sample_data.py
```

## 10. How to use it

1. **Home**: upload a file, or click a sample dataset (Sales, Students, Employees, Messy data).
2. **Dataset**: check the preview, column types, statistics, missing values and duplicates. Optionally clean the data in the *Clean data* tab.
3. **AI Chat**: type a question or click a suggestion. Open *How this was calculated* to see the Pandas code. Click *Add to report* on any chart.
4. **Visualizations**: pick a chart type and columns to build charts yourself.
5. **Insights & Reports**: read the calculated findings, generate an AI summary (optional), and download the HTML report or CSV tables.

The step-by-step guide with screenshots is in **[docs/USER_GUIDE.md](docs/USER_GUIDE.md)**.

## 11. Example questions

Using `sample_data/sales_dataset.csv`:

| Type | Example |
|---|---|
| Overview | *Summarize this dataset* · *How many rows and columns are there?* |
| Single value | *What is the average revenue?* · *What is the total units sold?* |
| Group comparison | *Which product has the highest total revenue?* · *Average revenue by region* |
| Top / bottom N | *Top 3 sales reps by units sold* · *Bottom 2 products by revenue* |
| Filters (AI mode) | *Total revenue in the North region* · *How many orders had a discount above 10%?* |
| Trends | *Show monthly revenue trend* · *Weekly order count* |
| Relationships | *Show the correlation between numerical columns* · *Scatter plot of unit price vs revenue* |
| Data quality | *Are there missing values?* · *Find duplicate rows* · *Outliers in revenue* |
| Charts | *Pie chart of revenue by category* · *Histogram of customer rating* |
| Follow-up (AI mode) | *Now show that as a pie chart* · *Only for laptops* |

Questions the app will **decline or ask to clarify**: predictions ("What will sales be next year?"),
causes ("Why did June drop?"), and anything not in the data ("What's the weather?").

## 12. Run the tests

```bash
./run.sh test
```

The suite (80+ tests) checks:
- File validation: empty, header-only, malformed, corrupt Excel, wrong type, too large, delimiters, messy headers.
- **Every calculation against an independently computed value** (e.g. Laptop revenue = 750,000 + 1,000,000).
- Plan validation rejects unknown columns, unknown operations, invalid aggregations and code-like input.
- The AI flow uses a **fake provider** (no network, no cost): hallucinated columns are caught, outages fall back gracefully, and raw rows never reach the planning prompt.
- The HTML report escapes user content and contains no secrets.

## 13. Where AI is used (and where it is not)

| Step | Done by | Why |
|---|---|---|
| Read file, detect types | Pandas | Deterministic |
| Understand the question → JSON plan | **LLM** | Natural-language understanding is what LLMs are good at |
| Check the plan (columns, types, operation) | Python | Never trust model output blindly |
| Calculate the answer | Pandas | Exact and testable |
| Draw the chart | Plotly | From calculated tables only |
| Explain the result in English | **LLM** | Given only the verified numbers |
| Find insights | Python statistics | Deterministic findings |
| Turn findings into a narrative | **LLM** (optional) | Wording only; no new facts |

## 14. Security and privacy

- **No code execution.** The AI can only choose from 15 whitelisted operations; there is no `eval`/`exec`, SQL or shell.
- **Validation.** Every column name, aggregation, operator and number in a plan is checked against the real data.
- **Minimal data sharing.** The AI receives column names and types, numeric ranges, up to 5 example values per text column (can be turned off), and at most 20 rows of an already-calculated result. **Never the full dataset.**
- **No storage.** Uploaded files stay in memory for the browser session and are never written to disk.
- **Secrets.** API keys come from environment variables only; they never appear in logs, errors or reports.
- **Limits.** 50 MB / 1,000,000 rows per file, 500-character questions, a per-session AI request cap.
- **Safe reports.** All user text is HTML-escaped in the exported report.

> Don't upload confidential data to an external AI provider without permission.
> With `AI_PROVIDER=none` nothing leaves your computer.

## 15. Known limitations

- Structured, tabular data only (one table; Excel reads the first sheet).
- Supports a defined set of analyses, not arbitrary questions. Multi-step questions ("revenue growth of the top product per region") may need to be split up.
- Offline mode only understands simple phrasings that name a column.
- Very large files (hundreds of MB) are refused or slow, because all processing is in memory.
- The AI explanation may occasionally word things imperfectly. The numbers in the table and chart are always the source of truth.

## 16. Future enhancements

- Forecasting (e.g. Prophet / statsmodels) and anomaly detection over time
- Multiple sheets and joining multiple datasets
- Saved sessions and history (SQLite) with user accounts
- PDF export
- More operations: pivot tables, percent change, rolling averages, multi-column group-by
- Deployment to Streamlit Community Cloud or a college server

## 17. Troubleshooting

| Problem | Fix |
|---|---|
| `command not found: streamlit` | Use `./run.sh` (or activate the environment first) |
| `unexpected keyword argument 'width'` or *"This app needs Streamlit 1.50 or newer"* | You started it with an old, system-wide Streamlit. Use `./run.sh`, or activate the environment first |
| Gemini: *"model … was not found"* or *"overloaded"* | Google retires and rotates models. Run `./run.sh check`; if needed set other models in `.env` (`GEMINI_MODEL`, `GEMINI_FALLBACK_MODEL`) |
| Gemini: *"rate limit"* / *"daily quota is used up"* | Free keys have per-minute and **per-day** limits per model (each question uses 2 requests). Wait, or switch `GEMINI_MODEL`. Simple questions keep working through the built-in rule matcher meanwhile |
| Sidebar says *Offline mode* | Create `.env` from `.env.example`, add your key, restart the app |
| "API key was rejected" | Check for spaces or quotes around the key in `.env` |
| "Model was not found" | Remove `ANTHROPIC_MODEL` from `.env` to use the default |
| CSV shows one giant column | Unusual delimiter. Save it as a standard comma-separated CSV |
| Excel file fails | Must be `.xlsx` (not `.xls`); only the first sheet is read |
| Start-up takes minutes / `Errno 89 Operation canceled` | The Python environment is inside iCloud Drive. Use `./run.sh`, which keeps it in `~/.venvs/` |
| AI chat not working | Run `./run.sh check`. It prints exactly what fails (key, model name, quota) |
