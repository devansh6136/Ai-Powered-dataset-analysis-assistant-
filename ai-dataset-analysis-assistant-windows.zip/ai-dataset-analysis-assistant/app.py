"""AI-Powered Dataset Analysis Assistant — Streamlit entry point.

Run with:  ./run.sh   (macOS / Linux)      or      run.bat   (Windows)
"""

import sys

import streamlit as st

MIN_STREAMLIT = (1, 50)
SETUP_HELP = """
**How to fix:** stop the app (`Ctrl+C`) and start it from the project's own environment:

```bash
./run.sh        # macOS / Linux
run.bat         # Windows
```

or activate the environment first (macOS):

```bash
source ~/.venvs/ai-dataset-analysis-assistant/bin/activate
streamlit run app.py
```
"""


def check_environment() -> None:
    """Stop with a clear message if the app is started with the wrong Python/Streamlit."""
    installed = tuple(int(part) for part in st.__version__.split(".")[:2])
    if installed < MIN_STREAMLIT:
        st.error(f"This app needs **Streamlit {'.'.join(map(str, MIN_STREAMLIT))} or newer**, but it was "
                 f"started with Streamlit {st.__version__} from `{sys.executable}`.")
        st.markdown(SETUP_HELP)
        st.stop()


check_environment()

try:
    import config
    from components import (chat_interface, dataset_page, home_page, insights_page, nav, sidebar,
                            state, visualizations_page)
    from components.styles import inject_css
except ModuleNotFoundError as exc:
    st.error(f"A required package is missing: **{exc.name}** (Python: `{sys.executable}`).")
    st.markdown(SETUP_HELP)
    st.stop()

st.set_page_config(page_title=config.APP_NAME, page_icon=":material/query_stats:", layout="wide")
inject_css()
state.init_state()

nav.PAGES.update({
    "home": st.Page(home_page.render, title="Home", icon=":material/home:", url_path="home", default=True),
    "dataset": st.Page(dataset_page.render, title="Dataset", icon=":material/table_view:", url_path="dataset"),
    "chat": st.Page(chat_interface.render, title="AI Chat", icon=":material/chat:", url_path="chat"),
    "visualizations": st.Page(visualizations_page.render, title="Visualizations",
                              icon=":material/bar_chart:", url_path="visualizations"),
    "insights": st.Page(insights_page.render, title="Insights & Reports",
                        icon=":material/lightbulb:", url_path="insights"),
})

page = st.navigation(list(nav.PAGES.values()))
sidebar.render()
page.run()
