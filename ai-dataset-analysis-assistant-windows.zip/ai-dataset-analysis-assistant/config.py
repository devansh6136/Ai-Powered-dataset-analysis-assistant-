"""Central settings for the app.

Everything configurable lives here so it is easy to find and explain.
Values come from environment variables (loaded from a `.env` file).
"""

import os

from dotenv import load_dotenv

load_dotenv()

APP_NAME = "AI-Powered Dataset Analysis Assistant"
APP_TAGLINE = "Upload a CSV or Excel file and ask questions about it in plain English."

# --- Upload limits ---
MAX_FILE_MB = 50                 # keep in sync with .streamlit/config.toml
MAX_ROWS = 1_000_000             # refuse files larger than this (memory safety)
ALLOWED_EXTENSIONS = (".csv", ".xlsx")

# --- Chat / AI limits ---
MAX_QUESTION_CHARS = 500
MAX_RESULT_ROWS_FOR_AI = 20      # only this many result rows are sent to the AI
MAX_AI_REQUESTS_PER_SESSION = int(os.getenv("MAX_AI_REQUESTS_PER_SESSION", "60"))
AI_SHARE_SAMPLE_VALUES = os.getenv("AI_SHARE_SAMPLE_VALUES", "true").lower() == "true"
# true = 2 AI calls per question (plan + plain-English explanation); false = 1 call (plan only,
# the calculated summary is shown) — about twice as fast and uses half the free quota.
AI_EXPLAIN_ANSWERS = os.getenv("AI_EXPLAIN_ANSWERS", "true").lower() == "true"

# --- AI provider ---
AI_PROVIDER = os.getenv("AI_PROVIDER", "anthropic").strip().lower()
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-opus-5-5")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.5-flash")
# Used automatically when the main model is overloaded or out of free quota ("" = no backup)
GEMINI_FALLBACK_MODEL = os.getenv("GEMINI_FALLBACK_MODEL", "gemini-3.5-flash-lite")
