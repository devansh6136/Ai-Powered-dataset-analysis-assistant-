"""Session state: everything one browser tab remembers between clicks.

Uploaded data lives only in memory (st.session_state) — it is never written
to disk and disappears when the browser tab is closed.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

import config
from services.ai_service import AIService, get_provider
from services.dataset_loader import DatasetError, LoadResult, load_dataset

SAMPLE_DIR = Path(__file__).resolve().parent.parent / "sample_data"
SAMPLES = {
    "Sales (CSV)": "sales_dataset.csv",
    "Students (CSV)": "student_performance.csv",
    "Employees (Excel)": "employees.xlsx",
    "Messy data (CSV)": "messy_dataset.csv",
}

DEFAULTS = {
    "df": None,                 # the working DataFrame (after optional cleaning)
    "original_df": None,        # as loaded, so cleaning can be undone
    "filename": None,
    "load_notes": [],
    "cleaning_log": [],
    "messages": [],             # chat history
    "last_plan": None,          # for follow-up questions
    "report_charts": [],        # [{"title": str, "figure": plotly Figure}]
    "ai_summary": None,
    "ai_requests": 0,
    "upload_error": None,
    "data_version": 0,          # bumps whenever the data changes (cache key)
}


def init_state() -> None:
    for key, value in DEFAULTS.items():
        if key not in st.session_state:
            st.session_state[key] = list(value) if isinstance(value, list) else value


def get_df() -> pd.DataFrame | None:
    return st.session_state.get("df")


def set_dataset(result: LoadResult) -> None:
    st.session_state.update(
        df=result.df, original_df=result.df.copy(), filename=result.filename,
        load_notes=result.notes, cleaning_log=[], messages=[], last_plan=None,
        report_charts=[], ai_summary=None, upload_error=None,
        data_version=st.session_state.get("data_version", 0) + 1,
    )


def replace_working_df(df: pd.DataFrame, log: list[str]) -> None:
    """Called after cleaning: keep the original, swap the working copy."""
    st.session_state.df = df
    st.session_state.cleaning_log = log
    st.session_state.ai_summary = None
    st.session_state.last_plan = None
    st.session_state.data_version += 1


def clear_dataset() -> None:
    for key, value in DEFAULTS.items():
        if key not in ("ai_requests",):
            st.session_state[key] = list(value) if isinstance(value, list) else value


def handle_upload(widget_key: str) -> None:
    """on_change callback for st.file_uploader (runs only when the file changes)."""
    file = st.session_state.get(widget_key)
    if file is None:
        return
    try:
        set_dataset(load_dataset(file.getvalue(), file.name))
    except DatasetError as exc:
        st.session_state.upload_error = f"{file.name}: {exc}"


def load_sample(filename: str) -> None:
    path = SAMPLE_DIR / filename
    try:
        set_dataset(load_dataset(path.read_bytes(), filename))
    except (OSError, DatasetError) as exc:
        st.session_state.upload_error = f"Couldn't load sample: {exc}"


@st.cache_resource(show_spinner=False)
def _provider_cached(provider: str, anthropic_model: str, gemini_model: str):
    return get_provider()


def get_ai() -> tuple[AIService | None, str]:
    """Return (AIService or None, status text). Respects the per-session request cap."""
    provider, status = _provider_cached(config.AI_PROVIDER, config.ANTHROPIC_MODEL, config.GEMINI_MODEL)
    if provider is None:
        return None, status
    if st.session_state.get("ai_requests", 0) >= config.MAX_AI_REQUESTS_PER_SESSION:
        return None, (f"AI request limit for this session reached "
                      f"({config.MAX_AI_REQUESTS_PER_SESSION}); using offline mode")
    return AIService(provider), status


def count_ai_requests(n: int) -> None:
    st.session_state.ai_requests = st.session_state.get("ai_requests", 0) + n


def add_chart_to_report(title: str, figure) -> bool:
    charts = st.session_state.report_charts
    if any(c["title"] == title for c in charts):
        return False
    charts.append({"title": title, "figure": figure})
    return True
