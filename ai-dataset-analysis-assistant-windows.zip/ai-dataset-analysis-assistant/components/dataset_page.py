"""B. Dataset — preview, column types, statistics, missing values, duplicates, cleaning."""

import streamlit as st

from components import nav, state
from services import analysis_engine as ae
from services import chart_generator as cg
from services.data_cleaner import apply_cleaning, suggest_cleaning

PREVIEW_ROWS = 1000


def date_formats(df) -> dict:
    """Show date-only columns as YYYY-MM-DD instead of 'YYYY-MM-DD 00:00:00'."""
    config = {}
    for col in ae.column_types(df)["datetime"]:
        values = df[col].dropna()
        if len(values) and (values == values.dt.normalize()).all():
            config[col] = st.column_config.DatetimeColumn(col, format="YYYY-MM-DD")
    return config


def empty_state(message: str = "Upload a dataset to get started.") -> None:
    st.info(message, icon=":material/upload_file:")
    if st.button("Go to Home to upload", icon=":material/home:"):
        nav.go("home")


def render() -> None:
    st.title("Dataset")
    df = state.get_df()
    if df is None:
        empty_state()
        return

    st.caption(f"File: **{st.session_state.filename}** — processed in memory only.")
    if st.session_state.load_notes:
        st.info("**Adjustments made while reading the file** (your original file is unchanged):\n\n"
                + "\n".join(f"- {n}" for n in st.session_state.load_notes), icon=":material/info:")
    if st.session_state.cleaning_log:
        st.warning("**You are viewing a cleaned copy.** Changes: "
                   + "; ".join(st.session_state.cleaning_log), icon=":material/cleaning_services:")

    o = ae.dataset_overview(df)
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Rows", f"{o['rows']:,}")
    c2.metric("Columns", o["columns"])
    c3.metric("Missing cells", f"{o['missing_cells']:,}")
    c4.metric("Missing %", f"{o['missing_percent']:.1f}%")
    c5.metric("Duplicate rows", f"{o['duplicate_rows']:,}")
    st.caption(f"Column types: {o['numeric_columns']} numeric · {o['categorical_columns']} text/category · "
               f"{o['datetime_columns']} date")

    tabs = st.tabs(["Preview", "Columns", "Statistics", "Missing values", "Duplicates", "Clean data"])

    with tabs[0]:
        st.dataframe(df.head(PREVIEW_ROWS), width="stretch", height=420, column_config=date_formats(df))
        st.caption(f"Showing the first {min(PREVIEW_ROWS, len(df)):,} of {len(df):,} rows.")
        st.download_button("Download current data (CSV)", df.to_csv(index=False).encode("utf-8"),
                           file_name=f"data_{st.session_state.filename.rsplit('.', 1)[0]}.csv",
                           mime="text/csv", icon=":material/download:")

    with tabs[1]:
        st.dataframe(ae.column_info(df), width="stretch", hide_index=True, column_config={
            "Missing %": st.column_config.ProgressColumn("Missing %", min_value=0, max_value=100, format="%.1f%%"),
        })

    with tabs[2]:
        st.markdown("##### Numeric columns")
        num = ae.numeric_summary(df)
        if num.empty:
            st.caption("No numeric columns.")
        else:
            st.dataframe(num, width="stretch", hide_index=True)
        st.markdown("##### Text / category columns")
        cat = ae.categorical_summary(df)
        if cat.empty:
            st.caption("No text columns.")
        else:
            st.dataframe(cat, width="stretch", hide_index=True)

    with tabs[3]:
        missing = ae.missing_values(df)
        if missing.empty:
            st.success("No missing values found.", icon=":material/check_circle:")
        else:
            left, right = st.columns([2, 3])
            left.dataframe(missing, width="stretch", hide_index=True)
            right.plotly_chart(cg.bar_chart(missing, "Column", "Missing", "Missing values per column"),
                               width="stretch", key="missing_chart")

    with tabs[4]:
        count, rows = ae.duplicate_rows(df)
        if count == 0:
            st.success("No duplicate rows found.", icon=":material/check_circle:")
        else:
            st.warning(f"{count:,} duplicate row(s) — exact copies of an earlier row. "
                       "All rows involved are shown below.", icon=":material/content_copy:")
            st.dataframe(rows.head(500), width="stretch")

    with tabs[5]:
        _render_cleaning(df)


def _render_cleaning(df) -> None:
    st.markdown("Nothing is changed automatically. Pick the steps you want, review the impact, then apply. "
                "You can always restore the original.")
    suggestions = suggest_cleaning(df)
    if not suggestions:
        st.success("No cleaning needed — no duplicates, blanks or untrimmed text found.",
                   icon=":material/check_circle:")
    else:
        with st.form("cleaning_form"):
            chosen = [s.action for s in suggestions
                      if st.checkbox(f"{s.label} — *{s.impact}*", key=f"clean_{s.action}")]
            submitted = st.form_submit_button("Apply selected steps", type="primary")
        if submitted:
            if not chosen:
                st.warning("Select at least one step.")
            else:
                cleaned, log = apply_cleaning(df, chosen)
                state.replace_working_df(cleaned, st.session_state.cleaning_log + log)
                st.rerun()

    if st.session_state.cleaning_log:
        st.markdown("**Changes applied:**\n" + "\n".join(f"- {c}" for c in st.session_state.cleaning_log))
        if st.button("Restore original data", icon=":material/undo:"):
            state.replace_working_df(st.session_state.original_df.copy(), [])
            st.rerun()
