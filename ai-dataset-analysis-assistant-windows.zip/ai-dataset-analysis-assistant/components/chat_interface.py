"""C. AI Chat — ask questions about the dataset in plain English."""

import streamlit as st

from components import state
from components.dataset_page import empty_state
from services import analysis_engine as ae
from services.chat_engine import ChatAnswer, answer_question
from services.insights import pick_main_measure


def suggested_questions(df) -> list[str]:
    """Build suggestions from the real column names so they always work."""
    main = pick_main_measure(df)
    measures = ([main] if main else []) + [m for m in ae.measure_columns(df) if m != main]
    groups = ae.grouping_columns(df, max_unique=30)
    dates = ae.column_types(df)["datetime"]
    out = ["Summarize this dataset", "Are there missing values?"]
    if measures and groups:
        out.append(f"Which {groups[0]} has the highest total {measures[0]}?")
        out.append(f"Show a bar chart of average {measures[0]} by {groups[-1]}")
    if measures and dates:
        out.append(f"Show monthly {measures[0]} trend")
    if len(measures) >= 2:
        out.append("Show the correlation between numerical columns")
    elif measures:
        out.append(f"Show a histogram of {measures[0]}")
    out.append("Find duplicate rows")
    return out[:6]


def _queue_suggestion() -> None:
    choice = st.session_state.get("suggestion_pills")
    if choice:
        st.session_state.pending_question = choice
    st.session_state.suggestion_pills = None


def render() -> None:
    df = state.get_df()
    ai, status = state.get_ai()

    head, actions = st.columns([4, 1])
    head.title("AI Chat")
    if df is None:
        empty_state("Upload a dataset first, then ask questions about it here.")
        return
    if st.session_state.messages and actions.button("Clear chat", icon=":material/delete_sweep:",
                                                     width="stretch"):
        st.session_state.messages = []
        st.session_state.last_plan = None
        st.rerun()

    if ai:
        head.caption(f"Answers explained by **{status}** · numbers calculated by Pandas")
    else:
        st.info(f"**Offline mode** — {status}. Simple questions are matched with built-in rules "
                "(answers are labelled as such). Add an API key to `.env` for full AI chat — see README.",
                icon=":material/cloud_off:")

    prompt = st.chat_input(f"Ask about {st.session_state.filename}…", max_chars=500)
    question = prompt or st.session_state.pop("pending_question", None)

    for i, msg in enumerate(st.session_state.messages):
        _render_message(i, msg)

    if question:
        with st.chat_message("user"):
            st.markdown(question)
        with st.chat_message("assistant"):
            with st.status("Analysing your data…") as status:
                answer = answer_question(question, df, ai, st.session_state.last_plan,
                                         on_step=lambda message: status.update(label=message))
        state.count_ai_requests(answer.ai_calls)
        if answer.plan and answer.kind == "answer":
            st.session_state.last_plan = answer.plan
        st.session_state.messages += [{"role": "user", "text": question},
                                      {"role": "assistant", "answer": answer}]
        st.rerun()

    if not st.session_state.messages:
        st.markdown("##### Try asking")
    st.pills("Suggested questions", suggested_questions(df), key="suggestion_pills",
             on_change=_queue_suggestion, label_visibility="collapsed")


def _render_message(i: int, msg: dict) -> None:
    if msg["role"] == "user":
        with st.chat_message("user"):
            st.markdown(msg["text"])
        return

    answer: ChatAnswer = msg["answer"]
    with st.chat_message("assistant"):
        if answer.kind == "error":
            st.error(answer.text, icon=":material/error:")
        elif answer.kind == "clarify":
            st.warning(answer.text, icon=":material/help:")
        else:
            st.markdown(answer.text)
        for w in answer.warnings:
            st.caption(f":material/warning: {w}")

        if answer.chart is not None:
            st.plotly_chart(answer.chart, width="stretch", key=f"chat_chart_{i}")

        table = answer.table
        if table is not None and not table.empty:
            with st.expander(f"Result table ({len(table):,} rows)"):
                st.dataframe(table, width="stretch", hide_index=True)
                st.download_button("Download as CSV", table.to_csv(index=False).encode("utf-8"),
                                   file_name="result.csv", mime="text/csv", key=f"dl_{i}",
                                   icon=":material/download:")

        if answer.code:
            with st.expander("How this was calculated"):
                st.caption("Equivalent Pandas code (shown for transparency — the app runs the same "
                           "operation through validated functions):")
                st.code(answer.code, language="python")
                st.caption("Validated analysis plan:")
                st.json(answer.plan, expanded=False)

        left, right = st.columns([3, 1])
        if answer.source:
            left.caption(f"Source: {answer.source}")
        if answer.chart is not None and answer.result is not None:
            if right.button("Add to report", key=f"report_{i}", icon=":material/add_chart:", width="stretch"):
                added = state.add_chart_to_report(answer.result.title, answer.chart)
                st.toast("Chart added to report" if added else "Already in the report")
