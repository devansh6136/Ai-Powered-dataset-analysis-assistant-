"""A. Home / Overview — what the app does and where to start."""

import streamlit as st

import config
from components import nav, state
from components.styles import card


def render() -> None:
    st.markdown(
        f"<div class='da-hero'><div class='da-eyebrow'>Python · Pandas · Plotly · LLM</div>"
        f"<h1>{config.APP_NAME}</h1><p>{config.APP_TAGLINE} Every number is calculated "
        f"by Python from your data; the AI only understands your question and explains the result.</p></div>",
        unsafe_allow_html=True,
    )

    if st.session_state.upload_error:
        st.error(st.session_state.upload_error, icon=":material/error:")

    df = state.get_df()
    left, right = st.columns([3, 2], gap="large")
    with left:
        if df is None:
            st.subheader("1 · Upload a dataset")
            st.file_uploader("CSV or Excel (.xlsx)", type=["csv", "xlsx"], key="uploader_home",
                             on_change=state.handle_upload, args=("uploader_home",),
                             help=f"Up to {config.MAX_FILE_MB} MB. Only the first sheet of an Excel file is read.")
            st.caption("No file handy? Try a sample dataset:")
            items = list(state.SAMPLES.items())
            for row in (items[:2], items[2:]):
                for col, (label, filename) in zip(st.columns(2), row):
                    if col.button(label, width="stretch", key=f"sample_{filename}",
                                  icon=":material/dataset:"):
                        state.load_sample(filename)
                        st.rerun()
        else:
            st.success(f"**{st.session_state.filename}** is loaded — "
                       f"{df.shape[0]:,} rows × {df.shape[1]} columns.", icon=":material/check_circle:")
            a, b, c = st.columns(3)
            if a.button("Explore dataset", icon=":material/table_view:", width="stretch"):
                nav.go("dataset")
            if b.button("Ask a question", icon=":material/chat:", type="primary", width="stretch"):
                nav.go("chat")
            if c.button("View insights", icon=":material/lightbulb:", width="stretch"):
                nav.go("insights")

    with right:
        st.subheader("How it works")
        steps = [
            "Upload a CSV or Excel file — it stays in memory, never saved.",
            "The app profiles it: types, missing values, duplicates, statistics.",
            "Ask a question. The AI turns it into a safe analysis plan.",
            "Pandas calculates the answer; the AI explains it in plain English.",
            "Add charts to a report and download it.",
        ]
        st.markdown("".join(f"<div class='da-step'><b>{i}</b><span>{s}</span></div>"
                            for i, s in enumerate(steps, 1)), unsafe_allow_html=True)

    st.write("")
    features = [
        ("table_view", "Dataset profiling", "Rows, columns, data types, missing values, duplicates and summary statistics."),
        ("chat", "AI chat", "Ask in plain English: totals, averages, top-N, filters, trends, correlations."),
        ("bar_chart", "Visualizations", "Bar, line, pie, histogram, scatter, box plots and correlation heatmaps."),
        ("description", "Insights & reports", "Automatic findings, data-quality notes and a downloadable HTML report."),
    ]
    for col, (icon, title, text) in zip(st.columns(4), features):
        col.markdown(card(icon, title, text), unsafe_allow_html=True)

    st.write("")
    st.caption(":material/lock: Privacy: the AI never receives your full dataset — only column names and types, "
               "a few example values (configurable), and the small result tables Python has already calculated.")
