"""Streamlit UI: one module per page, plus shared state, styles and sidebar."""
