"""E. Insights & Reports — calculated findings, AI summary and downloads."""

import pandas as pd
import streamlit as st

from components import state
from components.dataset_page import empty_state
from services import analysis_engine as ae
from services.ai_service import AIError
from services.insights import compute_findings
from services.report_generator import build_html_report

CATEGORY_ICONS = {"Overview": ":material/dataset:", "Top & bottom": ":material/leaderboard:",
                  "Trend": ":material/trending_up:", "Relationship": ":material/hub:",
                  "Unusual values": ":material/troubleshoot:", "Data quality": ":material/fact_check:"}


def _findings(df):
    """Recompute only when the data changes."""
    key = ("findings", st.session_state.data_version)
    if st.session_state.get("_findings_key") != key:
        st.session_state._findings = compute_findings(df)
        st.session_state._findings_key = key
    return st.session_state._findings


def render() -> None:
    st.title("Insights & Reports")
    df = state.get_df()
    if df is None:
        empty_state()
        return

    findings = _findings(df)
    o = ae.dataset_overview(df)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Rows", f"{o['rows']:,}")
    c2.metric("Columns", o["columns"])
    c3.metric("Missing cells", f"{o['missing_cells']:,}")
    c4.metric("Duplicate rows", f"{o['duplicate_rows']:,}")

    left, right = st.columns([3, 2], gap="large")
    with left:
        st.subheader("Key findings")
        st.caption("Calculated directly from the data with standard statistics — no AI involved.")
        current = None
        for f in findings:
            if f.category != current:
                current = f.category
                st.markdown(f"**{CATEGORY_ICONS.get(f.category, '')} {f.category}**")
            st.markdown(f"- {f.text}")

    with right:
        st.subheader("AI summary")
        ai, status = state.get_ai()
        if st.session_state.ai_summary:
            with st.container(border=True):
                st.markdown(st.session_state.ai_summary)
                st.caption(f"Written by {st.session_state.get('ai_summary_by', 'AI')} from the findings on "
                           "the left. Treat 'worth investigating' points as hypotheses.")
        if ai:
            if st.button("Generate AI summary" if not st.session_state.ai_summary else "Regenerate",
                         icon=":material/auto_awesome:", type="primary"):
                with st.spinner("Writing summary…"):
                    try:
                        st.session_state.ai_summary = ai.write_insights(
                            st.session_state.filename, [f"[{f.category}] {f.text}" for f in findings])
                        st.session_state.ai_summary_by = ai.label
                        state.count_ai_requests(1)
                    except AIError as exc:
                        st.error(str(exc))
                st.rerun()
        else:
            st.info(f"AI summary unavailable — {status}. The calculated findings and the report "
                    "still work without AI.", icon=":material/cloud_off:")

    st.divider()
    _render_report(df, findings)


def _render_report(df, findings) -> None:
    st.subheader("Report")
    charts = st.session_state.report_charts
    if charts:
        st.markdown(f"**Charts in report ({len(charts)})** — add more from AI Chat or Visualizations.")
        for i, chart in enumerate(list(charts)):
            a, b = st.columns([5, 1])
            a.markdown(f"{i + 1}. {chart['title']}")
            if b.button("Remove", key=f"rm_chart_{i}", width="stretch"):
                charts.pop(i)
                st.rerun()
    else:
        st.caption("No charts added yet. Use **Add to report** on any chart in AI Chat or Visualizations.")

    html = build_html_report(
        st.session_state.filename, df, findings, charts,
        ai_summary=st.session_state.ai_summary,
        ai_label=st.session_state.get("ai_summary_by"),
        change_log=st.session_state.load_notes + st.session_state.cleaning_log,
    )
    base = st.session_state.filename.rsplit(".", 1)[0]
    st.download_button("Download full report (HTML)", html.encode("utf-8"), file_name=f"report_{base}.html",
                       mime="text/html", type="primary", icon=":material/download:")

    st.markdown("**Download tables (CSV)**")
    tables = {
        "Column information": ae.column_info(df),
        "Numeric statistics": ae.numeric_summary(df),
        "Missing values": ae.missing_values(df),
        "Findings": pd.DataFrame([vars(f) for f in findings]),
    }
    cols = st.columns(len(tables))
    for col, (name, table) in zip(cols, tables.items()):
        col.download_button(name, table.to_csv(index=False).encode("utf-8"),
                            file_name=f"{base}_{name.lower().replace(' ', '_')}.csv", mime="text/csv",
                            disabled=table.empty, width="stretch", key=f"csv_{name}")
