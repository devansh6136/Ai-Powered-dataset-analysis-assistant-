"""D. Visualizations — build charts by picking a chart type and columns."""

import streamlit as st

from components import state
from components.dataset_page import empty_state
from services import analysis_engine as ae
from services import chart_generator as cg

CHART_OPTIONS = {
    "Bar — compare categories": "bar",
    "Line — change over time": "line",
    "Pie — share of a total": "pie",
    "Histogram — distribution of one number": "histogram",
    "Scatter — relationship between two numbers": "scatter",
    "Box — spread and outliers": "box",
    "Heatmap — correlation matrix": "heatmap",
}
AGG_OPTIONS = {"Total (sum)": "sum", "Average (mean)": "mean", "Median": "median",
               "Maximum": "max", "Minimum": "min", "Count of rows": "count"}
COUNT = "(count of rows)"


def render() -> None:
    st.title("Visualizations")
    df = state.get_df()
    if df is None:
        empty_state()
        return

    types = ae.column_types(df)
    numeric = types["numeric"]
    groups = [c for c in types["categorical"] + types["boolean"] if not ae.is_identifier(df, c)] \
        or types["categorical"]
    dates = types["datetime"]

    label = st.selectbox("Chart type", list(CHART_OPTIONS))
    kind = CHART_OPTIONS[label]

    try:
        fig = _build(kind, df, numeric, groups, dates)
    except ae.AnalysisError as exc:
        st.warning(str(exc), icon=":material/warning:")
        return
    if fig is None:
        return

    st.plotly_chart(fig, width="stretch", key="viz_chart")
    title = fig.layout.title.text or label
    a, b, _ = st.columns([1, 1, 2])
    if a.button("Add to report", icon=":material/add_chart:", width="stretch"):
        added = state.add_chart_to_report(title, fig)
        st.toast("Chart added to report" if added else "Already in the report")
    b.download_button("Download chart (HTML)", fig.to_html(include_plotlyjs="cdn").encode("utf-8"),
                      file_name="chart.html", mime="text/html", icon=":material/download:", width="stretch")


def _build(kind, df, numeric, groups, dates):
    c1, c2, c3, c4 = st.columns(4)

    if kind in ("bar", "pie"):
        if not groups:
            st.info("This dataset has no text/category columns to group by.")
            return None
        x = c1.selectbox("Category column", groups)
        y = c2.selectbox("Value column", [COUNT] + numeric)
        agg = "count" if y == COUNT else AGG_OPTIONS[c3.selectbox(
            "Aggregation", [k for k in AGG_OPTIONS if k != "Count of rows"])]
        n = c4.slider("Show top", 3, 30, 10)
        table = ae.group_aggregate(df, x, None if y == COUNT else y, agg, n=n)
        title = f"{table.columns[1]} by {x}"
        return cg.bar_chart(table, x, table.columns[1], title) if kind == "bar" \
            else cg.pie_chart(table, x, table.columns[1], title)

    if kind == "line":
        if not dates:
            st.info("A line chart over time needs a date column, and this dataset has none. "
                    "Try a bar chart instead.")
            return None
        x = c1.selectbox("Date column", dates)
        y = c2.selectbox("Value column", [COUNT] + numeric)
        agg = "count" if y == COUNT else AGG_OPTIONS[c3.selectbox(
            "Aggregation", [k for k in AGG_OPTIONS if k != "Count of rows"])]
        freq_label = c4.selectbox("Group by", ["Month", "Week", "Day", "Quarter", "Year"])
        freq = {"Day": "D", "Week": "W", "Month": "M", "Quarter": "Q", "Year": "Y"}[freq_label]
        table = ae.time_trend(df, x, None if y == COUNT else y, agg, freq)
        return cg.line_chart(table, "Period", table.columns[1], f"{table.columns[1]} per {freq_label.lower()}")

    if not numeric:
        st.info("This chart needs at least one numeric column.")
        return None

    if kind == "histogram":
        return cg.histogram(df, c1.selectbox("Numeric column", numeric))

    if kind == "box":
        col = c1.selectbox("Numeric column", numeric)
        by = c2.selectbox("Split by (optional)", ["(none)"] + groups)
        return cg.box_plot(df, col, None if by == "(none)" else by)

    if kind == "scatter":
        if len(numeric) < 2:
            st.info("A scatter plot needs two numeric columns.")
            return None
        x = c1.selectbox("X axis", numeric, index=0)
        y = c2.selectbox("Y axis", numeric, index=1)
        color = c3.selectbox("Colour by (optional)", ["(none)"] + groups)
        return cg.scatter_plot(df, x, y, None if color == "(none)" else color)

    # heatmap
    default = ae.measure_columns(df)[:8] or numeric[:8]
    cols = st.multiselect("Numeric columns", numeric, default=default)
    if len(cols) < 2:
        st.info("Pick at least two numeric columns.")
        return None
    return cg.correlation_heatmap(ae.correlation_matrix(df, cols))
