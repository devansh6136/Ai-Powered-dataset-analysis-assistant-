"""Page registry, filled in by app.py, so pages can link to each other."""

PAGES: dict = {}


def go(name: str) -> None:
    import streamlit as st
    st.switch_page(PAGES[name])
