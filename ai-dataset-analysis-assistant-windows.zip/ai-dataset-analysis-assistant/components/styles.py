"""Small CSS layer on top of Streamlit's theme (.streamlit/config.toml)."""

import streamlit as st

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
.stApp, .stApp p, .stApp label, .stApp button, .stApp input, .stApp textarea,
.stApp h1, .stApp h2, .stApp h3, .stApp h4, .stApp li { font-family: 'Inter', sans-serif; }
/* Keep Streamlit's icon font intact */
[data-testid="stIconMaterial"], .material-symbols-rounded { font-family: 'Material Symbols Rounded' !important; }
.block-container { padding-top: 3.6rem; max-width: 1180px; }
h1 { font-weight: 700; letter-spacing: -0.02em; }
h2, h3 { font-weight: 600; letter-spacing: -0.01em; }

/* Metric tiles */
[data-testid="stMetric"] {
  background: #ffffff; border: 1px solid #e6e6e1; border-radius: 12px; padding: 14px 16px;
}
[data-testid="stMetricLabel"] p { color: #52514e; font-size: 0.85rem; }

/* Feature / info cards */
.da-card {
  background: #ffffff; border: 1px solid #e6e6e1; border-radius: 12px;
  padding: 18px; height: 100%;
}
.da-card h4 { margin: 6px 0 4px; font-size: 1rem; font-weight: 600; color: #0b0b0b; }
.da-card p { margin: 0; color: #52514e; font-size: 0.9rem; line-height: 1.45; }
.da-icon {
  display: inline-flex; align-items: center; justify-content: center;
  width: 34px; height: 34px; border-radius: 9px; background: #e8f1fc; color: #1c5cab;
  font-family: 'Material Symbols Rounded'; font-size: 20px;
}
.da-eyebrow { color: #1c5cab; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.06em; text-transform: uppercase; }
.da-hero p { color: #52514e; font-size: 1.1rem; max-width: 720px; }
.da-step { display: flex; gap: 12px; margin-bottom: 14px; }
.da-step b { display: inline-flex; flex: 0 0 26px; height: 26px; border-radius: 50%; background: #2a78d6;
  color: #fff; align-items: center; justify-content: center; font-size: 0.8rem; }
.da-step span { color: #3a3a37; font-size: 0.95rem; }
.da-pill { display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 0.78rem;
  background: #eef6ee; color: #0a5c0a; border: 1px solid #cfe6cf; }
.da-pill.off { background: #f3f4f1; color: #52514e; border-color: #e3e3de; }

/* Chat */
[data-testid="stChatMessage"] { border-radius: 12px; }
</style>
"""


def inject_css() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


def card(icon: str, title: str, text: str) -> str:
    """HTML for a feature card. `icon` is a Material Symbols name, e.g. 'chat'."""
    return (f"<div class='da-card'><span class='da-icon'>{icon}</span>"
            f"<h4>{title}</h4><p>{text}</p></div>")
