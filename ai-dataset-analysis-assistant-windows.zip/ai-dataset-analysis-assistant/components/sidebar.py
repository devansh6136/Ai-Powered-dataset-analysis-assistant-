"""Sidebar shown on every page: current dataset, uploader and AI status."""

import streamlit as st

import config
from components import state


def render() -> None:
    with st.sidebar:
        st.markdown("#### Current dataset")
        df = state.get_df()
        if df is not None:
            st.markdown(f"**{st.session_state.filename}**  \n"
                        f"{df.shape[0]:,} rows × {df.shape[1]} columns")
            if st.session_state.cleaning_log:
                st.caption("Cleaned copy in use — see Dataset → Clean data")
            if st.button("Remove dataset", icon=":material/delete:", width="stretch"):
                state.clear_dataset()
                st.rerun()
        else:
            st.caption("No dataset loaded yet.")

        st.file_uploader("Upload CSV or Excel", type=["csv", "xlsx"], key="uploader_sidebar",
                         on_change=state.handle_upload, args=("uploader_sidebar",),
                         help=f"Up to {config.MAX_FILE_MB} MB. Files stay in memory and are never saved.")

        st.divider()
        ai, status = state.get_ai()
        ai_on = ai is not None
        pill = "da-pill" if ai_on else "da-pill off"
        st.markdown(f"<span class='{pill}'>{'AI on' if ai_on else 'Offline mode'}</span>",
                    unsafe_allow_html=True)
        st.caption(status)
        if ai_on:
            st.caption(f"AI requests this session: {st.session_state.ai_requests}"
                       f" / {config.MAX_AI_REQUESTS_PER_SESSION}")
