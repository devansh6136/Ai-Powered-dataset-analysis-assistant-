@echo off
REM ---------------------------------------------------------------------------
REM  AI-Powered Dataset Analysis Assistant - Windows launcher
REM    run.bat          start the app (sets everything up on the first run)
REM    run.bat check    test the AI provider configured in .env
REM    run.bat test     run the automated tests
REM ---------------------------------------------------------------------------
setlocal
cd /d "%~dp0"

REM A .venv copied from a Mac (it has a "bin" folder) does not work on Windows.
if exist ".venv\bin" (
    echo Removing the macOS .venv folder - it cannot run on Windows...
    rmdir /s /q ".venv"
)

if not exist ".venv\Scripts\python.exe" (
    echo First run: creating the Python environment in .venv ...
    py -3 -m venv .venv 2>nul || python -m venv .venv
    if not exist ".venv\Scripts\python.exe" (
        echo.
        echo ERROR: Python was not found. Install Python 3.10 or newer from https://www.python.org/downloads/
        echo        and tick "Add python.exe to PATH" during installation. Then run run.bat again.
        exit /b 1
    )
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 (
        echo ERROR: installing the requirements failed - check your internet connection and try again.
        exit /b 1
    )
    echo Environment ready.
)

if not exist ".env" (
    echo NOTE: no .env file found - the app will run in offline mode.
    echo       Create it with:  copy .env.example .env   and add your API key.
)

if /i "%~1"=="check" (
    ".venv\Scripts\python.exe" scripts\check_ai.py
    exit /b
)
if /i "%~1"=="test" (
    ".venv\Scripts\python.exe" -m pytest -q
    exit /b
)
".venv\Scripts\python.exe" -m streamlit run app.py %*
