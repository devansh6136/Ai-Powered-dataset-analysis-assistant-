"""Generate the demo datasets in sample_data/ (fixed seed, so results are reproducible).

Run:  python scripts/generate_sample_data.py
"""

from pathlib import Path

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent.parent / "sample_data"
rng = np.random.default_rng(42)


def sales_dataset(rows: int = 600) -> pd.DataFrame:
    products = {  # product: (category, base price in ₹)
        "Laptop": ("Computers", 55000), "Monitor": ("Computers", 14000),
        "Mobile": ("Phones", 18000), "Tablet": ("Phones", 22000),
        "Headphones": ("Accessories", 2500), "Smartwatch": ("Accessories", 6000),
    }
    regions = ["North", "South", "East", "West"]
    reps = ["Aarav", "Simran", "Kabir", "Meera", "Rohan", "Isha"]
    # More orders in the festive months (Oct–Dec)
    month_weights = np.array([7, 6, 7, 7, 8, 7, 8, 8, 9, 11, 12, 10], dtype=float)
    months = rng.choice(np.arange(1, 13), size=rows, p=month_weights / month_weights.sum())
    days = rng.integers(1, 29, size=rows)
    names = rng.choice(list(products), size=rows, p=[0.18, 0.12, 0.25, 0.12, 0.18, 0.15])

    records = []
    for i in range(rows):
        product = names[i]
        category, base = products[product]
        units = int(rng.integers(1, 6 if base > 10000 else 15))
        price = round(base * rng.uniform(0.9, 1.1), -1)
        discount = float(rng.choice([0, 0, 5, 10, 15]))
        revenue = round(units * price * (1 - discount / 100), 2)
        records.append({
            "Order ID": f"ORD-{1001 + i}",
            "Order Date": f"2025-{months[i]:02d}-{days[i]:02d}",
            "Region": rng.choice(regions, p=[0.3, 0.25, 0.2, 0.25]),
            "Product": product,
            "Category": category,
            "Sales Rep": rng.choice(reps),
            "Units Sold": units,
            "Unit Price": price,
            "Discount %": discount,
            "Revenue": revenue,
            "Customer Rating": int(rng.choice([3, 4, 4, 5, 5])) if rng.random() > 0.04 else None,
        })
    df = pd.DataFrame(records).sort_values("Order Date").reset_index(drop=True)
    # A few realistic data-quality issues for the demo: duplicates and blanks
    df = pd.concat([df, df.sample(4, random_state=1)], ignore_index=True)
    df.loc[df.sample(6, random_state=2).index, "Region"] = None
    return df


def student_dataset(rows: int = 300) -> pd.DataFrame:
    study = rng.uniform(1, 10, rows).round(1)
    attendance = rng.uniform(55, 100, rows).round(0)
    base = 25 + study * 4.5 + (attendance - 55) * 0.35
    return pd.DataFrame({
        "Student ID": [f"S{2001 + i}" for i in range(rows)],
        "Gender": rng.choice(["Female", "Male"], rows),
        "Branch": rng.choice(["CSE", "ECE", "ME", "CE", "IT"], rows, p=[0.3, 0.2, 0.2, 0.1, 0.2]),
        "Study Hours per Day": study,
        "Attendance %": attendance,
        "Maths": np.clip(base + rng.normal(0, 8, rows), 0, 100).round(0),
        "Physics": np.clip(base + rng.normal(-3, 9, rows), 0, 100).round(0),
        "Programming": np.clip(base + rng.normal(4, 10, rows), 0, 100).round(0),
    })


def employee_dataset(rows: int = 150) -> pd.DataFrame:
    dept = rng.choice(["Engineering", "Sales", "HR", "Finance", "Support"], rows, p=[0.35, 0.2, 0.1, 0.15, 0.2])
    experience = rng.integers(0, 21, rows)
    base = {"Engineering": 700000, "Sales": 500000, "HR": 450000, "Finance": 600000, "Support": 380000}
    salary = [round(base[d] * (1 + e * 0.06) * rng.uniform(0.85, 1.15), -3) for d, e in zip(dept, experience)]
    df = pd.DataFrame({
        "Employee ID": [f"E{301 + i}" for i in range(rows)],
        "Department": dept,
        "City": rng.choice(["Ludhiana", "Chandigarh", "Delhi", "Bengaluru", "Pune"], rows),
        "Joining Date": pd.to_datetime("2005-01-01") + pd.to_timedelta(rng.integers(0, 7300, rows), unit="D"),
        "Experience (Years)": experience,
        "Annual Salary": salary,
        "Performance Score": rng.choice([1, 2, 3, 4, 5], rows, p=[0.05, 0.15, 0.4, 0.3, 0.1]),
    })
    df.loc[df.sample(8, random_state=3).index, "Performance Score"] = None
    return df


def messy_dataset() -> str:
    """A deliberately messy CSV for testing validation and cleaning."""
    return (
        " Product Name ,Price,price,,Order Date,Quantity\n"
        "Pen,\"1,200\",10,,2025-01-05,3\n"
        "  Notebook ,850,12,,2025-01-07,\n"
        "Pen,\"1,200\",10,,2025-01-05,3\n"
        "Marker,\"2,450\",15,,not a date,7\n"
        ",300,8,,2025-02-11,2\n"
        "Stapler,\"1,100\",9,,2025-02-14,1\n"
    )


if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    sales_dataset().to_csv(OUT / "sales_dataset.csv", index=False)
    student_dataset().to_csv(OUT / "student_performance.csv", index=False)
    employee_dataset().to_excel(OUT / "employees.xlsx", index=False)
    (OUT / "messy_dataset.csv").write_text(messy_dataset(), encoding="utf-8")
    print("Wrote:", ", ".join(sorted(p.name for p in OUT.iterdir())))
