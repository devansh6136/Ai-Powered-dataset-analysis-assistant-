"""Check that the AI provider in .env works, end to end.

Run:  .venv/bin/python scripts/check_ai.py

It asks a few questions about sample_data/sales_dataset.csv through the same
pipeline the app uses (AI plan -> validation -> Pandas -> AI explanation).
Each question makes 2 small API calls; questions are spaced out to stay within
free-tier rate limits.
"""

import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import config  # noqa: E402  (loads .env)
from services.ai_service import AIService, get_provider  # noqa: E402
from services.chat_engine import answer_question  # noqa: E402
from services.dataset_loader import load_dataset  # noqa: E402

QUESTIONS = [
    "Which product has the highest revenue?",
    "What is the total revenue in the North region?",
    "Now show that by product as a pie chart",
    "What will sales be next year?",          # should be declined, not answered
]


def main() -> int:
    provider, status = get_provider()
    print(f"Provider setting: AI_PROVIDER={config.AI_PROVIDER} -> {status}")
    if provider is None:
        print("No AI provider configured. Edit .env (see .env.example).")
        return 1

    data = (ROOT / "sample_data" / "sales_dataset.csv").read_bytes()
    df = load_dataset(data, "sales_dataset.csv").df
    ai = AIService(provider)
    previous_plan, failures = None, 0

    for i, question in enumerate(QUESTIONS):
        if i:
            time.sleep(12)  # free tiers allow only a few requests per minute
        start = time.time()
        answer = answer_question(question, df, ai, previous_plan)
        if answer.kind == "answer":
            previous_plan = answer.plan
        if answer.kind == "error":
            failures += 1
        plan = {k: v for k, v in (answer.plan or {}).items() if v not in (None, [], False)}
        print(f"\nQ: {question}   [{answer.kind}, {time.time() - start:.1f}s]")
        print(f"   plan:   {json.dumps(plan)}")
        print(f"   answer: {answer.text[:300]}")
        for warning in answer.warnings:
            print(f"   warning: {warning}")
            failures += 1

    print("\nRESULT:", "AI is working." if failures == 0 else f"{failures} problem(s) — see above.")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
