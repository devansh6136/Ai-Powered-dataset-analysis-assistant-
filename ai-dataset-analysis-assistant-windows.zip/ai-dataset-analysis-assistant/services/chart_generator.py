"""Plotly charts with one consistent, colour-blind-safe style.

Charts are only ever drawn from real DataFrame columns or from tables produced
by analysis_engine — never from made-up data.
"""

from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go

from services.analysis_engine import AnalysisError, column_kind

# Categorical palette (fixed order — validated for colour-vision deficiency).
PALETTE = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
OTHER_GRAY = "#a8a79f"
SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK_SECONDARY = "#52514e"
GRID = "#e8e8e3"
# Diverging blue ↔ gray ↔ red, used for correlations (-1 … +1)
DIVERGING = [[0.0, "#c83b3b"], [0.25, "#ec9a8f"], [0.5, "#f0efec"], [0.75, "#86b6ef"], [1.0, "#1c5cab"]]

CHART_TYPES = ("bar", "line", "pie", "histogram", "scatter", "box", "heatmap")
MAX_BARS = 25            # more categories than this become unreadable
MAX_PIE_SLICES = 6       # the rest are folded into "Other"
MAX_SCATTER_POINTS = 5000


def style(fig: go.Figure, title: str, x_title: str | None = None,
          y_title: str | None = None, height: int = 420) -> go.Figure:
    """Apply the shared look to any figure."""
    fig.update_layout(
        title=dict(text=title, font=dict(size=16, color=INK), x=0, xanchor="left"),
        font=dict(family="Inter, -apple-system, Segoe UI, sans-serif", size=13, color=INK_SECONDARY),
        paper_bgcolor=SURFACE,
        plot_bgcolor=SURFACE,
        height=height,
        margin=dict(l=10, r=10, t=56, b=10),
        hoverlabel=dict(bgcolor="white", font_size=13, font_color=INK),
        legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="right", x=1),
        colorway=PALETTE,
    )
    fig.update_xaxes(title=dict(text=x_title or ""), gridcolor=GRID, linecolor=GRID,
                     zeroline=False, automargin=True)
    fig.update_yaxes(title=dict(text=y_title or ""), gridcolor=GRID, linecolor=GRID,
                     zeroline=False, automargin=True)
    return fig


def bar_chart(table: pd.DataFrame, x: str, y: str, title: str) -> go.Figure:
    """Bars for category comparisons. Long lists flip to horizontal for readability."""
    data = table.head(MAX_BARS)
    labels = data[x].astype(str)
    horizontal = len(data) > 8 or labels.str.len().max() > 14
    if horizontal:
        data = data.iloc[::-1]  # biggest bar on top
        trace = go.Bar(x=data[y], y=data[x].astype(str), orientation="h",
                       marker=dict(color=PALETTE[0], cornerradius=4),
                       hovertemplate=f"<b>%{{y}}</b><br>{y}: %{{x:,.2f}}<extra></extra>")
    else:
        trace = go.Bar(x=data[x].astype(str), y=data[y],
                       marker=dict(color=PALETTE[0], cornerradius=4),
                       hovertemplate=f"<b>%{{x}}</b><br>{y}: %{{y:,.2f}}<extra></extra>")
    fig = go.Figure(trace)
    fig.update_layout(bargap=0.45)
    if len(table) > MAX_BARS:
        title += f" (top {MAX_BARS} of {len(table)})"
    return style(fig, title, y if horizontal else x, x if horizontal else y,
                 height=max(420, 26 * len(data)) if horizontal else 420)


def line_chart(table: pd.DataFrame, x: str, y: str, title: str) -> go.Figure:
    mode = "lines+markers" if len(table) <= 40 else "lines"
    fig = go.Figure(go.Scatter(
        x=table[x], y=table[y], mode=mode,
        line=dict(color=PALETTE[0], width=2), marker=dict(size=8),
        hovertemplate=f"<b>%{{x}}</b><br>{y}: %{{y:,.2f}}<extra></extra>",
    ))
    fig.update_layout(hovermode="x unified")
    return style(fig, title, x, y)


def pie_chart(table: pd.DataFrame, names: str, values: str, title: str) -> go.Figure:
    if (table[values] < 0).any():
        raise AnalysisError("A pie chart can't show negative values — try a bar chart instead.")
    data = table.sort_values(values, ascending=False)
    if len(data) > MAX_PIE_SLICES:
        top = data.head(MAX_PIE_SLICES - 1)
        other = pd.DataFrame({names: ["Other"], values: [data[values].iloc[MAX_PIE_SLICES - 1:].sum()]})
        data = pd.concat([top, other], ignore_index=True)
    colors = PALETTE[: len(data)]
    if data[names].iloc[-1] == "Other":
        colors[-1] = OTHER_GRAY
    fig = go.Figure(go.Pie(
        labels=data[names].astype(str), values=data[values], hole=0.45, sort=False,
        marker=dict(colors=colors, line=dict(color=SURFACE, width=2)),
        textinfo="percent", hovertemplate="<b>%{label}</b><br>%{value:,.2f} (%{percent})<extra></extra>",
    ))
    return style(fig, title)


def histogram(df: pd.DataFrame, column: str, title: str | None = None) -> go.Figure:
    _require_numeric(df, column)
    fig = go.Figure(go.Histogram(
        x=df[column].dropna(), nbinsx=30,
        marker=dict(color=PALETTE[0], line=dict(color=SURFACE, width=1)),
        hovertemplate=f"{column}: %{{x}}<br>Rows: %{{y}}<extra></extra>",
    ))
    return style(fig, title or f"Distribution of {column}", column, "Number of rows")


def scatter_plot(df: pd.DataFrame, x: str, y: str, color: str | None = None,
                 title: str | None = None) -> go.Figure:
    _require_numeric(df, x)
    _require_numeric(df, y)
    data = df.dropna(subset=[x, y])
    note = ""
    if len(data) > MAX_SCATTER_POINTS:
        data = data.sample(MAX_SCATTER_POINTS, random_state=0)
        note = f" (random sample of {MAX_SCATTER_POINTS:,} points)"
    fig = go.Figure()
    if color:
        # At most 3 colours stay distinguishable on a scatter; the rest become "Other".
        top = data[color].value_counts().head(3).index
        groups = [(str(v), data[data[color] == v], PALETTE[i]) for i, v in enumerate(top)]
        rest = data[~data[color].isin(top)]
        if len(rest):
            groups.append(("Other", rest, OTHER_GRAY))
        for name, part, c in groups:
            fig.add_trace(go.Scatter(x=part[x], y=part[y], mode="markers", name=name,
                                     marker=dict(color=c, size=8, opacity=0.75,
                                                 line=dict(color=SURFACE, width=1))))
    else:
        fig.add_trace(go.Scatter(x=data[x], y=data[y], mode="markers",
                                 marker=dict(color=PALETTE[0], size=8, opacity=0.7,
                                             line=dict(color=SURFACE, width=1)),
                                 hovertemplate=f"{x}: %{{x:,.2f}}<br>{y}: %{{y:,.2f}}<extra></extra>"))
    return style(fig, (title or f"{y} vs {x}") + note, x, y)


def box_plot(df: pd.DataFrame, column: str, group_by: str | None = None,
             title: str | None = None) -> go.Figure:
    _require_numeric(df, column)
    fig = go.Figure()
    if group_by:
        top = df[group_by].value_counts().head(8).index
        for i, value in enumerate(top):
            fig.add_trace(go.Box(y=df.loc[df[group_by] == value, column], name=str(value),
                                 marker_color=PALETTE[i], boxmean=True))
        fig.update_layout(showlegend=False)
    else:
        fig.add_trace(go.Box(y=df[column], name=column, marker_color=PALETTE[0], boxmean=True))
    return style(fig, title or f"Spread of {column}" + (f" by {group_by}" if group_by else ""),
                 group_by, column)


def correlation_heatmap(corr: pd.DataFrame, title: str = "Correlation between numeric columns") -> go.Figure:
    fig = go.Figure(go.Heatmap(
        z=corr.values, x=list(corr.columns), y=list(corr.index),
        zmin=-1, zmax=1, colorscale=DIVERGING,
        text=corr.round(2).values, texttemplate="%{text}",
        hovertemplate="%{y} ↔ %{x}<br>r = %{z:.3f}<extra></extra>",
        colorbar=dict(title=dict(text="r"), thickness=12),
    ))
    fig.update_yaxes(autorange="reversed")
    return style(fig, title, height=max(420, 60 * len(corr)))


def _require_numeric(df: pd.DataFrame, column: str) -> None:
    if column_kind(df[column]) != "numeric":
        raise AnalysisError(f"'{column}' must be numeric for this chart.")
