"""The Analysis Controller: question in, verified answer out.

    1. plan    — AI (or offline rule matcher) maps the question to a plan
    2. check   — validate_plan() checks columns, types and parameters
    3. compute — execute_plan() runs Pandas on the real data
    4. explain — AI turns the verified numbers into plain English
                 (offline: the deterministic summary is shown as-is)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

import pandas as pd

import config
from services.ai_service import AIError, AIService
from services.analysis_engine import AnalysisError
from services.query_planner import (AnalysisResult, PlanError, execute_plan, plan_to_pandas,
                                    validate_plan)
from services.rule_planner import plan_from_rules


@dataclass
class ChatAnswer:
    text: str
    kind: str = "answer"          # "answer" | "clarify" | "error"
    source: str = ""              # who wrote the text (AI model or rule-based)
    plan: dict | None = None
    code: str = ""
    result: AnalysisResult | None = None
    warnings: list[str] = field(default_factory=list)
    ai_calls: int = 0

    @property
    def table(self) -> pd.DataFrame | None:
        return self.result.table if self.result else None

    @property
    def chart(self) -> Any:
        return self.result.chart if self.result else None


def answer_question(question: str, df: pd.DataFrame, ai: AIService | None,
                    previous_plan: dict | None = None,
                    on_step: Callable[[str], None] | None = None) -> ChatAnswer:
    """Answer one question. `on_step(message)` is called before each stage (for progress display)."""
    step = on_step or (lambda message: None)
    question = (question or "").strip()
    if not question:
        return ChatAnswer("Please type a question.", kind="error")
    if len(question) > config.MAX_QUESTION_CHARS:
        return ChatAnswer(f"Please keep questions under {config.MAX_QUESTION_CHARS} characters.", kind="error")

    ai_calls = 0
    warnings: list[str] = []
    # 1. Plan
    if ai:
        step(f"Understanding your question ({ai.label})…")
        try:
            raw_plan = ai.plan_question(question, df, previous_plan)
            ai_calls += 1
            source = ai.label
        except AIError as exc:
            # AI down or out of quota: try the offline rules so simple questions still get answered.
            ai_calls += 1
            raw_plan = plan_from_rules(question, df)
            if raw_plan["operation"] == "clarify":
                return ChatAnswer(f"⚠️ {exc}", kind="error", ai_calls=ai_calls)
            source = "Built-in rule matcher (AI unavailable)"
            warnings.append(f"AI unavailable: {exc} Answered with the built-in rule matcher instead.")
            ai = None  # skip the AI explanation as well
    else:
        raw_plan = plan_from_rules(question, df)
        source = "Built-in rule matcher (no AI configured)"

    # 2. Validate
    try:
        plan = validate_plan(raw_plan, df)
    except PlanError as exc:
        return ChatAnswer(str(exc), kind="clarify", source=source, plan=raw_plan, ai_calls=ai_calls)

    if plan["operation"] in ("clarify", "unsupported"):
        return ChatAnswer(plan["message"], kind="clarify", source=source, plan=plan, ai_calls=ai_calls)

    # 3. Compute (Pandas — the only place numbers come from)
    step("Calculating the answer with Pandas…")
    try:
        result = execute_plan(plan, df)
    except (AnalysisError, PlanError) as exc:
        return ChatAnswer(str(exc), kind="clarify", source=source, plan=plan, ai_calls=ai_calls)
    except Exception as exc:  # unexpected data shape — report briefly, never crash the UI
        return ChatAnswer(f"Sorry, that calculation failed ({type(exc).__name__}). Try rephrasing.",
                          kind="error", source=source, plan=plan, ai_calls=ai_calls)

    answer = ChatAnswer(result.summary, source=source, plan=plan, code=plan_to_pandas(plan),
                        result=result, warnings=warnings, ai_calls=ai_calls)

    # 4. Explain (optional: AI_EXPLAIN_ANSWERS=false skips it — half the wait and half the quota)
    if ai and config.AI_EXPLAIN_ANSWERS:
        step("Writing the explanation…")
        try:
            answer.text = ai.explain_result(question, result)
            answer.ai_calls += 1
        except AIError as exc:
            answer.warnings.append(f"AI explanation unavailable ({exc}); showing the calculated summary.")
    return answer
