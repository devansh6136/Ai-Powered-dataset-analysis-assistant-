"""Build a self-contained HTML analysis report.

The report contains only calculated statistics, findings, the user's chosen
charts and (if generated) the AI-written summary — never API keys or secrets.
"""

from __future__ import annotations

import html
import re
from datetime import datetime

import pandas as pd

from services import analysis_engine as ae
from services.insights import Finding

CSS = """
body{font-family:Inter,-apple-system,Segoe UI,Roboto,sans-serif;color:#0b0b0b;background:#f9f9f7;margin:0}
main{max-width:980px;margin:0 auto;padding:32px 20px 60px}
h1{font-size:26px;margin:0 0 4px}h2{font-size:19px;margin:36px 0 12px;border-bottom:1px solid #e3e3de;padding-bottom:6px}
.muted{color:#52514e;font-size:14px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.card{background:#fff;border:1px solid #e3e3de;border-radius:10px;padding:14px}
.card b{display:block;font-size:22px;margin-top:4px;color:#0b0b0b}
table{border-collapse:collapse;width:100%;font-size:13px;background:#fff}
th,td{border:1px solid #e3e3de;padding:6px 8px;text-align:left}th{background:#f3f4f1}
.table-wrap{overflow-x:auto}
.ai{background:#fff;border:1px solid #cde2fb;border-left:4px solid #2a78d6;border-radius:8px;padding:12px 16px}
li{margin:4px 0}.chart{background:#fff;border:1px solid #e3e3de;border-radius:10px;margin:14px 0;padding:6px}
"""


def _table(df: pd.DataFrame) -> str:
    if df is None or df.empty:
        return "<p class='muted'>Nothing to show.</p>"
    return f"<div class='table-wrap'>{df.to_html(index=False, escape=True, border=0)}</div>"


def _markdown_lite(text: str) -> str:
    """Tiny, safe markdown: escape everything, then allow **bold** and '- ' bullets."""
    out, in_list = [], False
    for line in html.escape(text).splitlines():
        line = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", line.strip())
        if line.startswith(("- ", "* ", "• ")):
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append(f"<li>{line[2:]}</li>")
            continue
        if in_list:
            out.append("</ul>")
            in_list = False
        if line:
            out.append(f"<p>{line}</p>")
    if in_list:
        out.append("</ul>")
    return "\n".join(out)


def build_html_report(dataset_name: str, df: pd.DataFrame, findings: list[Finding],
                      charts: list[dict], ai_summary: str | None = None,
                      ai_label: str | None = None, change_log: list[str] | None = None) -> str:
    o = ae.dataset_overview(df)
    name = html.escape(dataset_name)
    generated = datetime.now().strftime("%d %b %Y, %H:%M")

    cards = "".join(f"<div class='card'><span class='muted'>{label}</span><b>{value}</b></div>" for label, value in [
        ("Rows", f"{o['rows']:,}"), ("Columns", o["columns"]), ("Numeric columns", o["numeric_columns"]),
        ("Missing cells", f"{o['missing_cells']:,} ({o['missing_percent']}%)"),
        ("Duplicate rows", f"{o['duplicate_rows']:,}"),
    ])

    grouped: dict[str, list[str]] = {}
    for f in findings:
        grouped.setdefault(f.category, []).append(html.escape(f.text))
    findings_html = "".join(f"<h3>{html.escape(cat)}</h3><ul>{''.join(f'<li>{t}</li>' for t in items)}</ul>"
                            for cat, items in grouped.items())

    ai_html = ""
    if ai_summary:
        ai_html = (f"<h2>AI-written summary</h2><div class='ai'>{_markdown_lite(ai_summary)}"
                   f"<p class='muted'>Written by {html.escape(ai_label or 'an AI model')} from the "
                   "statistics in this report. Verify important conclusions.</p></div>")

    charts_html = ""
    for i, chart in enumerate(charts):
        fig_html = chart["figure"].to_html(full_html=False, include_plotlyjs="cdn" if i == 0 else False)
        charts_html += f"<div class='chart'>{fig_html}</div>"
    if charts_html:
        charts_html = "<h2>Charts</h2>" + charts_html

    changes = ""
    if change_log:
        changes = "<h2>Changes applied to the data</h2><ul>" + "".join(
            f"<li>{html.escape(c)}</li>" for c in change_log) + "</ul>"

    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Analysis report – {name}</title><style>{CSS}</style></head>
<body><main>
<h1>Dataset analysis report</h1>
<p class="muted">{name} · generated {generated} · AI-Powered Dataset Analysis Assistant</p>
<h2>Summary</h2><div class="grid">{cards}</div>
{ai_html}
<h2>Key findings (calculated)</h2>{findings_html}
{charts_html}
<h2>Columns</h2>{_table(ae.column_info(df))}
<h2>Numeric statistics</h2>{_table(ae.numeric_summary(df))}
<h2>Text / category columns</h2>{_table(ae.categorical_summary(df))}
<h2>Missing values</h2>{_table(ae.missing_values(df))}
{changes}
<p class="muted" style="margin-top:40px">All numbers were calculated with Python/Pandas from the uploaded data.</p>
</main></body></html>"""
