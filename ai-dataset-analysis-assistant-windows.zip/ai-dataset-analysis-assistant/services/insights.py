"""Find noteworthy patterns with plain statistics (no AI involved).

Each finding is a sentence containing real, calculated numbers. The AI can
later rewrite these into a narrative, but it cannot add new facts.
"""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from services import analysis_engine as ae

PREFERRED_MEASURE_WORDS = ("revenue", "sales", "amount", "profit", "total", "price", "salary",
                           "income", "cost", "score", "marks", "quantity", "units")


@dataclass
class Finding:
    category: str   # "Overview" | "Top & bottom" | "Trend" | "Relationship" | "Unusual values" | "Data quality"
    text: str


def pick_main_measure(df: pd.DataFrame) -> str | None:
    measures = ae.measure_columns(df)
    for word in PREFERRED_MEASURE_WORDS:
        for col in measures:
            if word in col.lower():
                return col
    return measures[0] if measures else None


def compute_findings(df: pd.DataFrame) -> list[Finding]:
    findings: list[Finding] = []
    o = ae.dataset_overview(df)
    findings.append(Finding("Overview", f"The dataset has {o['rows']:,} rows and {o['columns']} columns "
                                        f"({o['numeric_columns']} numeric, {o['categorical_columns']} "
                                        f"text/category, {o['datetime_columns']} date)."))
    measure = pick_main_measure(df)

    # Top & bottom categories for the main measure
    if measure:
        stats = ae.numeric_column_stats(df, measure)
        findings.append(Finding("Overview", f"{measure}: total {ae.fmt(stats['sum'])}, average "
                                            f"{ae.fmt(stats['mean'])}, median {ae.fmt(stats['median'])}, "
                                            f"range {ae.fmt(stats['min'])} to {ae.fmt(stats['max'])}."))
        for group in ae.grouping_columns(df, max_unique=30)[:3]:
            table = ae.group_aggregate(df, group, measure, "sum")
            if len(table) < 2:
                continue
            label = table.columns[1]
            total = table[label].sum()
            top, bottom = table.iloc[0], table.iloc[-1]
            share = f", {top[label] / total * 100:.1f}% of the total" if total > 0 else ""
            findings.append(Finding("Top & bottom",
                                    f"By {group}, '{top[group]}' has the highest total {measure} "
                                    f"({ae.fmt(top[label])}{share}); '{bottom[group]}' has the lowest "
                                    f"({ae.fmt(bottom[label])})."))

    # Trend over time
    dates = ae.column_types(df)["datetime"]
    if dates and measure:
        trend = ae.time_trend(df, dates[0], measure, "sum", "M")
        if len(trend) >= 3:
            label = trend.columns[1]
            best = trend.loc[trend[label].idxmax()]
            worst = trend.loc[trend[label].idxmin()]
            first, last = trend.iloc[0], trend.iloc[-1]
            text = (f"Monthly total {measure} peaked in {best['Period']:%B %Y} ({ae.fmt(best[label])}) "
                    f"and was lowest in {worst['Period']:%B %Y} ({ae.fmt(worst[label])}).")
            if first[label]:
                change = (last[label] - first[label]) / abs(first[label]) * 100
                text += (f" The last month ({last['Period']:%b %Y}) was {change:+.1f}% versus the first "
                         f"({first['Period']:%b %Y}).")
            findings.append(Finding("Trend", text))

    # Relationships between numeric columns
    for _, row in ae.strongest_correlations(df, k=3, min_abs=0.5).iterrows():
        findings.append(Finding("Relationship",
                                f"{row['Column A']} and {row['Column B']} have a "
                                f"{ae.describe_correlation(row['Correlation'])} correlation "
                                f"(r = {row['Correlation']:.2f}). This shows association, not cause."))

    # Unusual values
    outlier_rows = []
    for col in ae.measure_columns(df):
        info = ae.outliers_iqr(df, col)
        if info["outlier_count"]:
            outlier_rows.append(info)
    for info in sorted(outlier_rows, key=lambda i: -i["outlier_count"])[:3]:
        findings.append(Finding("Unusual values",
                                f"{info['outlier_count']:,} rows ({info['outlier_percent']}%) have unusual "
                                f"{info['column']} values ({info['unusual_when']}, by the 1.5×IQR rule)."))

    findings.extend(data_quality_findings(df))
    return findings


def data_quality_findings(df: pd.DataFrame) -> list[Finding]:
    out: list[Finding] = []
    missing = ae.missing_values(df)
    if missing.empty:
        out.append(Finding("Data quality", "No missing values were found."))
    else:
        worst = ", ".join(f"{r['Column']} ({r['Missing %']}%)" for _, r in missing.head(3).iterrows())
        out.append(Finding("Data quality", f"{int(missing['Missing'].sum()):,} missing cells in "
                                           f"{len(missing)} column(s). Most affected: {worst}."))
    dupes = int(df.duplicated().sum())
    out.append(Finding("Data quality", f"{dupes:,} duplicate rows found." if dupes
                       else "No duplicate rows were found."))
    empty_cols = [c for c in df.columns if df[c].isna().all()]
    if empty_cols:
        out.append(Finding("Data quality", f"Completely empty column(s): {', '.join(empty_cols)}."))
    constant = [c for c in df.columns if df[c].nunique(dropna=True) == 1]
    if constant:
        out.append(Finding("Data quality", f"Column(s) with a single repeated value: {', '.join(constant[:5])}."))
    return out
