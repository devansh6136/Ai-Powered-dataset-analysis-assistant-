"""All dataset calculations, written as small reusable Pandas functions.

Every number the app shows (and every number the AI explains) comes from a
function in this file. The AI never calculates anything itself.
"""

from __future__ import annotations

import pandas as pd

NUMERIC_AGGREGATIONS = ("sum", "mean", "median", "min", "max", "std")
ALL_AGGREGATIONS = NUMERIC_AGGREGATIONS + ("count", "nunique")

AGGREGATION_LABELS = {
    "sum": "Total",
    "mean": "Average",
    "median": "Median",
    "min": "Minimum",
    "max": "Maximum",
    "std": "Std. deviation of",
    "count": "Number of rows",
    "nunique": "Unique values of",
}

FILTER_OPERATORS = ("==", "!=", ">", ">=", "<", "<=", "contains")

# Period codes accepted by Series.dt.to_period
TIME_FREQUENCIES = {"D": "day", "W": "week", "M": "month", "Q": "quarter", "Y": "year"}


class AnalysisError(Exception):
    """Raised when an analysis can't run on this data (shown to the user)."""


# --------------------------------------------------------------------------
# Column typing
# --------------------------------------------------------------------------

def column_kind(series: pd.Series) -> str:
    """Classify a column as 'numeric', 'datetime', 'boolean' or 'categorical'."""
    if pd.api.types.is_bool_dtype(series):
        return "boolean"
    if pd.api.types.is_numeric_dtype(series):
        return "numeric"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime"
    return "categorical"


def column_types(df: pd.DataFrame) -> dict[str, list[str]]:
    groups: dict[str, list[str]] = {"numeric": [], "categorical": [], "datetime": [], "boolean": []}
    for col in df.columns:
        groups[column_kind(df[col])].append(col)
    return groups


def is_identifier(df: pd.DataFrame, column: str) -> bool:
    """Columns like 'Order ID' are unique per row and meaningless to sum or group."""
    series = df[column]
    name = column.lower().replace("_", " ")
    looks_like_id = name == "id" or name.endswith(" id") or name.startswith("id ")
    return looks_like_id or (len(df) > 20 and series.nunique(dropna=True) == len(df)
                             and column_kind(series) != "numeric")


def measure_columns(df: pd.DataFrame) -> list[str]:
    """Numeric columns worth summing/averaging (identifiers excluded)."""
    return [c for c in column_types(df)["numeric"] if not is_identifier(df, c)]


def grouping_columns(df: pd.DataFrame, max_unique: int = 50) -> list[str]:
    """Text/boolean columns with a manageable number of groups."""
    types = column_types(df)
    candidates = types["categorical"] + types["boolean"]
    return [c for c in candidates
            if 2 <= df[c].nunique(dropna=True) <= max_unique and not is_identifier(df, c)]


# --------------------------------------------------------------------------
# Dataset profile
# --------------------------------------------------------------------------

def dataset_overview(df: pd.DataFrame) -> dict:
    types = column_types(df)
    total_cells = df.shape[0] * df.shape[1]
    missing = int(df.isna().sum().sum())
    return {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "numeric_columns": len(types["numeric"]),
        "categorical_columns": len(types["categorical"]) + len(types["boolean"]),
        "datetime_columns": len(types["datetime"]),
        "missing_cells": missing,
        "missing_percent": round(missing / total_cells * 100, 2) if total_cells else 0.0,
        "duplicate_rows": int(df.duplicated().sum()),
        "memory_mb": round(df.memory_usage(deep=True).sum() / 1024 ** 2, 2),
    }


FRIENDLY_KIND = {"numeric": "Number", "categorical": "Text / category",
                 "datetime": "Date / time", "boolean": "True / false"}


def column_info(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for col in df.columns:
        s = df[col]
        non_null = s.dropna()
        rows.append({
            "Column": col,
            "Type": FRIENDLY_KIND[column_kind(s)],
            "Pandas dtype": str(s.dtype),
            "Non-missing": int(s.notna().sum()),
            "Missing": int(s.isna().sum()),
            "Missing %": round(s.isna().mean() * 100, 2),
            "Unique values": int(s.nunique(dropna=True)),
            "Example": str(non_null.iloc[0])[:40] if len(non_null) else "",
        })
    return pd.DataFrame(rows)


def numeric_summary(df: pd.DataFrame) -> pd.DataFrame:
    cols = column_types(df)["numeric"]
    if not cols:
        return pd.DataFrame()
    desc = df[cols].describe().T
    desc.insert(0, "missing", df[cols].isna().sum())
    desc = desc.rename(columns={"25%": "q1 (25%)", "50%": "median", "75%": "q3 (75%)"})
    return desc.round(2).reset_index().rename(columns={"index": "Column"})


def categorical_summary(df: pd.DataFrame) -> pd.DataFrame:
    types = column_types(df)
    rows = []
    for col in types["categorical"] + types["boolean"]:
        counts = df[col].value_counts(dropna=True)
        rows.append({
            "Column": col,
            "Unique values": int(df[col].nunique(dropna=True)),
            "Most common": str(counts.index[0]) if len(counts) else "",
            "Most common count": int(counts.iloc[0]) if len(counts) else 0,
            "Missing": int(df[col].isna().sum()),
        })
    return pd.DataFrame(rows)


def missing_values(df: pd.DataFrame) -> pd.DataFrame:
    counts = df.isna().sum()
    counts = counts[counts > 0].sort_values(ascending=False)
    return pd.DataFrame({
        "Column": counts.index,
        "Missing": counts.values.astype(int),
        "Missing %": (counts.values / len(df) * 100).round(2) if len(df) else 0,
    })


def duplicate_rows(df: pd.DataFrame) -> tuple[int, pd.DataFrame]:
    """Return (number of extra duplicate rows, all rows involved in duplication)."""
    count = int(df.duplicated().sum())
    involved = df[df.duplicated(keep=False)]
    return count, involved


# --------------------------------------------------------------------------
# Row operations
# --------------------------------------------------------------------------

def filter_rows(df: pd.DataFrame, filters: list[dict]) -> tuple[pd.DataFrame, list[str]]:
    """Apply validated filters ({column, operator, value}). Returns (rows, descriptions)."""
    descriptions = []
    mask = pd.Series(True, index=df.index)
    for f in filters or []:
        col, op, value = f["column"], f["operator"], f["value"]
        if op not in FILTER_OPERATORS:
            raise AnalysisError(f"Unsupported filter operator '{op}'.")
        series = df[col]
        kind = column_kind(series)

        if kind == "numeric":
            try:
                value = float(value)
            except (TypeError, ValueError):
                raise AnalysisError(f"'{col}' is numeric, so the filter value must be a number.")
            target = series
        elif kind == "datetime":
            try:
                value = pd.Timestamp(str(value))
            except (TypeError, ValueError):
                raise AnalysisError(f"'{col}' holds dates; '{value}' is not a valid date.")
            target = series
        elif kind == "boolean":
            value = str(value).strip().lower() in ("true", "yes", "1", "y")
            target = series
        else:  # text: case-insensitive comparison
            target = series.astype("string").str.strip().str.lower()
            value = str(value).strip().lower()
            if op in (">", ">=", "<", "<="):
                raise AnalysisError(f"'{col}' is text; use 'equals', 'not equals' or 'contains'.")

        if op == "contains":
            condition = target.astype("string").str.contains(str(value), case=False, regex=False)
        else:
            condition = {
                "==": target == value, "!=": target != value,
                ">": target > value, ">=": target >= value,
                "<": target < value, "<=": target <= value,
            }[op]
        mask &= condition.fillna(False).astype(bool)
        descriptions.append(f"{col} {op} {f['value']}")
    return df[mask], descriptions


def sort_rows(df: pd.DataFrame, column: str, ascending: bool = False, n: int = 10) -> pd.DataFrame:
    return df.sort_values(column, ascending=ascending, na_position="last").head(n)


# --------------------------------------------------------------------------
# Aggregations
# --------------------------------------------------------------------------

def aggregate_label(aggregation: str, value_column: str | None) -> str:
    if aggregation == "count" or not value_column:
        return "Number of rows"
    return f"{AGGREGATION_LABELS[aggregation]} {value_column}"


def aggregate_column(df: pd.DataFrame, column: str, aggregation: str) -> float:
    series = df[column]
    if aggregation in NUMERIC_AGGREGATIONS and column_kind(series) != "numeric":
        raise AnalysisError(f"Can't calculate the {aggregation} of '{column}' because it isn't numeric.")
    if aggregation == "count":
        return int(series.notna().sum())
    if aggregation == "nunique":
        return int(series.nunique(dropna=True))
    value = getattr(series, aggregation)()
    return float(value) if pd.notna(value) else float("nan")


def group_aggregate(df: pd.DataFrame, group_by: str, value_column: str | None,
                    aggregation: str = "sum", ascending: bool = False,
                    n: int | None = None) -> pd.DataFrame:
    """e.g. total Revenue per Product, sorted from highest to lowest."""
    if aggregation not in ALL_AGGREGATIONS:
        raise AnalysisError(f"Unsupported aggregation '{aggregation}'.")
    label = aggregate_label(aggregation, value_column)
    grouped = df.groupby(group_by, dropna=True, observed=True)

    if aggregation == "count" or not value_column:
        result = grouped.size()
    else:
        if aggregation in NUMERIC_AGGREGATIONS and column_kind(df[value_column]) != "numeric":
            raise AnalysisError(f"'{value_column}' isn't numeric, so it can't be {aggregation}-aggregated.")
        result = grouped[value_column].agg(aggregation)

    table = result.rename(label).reset_index().sort_values(label, ascending=ascending)
    if n:
        table = table.head(n)
    return table.reset_index(drop=True)


def value_counts(df: pd.DataFrame, column: str, n: int | None = 10) -> pd.DataFrame:
    counts = df[column].value_counts(dropna=True)
    table = pd.DataFrame({column: counts.index, "Count": counts.values.astype(int)})
    table["Share %"] = (table["Count"] / max(len(df), 1) * 100).round(2)
    return table.head(n) if n else table


def time_trend(df: pd.DataFrame, date_column: str, value_column: str | None,
               aggregation: str = "sum", freq: str = "M") -> pd.DataFrame:
    """Aggregate a value per day / week / month / quarter / year."""
    if column_kind(df[date_column]) != "datetime":
        raise AnalysisError(f"'{date_column}' is not a date column.")
    if freq not in TIME_FREQUENCIES:
        raise AnalysisError(f"Unsupported time frequency '{freq}'.")
    data = df.dropna(subset=[date_column])
    period = data[date_column].dt.to_period(freq).dt.start_time.rename("Period")
    label = aggregate_label(aggregation, value_column)
    if aggregation == "count" or not value_column:
        result = data.groupby(period).size()
    else:
        result = data.groupby(period)[value_column].agg(aggregation)
    return result.rename(label).reset_index().sort_values("Period").reset_index(drop=True)


def period_label(value, freq: str) -> str:
    """Readable name for a period start, e.g. ('2025-12-01', 'M') -> 'Dec 2025'."""
    ts = pd.Timestamp(value)
    return {"D": ts.strftime("%d %b %Y"), "W": "week of " + ts.strftime("%d %b %Y"),
            "M": ts.strftime("%b %Y"), "Q": f"Q{ts.quarter} {ts.year}", "Y": str(ts.year)}[freq]


# --------------------------------------------------------------------------
# Relationships and unusual values
# --------------------------------------------------------------------------

def correlation_matrix(df: pd.DataFrame, columns: list[str] | None = None) -> pd.DataFrame:
    cols = columns or measure_columns(df)
    if len(cols) < 2:
        raise AnalysisError("Correlation needs at least two numeric columns.")
    return df[cols].corr(method="pearson").round(3)


def strongest_correlations(df: pd.DataFrame, k: int = 5, min_abs: float = 0.0) -> pd.DataFrame:
    """Return the k numeric column pairs with the strongest (absolute) correlation."""
    try:
        corr = correlation_matrix(df)
    except AnalysisError:
        return pd.DataFrame(columns=["Column A", "Column B", "Correlation"])
    pairs = []
    cols = list(corr.columns)
    for i, a in enumerate(cols):
        for b in cols[i + 1:]:
            r = corr.loc[a, b]
            if pd.notna(r) and abs(r) >= min_abs:
                pairs.append({"Column A": a, "Column B": b, "Correlation": float(r)})
    table = pd.DataFrame(pairs, columns=["Column A", "Column B", "Correlation"])
    if table.empty:
        return table
    return (table.reindex(table["Correlation"].abs().sort_values(ascending=False).index)
            .head(k).reset_index(drop=True))


def describe_correlation(r: float) -> str:
    strength = abs(r)
    if strength >= 0.7:
        word = "strong"
    elif strength >= 0.4:
        word = "moderate"
    elif strength >= 0.2:
        word = "weak"
    else:
        word = "very weak or no"
    direction = "positive" if r > 0 else "negative"
    return f"{word} {direction}" if word != "very weak or no" else "very weak or no linear"


def outliers_iqr(df: pd.DataFrame, column: str) -> dict:
    """Flag values outside 1.5 × IQR (the standard box-plot rule)."""
    series = df[column].dropna()
    if column_kind(df[column]) != "numeric" or series.empty:
        raise AnalysisError(f"'{column}' must be a numeric column with values.")
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    mask = (df[column] < lower) | (df[column] > upper)
    if lower < series.min():          # nothing can be unusually low
        normal_range = f"above {fmt(upper)}"
    elif upper > series.max():        # nothing can be unusually high
        normal_range = f"below {fmt(lower)}"
    else:
        normal_range = f"outside {fmt(lower)} to {fmt(upper)}"
    return {
        "column": column,
        "lower_bound": float(lower),
        "upper_bound": float(upper),
        "unusual_when": normal_range,   # human-readable, e.g. "above 46,462.50"
        "outlier_count": int(mask.sum()),
        "outlier_percent": round(mask.mean() * 100, 2),
        "rows": df[mask],
    }


def numeric_column_stats(df: pd.DataFrame, column: str) -> dict:
    s = df[column]
    return {
        "count": int(s.notna().sum()),
        "missing": int(s.isna().sum()),
        "mean": float(s.mean()),
        "median": float(s.median()),
        "std": float(s.std()) if s.notna().sum() > 1 else 0.0,
        "min": float(s.min()),
        "max": float(s.max()),
        "sum": float(s.sum()),
    }


# --------------------------------------------------------------------------
# Formatting helper used across the app
# --------------------------------------------------------------------------

def fmt(value) -> str:
    """Format numbers for humans: 1234567.891 -> '1,234,567.89'."""
    if value is None:
        return "—"
    if isinstance(value, pd.Timestamp):
        return value.strftime("%Y-%m-%d")
    try:
        if pd.isna(value):
            return "—"
    except (TypeError, ValueError):
        pass
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, int) or (isinstance(value, float) and float(value).is_integer()):
        return f"{int(value):,}"
    if isinstance(value, float):
        return f"{value:,.2f}"
    try:  # numpy numbers
        as_float = float(value)
        return fmt(int(as_float) if as_float.is_integer() else as_float)
    except (TypeError, ValueError):
        return str(value)
