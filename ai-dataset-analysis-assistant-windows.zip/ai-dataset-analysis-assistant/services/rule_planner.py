"""Offline fallback: turn common questions into a plan using keyword rules.

Used only when no AI provider is configured. It understands simple, common
phrasings ("average revenue", "revenue by product", "missing values"...).
The UI labels these answers as rule-based so nobody mistakes them for AI.
"""

from __future__ import annotations

import re

import pandas as pd

from services import analysis_engine as ae
from services.query_planner import empty_plan

NUMBER_WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
                "seven": 7, "eight": 8, "nine": 9, "ten": 10, "fifteen": 15, "twenty": 20}

CHART_WORDS = {"bar": "bar", "line": "line", "pie": "pie", "histogram": "histogram",
               "distribution": "histogram", "scatter": "scatter", "box": "box", "heatmap": "heatmap"}

FREQ_WORDS = {"daily": "D", "per day": "D", "by day": "D", "weekly": "W", "per week": "W",
              "by week": "W", "monthly": "M", "per month": "M", "by month": "M",
              "quarterly": "Q", "per quarter": "Q", "by quarter": "Q",
              "yearly": "Y", "per year": "Y", "by year": "Y", "annual": "Y"}


def _has(q: str, *words: str) -> bool:
    return any(re.search(rf"\b{re.escape(w)}", q) for w in words)


def find_columns(question: str, columns) -> list[str]:
    """Columns mentioned in the question, in the order they appear."""
    q = question.lower()
    found = []
    for col in sorted(map(str, columns), key=len, reverse=True):  # longest names first
        name = col.lower().replace("_", " ").replace("-", " ").strip()
        for variant in (name, name + "s", name + "es", name.replace(" ", "")):
            m = re.search(rf"\b{re.escape(variant)}\b", q)
            if m and not any(start <= m.start() < end for _, start, end in found):
                found.append((col, m.start(), m.end()))
                break
    return [c for c, _, _ in sorted(found, key=lambda t: t[1])]


def _detect_n(q: str) -> int | None:
    m = re.search(r"\b(?:top|bottom|first|last|lowest|highest|best|worst)\s+(\d{1,3})\b", q) \
        or re.search(r"\b(\d{1,3})\s+(?:most|least|highest|lowest|top|best|worst)\b", q)
    if m:
        return int(m.group(1))
    for word, value in NUMBER_WORDS.items():
        if re.search(rf"\b(?:top|bottom|first|lowest|highest)\s+{word}\b", q):
            return value
    return None


def _detect_aggregation(q: str) -> str | None:
    if _has(q, "average", "mean", "avg"):
        return "mean"
    if _has(q, "median"):
        return "median"
    if _has(q, "total", "sum", "overall"):
        return "sum"
    if _has(q, "how many", "count", "number of"):
        return "count"
    if _has(q, "unique", "distinct"):
        return "nunique"
    if _has(q, "maximum", "max ", "largest value", "biggest value"):
        return "max"
    if _has(q, "minimum", "min ", "smallest value"):
        return "min"
    return None


def plan_from_rules(question: str, df: pd.DataFrame) -> dict:
    q = question.lower().strip()
    types = ae.column_types(df)
    mentioned = find_columns(q, df.columns)
    nums = [c for c in mentioned if c in types["numeric"]]
    cats = [c for c in mentioned if c in types["categorical"] + types["boolean"]]
    dates = [c for c in mentioned if c in types["datetime"]]

    chart_type = next((v for k, v in CHART_WORDS.items() if _has(q, k)), None)
    n = _detect_n(q)
    agg = _detect_aggregation(q)
    lowest = _has(q, "lowest", "least", "bottom", "worst", "smallest", "minimum", "fewest")
    ranking = lowest or _has(q, "highest", "most", "top", "best", "largest", "biggest", "maximum")

    # 1. Whole-dataset questions
    if _has(q, "duplicate"):
        return empty_plan("duplicates")
    if _has(q, "missing", "null", "blank", "nan", "empty value"):
        return empty_plan("missing_values")
    if _has(q, "outlier", "anomal", "unusual", "extreme"):
        col = nums[0] if nums else None
        if col:
            return empty_plan("outliers", column=col)
        return empty_plan("clarify", message="Which numeric column should I check for unusual values?")
    if _has(q, "correlat", "relationship", "related") or chart_type == "heatmap":
        if len(nums) >= 2:
            return empty_plan("correlation", column=nums[0], value_column=nums[1])
        return empty_plan("correlation")
    if _has(q, "summar", "overview", "describe the data", "about this data", "about the data",
            "rows and columns", "how many rows", "how many columns", "shape", "size of"):
        return empty_plan("dataset_summary")

    # 2. Charts of a single column / pair
    if chart_type == "scatter" and len(nums) >= 2:
        return empty_plan("chart", chart_type="scatter", x=nums[0], y=nums[1])
    if chart_type in ("histogram", "box") and nums:
        return empty_plan("chart", chart_type=chart_type, column=nums[0],
                          group_by=cats[0] if cats and chart_type == "box" else None)

    # 3. Trends over time
    freq = next((v for k, v in FREQ_WORDS.items() if k in q), None)
    if (freq or _has(q, "trend", "over time", "time series")) and types["datetime"]:
        return empty_plan("time_trend", date_column=dates[0] if dates else types["datetime"][0],
                          value_column=nums[0] if nums else None,
                          aggregation=agg if agg and agg != "count" else ("sum" if nums else "count"),
                          freq=freq or "M", chart_type=chart_type)

    # 4. Group comparisons: "revenue by product", "which region has the highest sales"
    if cats and (nums or agg == "count" or chart_type in ("bar", "pie")):
        value = nums[0] if nums else None
        aggregation = "count" if not value else (agg if agg and agg not in ("count",) else "sum")
        return empty_plan("group_aggregate", group_by=cats[0], value_column=value,
                          aggregation=aggregation, ascending=lowest, n=n, chart_type=chart_type)

    # 5. Single numeric column
    if nums:
        if agg in ("mean", "median", "sum", "min", "max", "nunique"):
            return empty_plan("aggregate", column=nums[0], aggregation=agg)
        if ranking:
            return empty_plan("sort_rows", column=nums[0], ascending=lowest, n=n or 5)
        return empty_plan("column_stats", column=nums[0])

    # 6. Single text column: most common values
    if cats:
        return empty_plan("value_counts", column=cats[0], n=n or 10, chart_type=chart_type)
    if dates:
        return empty_plan("column_stats", column=dates[0])
    if agg == "count" or _has(q, "how many"):
        return empty_plan("count_rows")

    examples = _example_columns(df)
    return empty_plan("clarify", message=(
        "I couldn't match that question to a column. Try naming a column, for example: "
        + examples + ". (Offline mode understands simple questions; configure an AI provider "
        "for free-form questions.)"))


def _example_columns(df: pd.DataFrame) -> str:
    from services.insights import pick_main_measure
    main = pick_main_measure(df)
    measures = [main] if main else []
    groups = ae.grouping_columns(df)
    if measures and groups:
        return f"'total {measures[0]} by {groups[0]}' or 'average {measures[0]}'"
    if measures:
        return f"'average {measures[0]}'"
    return f"'most common {df.columns[0]}'"
