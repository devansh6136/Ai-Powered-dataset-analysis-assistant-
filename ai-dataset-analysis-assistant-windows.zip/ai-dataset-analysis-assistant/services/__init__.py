"""Business logic: loading, cleaning, analysing, charting, AI and reports.

Nothing in this package imports Streamlit, so every function can be unit-tested.
"""
