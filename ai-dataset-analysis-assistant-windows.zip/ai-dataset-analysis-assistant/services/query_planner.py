"""Turn an analysis *plan* (a small JSON dict) into a verified result.

    question ──► plan (from the AI or the rule matcher)
             ──► validate_plan()  : columns exist? operation allowed? types OK?
             ──► execute_plan()   : run the matching Pandas function
             ──► AnalysisResult   : table + chart + plain-English summary

The plan is pure data. It can only select from the operations listed in
OPERATIONS — there is no way for it to run arbitrary Python, SQL or shell.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from services import analysis_engine as ae
from services import chart_generator as cg

OPERATIONS = {
    "dataset_summary": "Overview: rows, columns, types, missing values, duplicates.",
    "column_stats": "Statistics for one column (numbers: mean/median/min/max; text: most common values).",
    "aggregate": "One number from one column, e.g. average/total/max of Revenue. Needs column + aggregation.",
    "group_aggregate": "Compare groups, e.g. total Revenue by Product. Needs group_by, value_column (null for counts), aggregation. Use n + ascending for top/bottom N.",
    "sort_rows": "Show individual rows with the highest/lowest values of a column. Needs column, ascending, n.",
    "value_counts": "How often each value of a column appears (e.g. most common categories). Needs column.",
    "count_rows": "Count rows, optionally matching filters (e.g. how many orders from North).",
    "time_trend": "A value over time, grouped by day/week/month/quarter/year. Needs date_column, freq; value_column + aggregation optional.",
    "correlation": "Correlation between numeric columns. Give column + value_column for one pair, or both null for all pairs.",
    "outliers": "Find unusual values in one numeric column (1.5×IQR rule). Needs column.",
    "missing_values": "Missing values per column.",
    "duplicates": "Duplicate rows.",
    "chart": "A distribution/relationship chart: histogram or box (column), scatter (x, y). For bar/line/pie of grouped values use group_aggregate or time_trend with chart_type instead.",
    "clarify": "The question is ambiguous — put a short clarifying question in message.",
    "unsupported": "The question can't be answered with these operations (e.g. predictions, external data, causes) — explain in message.",
}

NULLABLE_STRING = {"anyOf": [{"type": "string"}, {"type": "null"}]}

# JSON Schema handed to the AI so its reply is always a well-formed plan.
PLAN_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "operation": {"type": "string", "enum": list(OPERATIONS)},
        "column": NULLABLE_STRING,
        "group_by": NULLABLE_STRING,
        "value_column": NULLABLE_STRING,
        "date_column": NULLABLE_STRING,
        "aggregation": {"anyOf": [{"type": "string", "enum": list(ae.ALL_AGGREGATIONS)}, {"type": "null"}]},
        "n": {"anyOf": [{"type": "integer"}, {"type": "null"}]},
        "ascending": {"anyOf": [{"type": "boolean"}, {"type": "null"}]},
        "freq": {"anyOf": [{"type": "string", "enum": list(ae.TIME_FREQUENCIES)}, {"type": "null"}]},
        "chart_type": {"anyOf": [{"type": "string", "enum": list(cg.CHART_TYPES)}, {"type": "null"}]},
        "x": NULLABLE_STRING,
        "y": NULLABLE_STRING,
        "filters": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "column": {"type": "string"},
                    "operator": {"type": "string", "enum": list(ae.FILTER_OPERATORS)},
                    "value": {"anyOf": [{"type": "string"}, {"type": "number"}, {"type": "boolean"}]},
                },
                "required": ["column", "operator", "value"],
                "additionalProperties": False,
            },
        },
        "message": NULLABLE_STRING,
    },
    "required": ["operation", "column", "group_by", "value_column", "date_column", "aggregation",
                 "n", "ascending", "freq", "chart_type", "x", "y", "filters", "message"],
    "additionalProperties": False,
}

COLUMN_FIELDS = ("column", "group_by", "value_column", "date_column", "x", "y")
MAX_N = 100


class PlanError(Exception):
    """The plan can't be run as-is; the message is shown to the user."""


@dataclass
class AnalysisResult:
    operation: str
    title: str
    summary: str                         # deterministic, computed from the data
    table: pd.DataFrame | None = None
    chart: Any = None                    # plotly Figure
    facts: dict = field(default_factory=dict)
    filters: list[str] = field(default_factory=list)
    rows_used: int = 0

    def facts_for_ai(self, max_rows: int) -> str:
        """The *only* data the AI sees when writing an explanation."""
        payload: dict[str, Any] = {
            "operation": self.operation,
            "title": self.title,
            "computed_summary": self.summary,
            "rows_used": self.rows_used,
            "filters_applied": self.filters,
            "facts": self.facts,
        }
        if self.table is not None and not self.table.empty:
            payload["result_table_first_rows"] = json.loads(
                self.table.head(max_rows).to_json(orient="records", date_format="iso", default_handler=str)
            )
            payload["result_table_total_rows"] = int(len(self.table))
        return json.dumps(payload, default=str, indent=1)


# --------------------------------------------------------------------------
# Validation
# --------------------------------------------------------------------------

def empty_plan(operation: str, **values) -> dict:
    plan = {key: None for key in PLAN_SCHEMA["required"]}
    plan.update(operation=operation, filters=[])
    plan.update(values)
    return plan


def resolve_column(name: str | None, df: pd.DataFrame) -> str | None:
    """Match a column name forgivingly: case, spaces and underscores are ignored."""
    if name is None or str(name).strip() == "":
        return None
    if name in df.columns:
        return name

    def key(s: str) -> str:
        return "".join(ch for ch in str(s).lower() if ch.isalnum())

    lookup = {key(c): c for c in df.columns}
    match = lookup.get(key(name))
    if match is None:
        raise PlanError(f"I couldn't find a column called '{name}'. "
                        f"Available columns: {', '.join(map(str, df.columns[:30]))}")
    return match


def validate_plan(plan: dict, df: pd.DataFrame) -> dict:
    """Check every field of a plan against the real DataFrame. Returns a clean copy."""
    if not isinstance(plan, dict):
        raise PlanError("The analysis plan was not in the expected format.")
    op = plan.get("operation")
    if op not in OPERATIONS:
        raise PlanError(f"'{op}' is not a supported analysis operation.")

    clean = empty_plan(op)
    for key in PLAN_SCHEMA["required"]:
        if key in plan and plan[key] is not None:
            clean[key] = plan[key]
    if op in ("clarify", "unsupported"):
        clean["message"] = str(plan.get("message") or "Could you rephrase the question?")[:500]
        return clean

    for f in COLUMN_FIELDS:
        clean[f] = resolve_column(clean[f], df)

    if clean["aggregation"] is not None and clean["aggregation"] not in ae.ALL_AGGREGATIONS:
        raise PlanError(f"Unsupported aggregation '{clean['aggregation']}'.")
    if clean["freq"] is not None and clean["freq"] not in ae.TIME_FREQUENCIES:
        raise PlanError(f"Unsupported time period '{clean['freq']}'.")
    if clean["chart_type"] is not None and clean["chart_type"] not in cg.CHART_TYPES:
        raise PlanError(f"Unsupported chart type '{clean['chart_type']}'.")
    if clean["n"] is not None:
        try:
            clean["n"] = max(1, min(int(clean["n"]), MAX_N))
        except (TypeError, ValueError):
            raise PlanError("The number of results must be a whole number.")
    clean["ascending"] = bool(clean["ascending"]) if clean["ascending"] is not None else False

    filters = []
    for f in clean["filters"] or []:
        if not isinstance(f, dict) or f.get("operator") not in ae.FILTER_OPERATORS:
            raise PlanError("One of the filters is not valid.")
        filters.append({"column": resolve_column(f.get("column"), df),
                        "operator": f["operator"], "value": f.get("value")})
    clean["filters"] = filters

    _check_requirements(clean, df)
    return clean


def _kind(df: pd.DataFrame, col: str | None) -> str | None:
    return ae.column_kind(df[col]) if col else None


def _check_requirements(p: dict, df: pd.DataFrame) -> None:
    op = p["operation"]

    def need(field: str, question: str) -> None:
        if not p[field]:
            raise PlanError(question)

    # AI models sometimes put the main column in a neighbouring field; accept it there too.
    if op in ("column_stats", "aggregate", "value_counts", "sort_rows", "outliers") and not p["column"]:
        p["column"] = p["value_column"] or p["x"] or p["y"]
    if op == "group_aggregate" and not p["group_by"]:
        p["group_by"] = p["x"] or (p["column"] if p["column"] != p["value_column"] else None)

    if op in ("column_stats", "value_counts", "sort_rows", "outliers"):
        need("column", "Which column should I look at?")
    if op in ("sort_rows", "outliers") and _kind(df, p["column"]) != "numeric":
        raise PlanError(f"'{p['column']}' must be numeric for this analysis.")

    if op == "aggregate":
        need("column", "Which column should I calculate this for?")
        p["aggregation"] = p["aggregation"] or "sum"
        if p["aggregation"] in ae.NUMERIC_AGGREGATIONS and _kind(df, p["column"]) != "numeric":
            raise PlanError(f"'{p['column']}' isn't numeric, so I can't calculate its {p['aggregation']}.")

    if op == "group_aggregate":
        need("group_by", "Which column should I group by?")
        if p["value_column"] is None:
            p["aggregation"] = "count"
        else:
            p["aggregation"] = p["aggregation"] or ("sum" if _kind(df, p["value_column"]) == "numeric" else "count")
            if p["aggregation"] in ae.NUMERIC_AGGREGATIONS and _kind(df, p["value_column"]) != "numeric":
                raise PlanError(f"'{p['value_column']}' isn't numeric, so I can't calculate its {p['aggregation']}.")

    if op == "time_trend":
        if not p["date_column"]:
            dates = ae.column_types(df)["datetime"]
            if not dates:
                raise PlanError("This dataset has no date column, so I can't show a trend over time.")
            p["date_column"] = dates[0]
        if _kind(df, p["date_column"]) != "datetime":
            raise PlanError(f"'{p['date_column']}' is not a date column.")
        p["freq"] = p["freq"] or "M"
        p["aggregation"] = p["aggregation"] or ("sum" if p["value_column"] else "count")
        if p["value_column"] and p["aggregation"] in ae.NUMERIC_AGGREGATIONS \
                and _kind(df, p["value_column"]) != "numeric":
            raise PlanError(f"'{p['value_column']}' isn't numeric.")

    if op == "correlation":
        for col in (p["column"], p["value_column"]):
            if col and _kind(df, col) != "numeric":
                raise PlanError(f"'{col}' isn't numeric, so it has no correlation coefficient.")

    if op == "chart":
        chart = p["chart_type"]
        if chart in ("bar", "line", "pie"):
            # Re-route to the grouped operations, which compute the values first.
            x = p["x"] or p["group_by"] or p["column"]
            if not x:
                raise PlanError("Which column should go on the chart's category axis?")
            p.update(group_by=x, value_column=p["value_column"] or p["y"])
            p["operation"] = "time_trend" if _kind(df, x) == "datetime" else "group_aggregate"
            if p["operation"] == "time_trend":
                p["date_column"] = x
            _check_requirements(p, df)
        elif chart in ("histogram", "box"):
            p["column"] = p["column"] or p["x"] or p["y"]
            need("column", "Which numeric column should I plot?")
            if _kind(df, p["column"]) != "numeric":
                raise PlanError(f"'{p['column']}' must be numeric for a {chart}.")
        elif chart == "scatter":
            p["x"] = p["x"] or p["column"]
            p["y"] = p["y"] or p["value_column"]
            if not (p["x"] and p["y"]):
                raise PlanError("A scatter plot needs two numeric columns (x and y).")
            for col in (p["x"], p["y"]):
                if _kind(df, col) != "numeric":
                    raise PlanError(f"'{col}' must be numeric for a scatter plot.")
        elif chart == "heatmap":
            p["operation"] = "correlation"
        else:
            raise PlanError("Which kind of chart would you like (bar, line, pie, histogram, scatter, box)?")


# --------------------------------------------------------------------------
# Execution
# --------------------------------------------------------------------------

def execute_plan(plan: dict, df: pd.DataFrame) -> AnalysisResult:
    """Run a *validated* plan with Pandas and build the result + chart."""
    data, filter_text = ae.filter_rows(df, plan["filters"])
    op = plan["operation"]
    if len(data) == 0:
        return AnalysisResult(op, "No matching rows",
                              "No rows match the requested filters, so there is nothing to calculate.",
                              filters=filter_text)
    result = _RUNNERS[op](plan, data)
    result.filters = filter_text
    result.rows_used = int(len(data))
    if filter_text:
        result.summary = f"Using {len(data):,} rows where {' and '.join(filter_text)}. " + result.summary
    return result


def _dataset_summary(p, df):
    o = ae.dataset_overview(df)
    summary = (f"The dataset has {o['rows']:,} rows and {o['columns']} columns "
               f"({o['numeric_columns']} numeric, {o['categorical_columns']} text/category, "
               f"{o['datetime_columns']} date). It has {o['missing_cells']:,} missing cells "
               f"({o['missing_percent']}%) and {o['duplicate_rows']:,} duplicate rows.")
    return AnalysisResult("dataset_summary", "Dataset summary", summary, ae.column_info(df), facts=o)


def _column_stats(p, df):
    col = p["column"]
    kind = ae.column_kind(df[col])
    if kind == "numeric":
        s = ae.numeric_column_stats(df, col)
        table = pd.DataFrame({"Statistic": list(s), "Value": list(s.values())})
        summary = (f"{col}: average {ae.fmt(s['mean'])}, median {ae.fmt(s['median'])}, "
                   f"minimum {ae.fmt(s['min'])}, maximum {ae.fmt(s['max'])}, "
                   f"total {ae.fmt(s['sum'])} across {s['count']:,} non-missing values.")
        chart = cg.histogram(df, col)
        return AnalysisResult("column_stats", f"Statistics for {col}", summary, table, chart, facts=s)
    if kind == "datetime":
        s = df[col].dropna()
        facts = {"earliest": str(s.min().date()), "latest": str(s.max().date()), "count": int(len(s))}
        summary = f"{col} ranges from {facts['earliest']} to {facts['latest']} ({len(s):,} values)."
        return AnalysisResult("column_stats", f"Date range of {col}", summary, facts=facts)
    table = ae.value_counts(df, col, 10)
    unique = int(df[col].nunique())
    summary = (f"{col} has {unique:,} distinct values. The most common is "
               f"'{table.iloc[0, 0]}' ({table.iloc[0]['Count']:,} rows)." if len(table) else f"{col} is empty.")
    chart = cg.bar_chart(table, col, "Count", f"Most common values of {col}") if len(table) else None
    return AnalysisResult("column_stats", f"Values of {col}", summary, table, chart, facts={"unique": unique})


def _aggregate(p, df):
    col, agg = p["column"], p["aggregation"]
    value = ae.aggregate_column(df, col, agg)
    label = ae.aggregate_label(agg, col)
    summary = f"{label}: {ae.fmt(value)} (calculated over {df[col].notna().sum():,} non-missing values)."
    if agg == "count":
        summary = f"{col} has {ae.fmt(value)} non-missing values."
    table = pd.DataFrame({"Metric": [label], "Value": [value]})
    return AnalysisResult("aggregate", label, summary, table, facts={"metric": label, "value": value})


def _group_aggregate(p, df):
    table = ae.group_aggregate(df, p["group_by"], p["value_column"], p["aggregation"],
                               p["ascending"], p["n"])
    label = table.columns[1]
    title = f"{label} by {p['group_by']}"
    if p["n"]:
        title = f"{'Bottom' if p['ascending'] else 'Top'} {p['n']}: {title}"
    if table.empty:
        return AnalysisResult("group_aggregate", title, "No groups were found.", table)
    first, last = table.iloc[0], table.iloc[-1]
    word_first, word_last = ("lowest", "highest") if p["ascending"] else ("highest", "lowest")
    summary = f"**{first.iloc[0]}** has the {word_first} {label.lower()}: **{ae.fmt(first.iloc[1])}**"
    if p["aggregation"] in ("sum", "count") and (table[label] >= 0).all():
        total = ae.group_aggregate(df, p["group_by"], p["value_column"], p["aggregation"])[label].sum()
        if total:
            summary += f" ({first.iloc[1] / total * 100:.1f}% of the overall total)"
    summary += "."
    if len(table) > 1:
        summary += (f" The {word_last} shown is {last.iloc[0]} ({ae.fmt(last.iloc[1])}); "
                    f"{len(table)} {p['group_by']} groups compared.")
    chart = _chart_for_table(p.get("chart_type"), table, p["group_by"], label, title)
    facts = {"groups_shown": int(len(table)), "first": [str(first.iloc[0]), float(first.iloc[1])]}
    return AnalysisResult("group_aggregate", title, summary, table, chart, facts=facts)


def _sort_rows(p, df):
    n = p["n"] or 10
    table = ae.sort_rows(df, p["column"], p["ascending"], n)
    word = "lowest" if p["ascending"] else "highest"
    summary = f"The {len(table)} rows with the {word} {p['column']}"
    if len(table):
        summary += f" range from {ae.fmt(table[p['column']].iloc[0])} to {ae.fmt(table[p['column']].iloc[-1])}."
    return AnalysisResult("sort_rows", f"Rows with the {word} {p['column']}", summary, table)


def _value_counts(p, df):
    col = p["column"]
    table = ae.value_counts(df, col, p["n"] or 10)
    if table.empty:
        return AnalysisResult("value_counts", f"Values of {col}", f"{col} has no values.", table)
    summary = (f"Most common {col}: '{table.iloc[0, 0]}' with {table.iloc[0]['Count']:,} rows "
               f"({table.iloc[0]['Share %']}%). {df[col].nunique():,} distinct values in total.")
    chart = _chart_for_table(p.get("chart_type"), table, col, "Count", f"Most common values of {col}")
    return AnalysisResult("value_counts", f"Most common values of {col}", summary, table, chart)


def _count_rows(p, df):
    n = int(len(df))
    return AnalysisResult("count_rows", "Row count", f"{n:,} rows match.", facts={"rows": n})


def _time_trend(p, df):
    table = ae.time_trend(df, p["date_column"], p["value_column"], p["aggregation"], p["freq"])
    label = table.columns[1]
    period_name = ae.TIME_FREQUENCIES[p["freq"]]
    title = f"{label} per {period_name}"
    if table.empty:
        return AnalysisResult("time_trend", title, "No dated rows were found.", table)
    best, worst = table.loc[table[label].idxmax()], table.loc[table[label].idxmin()]
    first, last = table.iloc[0], table.iloc[-1]
    name = lambda row: ae.period_label(row["Period"], p["freq"])  # noqa: E731
    summary = (f"Across {len(table)} {period_name}s, the highest was {name(best)} "
               f"({ae.fmt(best[label])}) and the lowest was {name(worst)} ({ae.fmt(worst[label])}).")
    if len(table) > 1 and first[label]:
        change = (last[label] - first[label]) / abs(first[label]) * 100
        summary += (f" From the first {period_name}, {name(first)} ({ae.fmt(first[label])}), to the last, "
                    f"{name(last)} ({ae.fmt(last[label])}), the change is {change:+.1f}%.")
    chart_type = p.get("chart_type") if p.get("chart_type") in ("bar", "line") else "line"
    chart = (cg.bar_chart(table, "Period", label, title) if chart_type == "bar"
             else cg.line_chart(table, "Period", label, title))
    facts = {"periods": int(len(table)), "highest_period": name(best), "lowest_period": name(worst)}
    return AnalysisResult("time_trend", title, summary, table, chart, facts=facts)


def _correlation(p, df):
    a, b = p["column"], p["value_column"]
    if a and b:
        r = float(df[[a, b]].corr().iloc[0, 1])
        summary = (f"The correlation between {a} and {b} is {r:.3f} — a "
                   f"{ae.describe_correlation(r)} relationship. Correlation does not prove causation.")
        chart = cg.scatter_plot(df, a, b)
        table = pd.DataFrame({"Column A": [a], "Column B": [b], "Correlation": [round(r, 3)]})
        return AnalysisResult("correlation", f"Correlation: {a} vs {b}", summary, table, chart, facts={"r": r})
    corr = ae.correlation_matrix(df)
    pairs = ae.strongest_correlations(df, k=10)
    if pairs.empty:
        summary = "No correlations could be calculated."
    else:
        top = pairs.iloc[0]
        summary = (f"The strongest relationship is between {top['Column A']} and {top['Column B']} "
                   f"(r = {top['Correlation']:.3f}, {ae.describe_correlation(top['Correlation'])}). "
                   "Correlation does not prove causation.")
    return AnalysisResult("correlation", "Correlation between numeric columns", summary, pairs,
                          cg.correlation_heatmap(corr), facts={"pairs_checked": int(len(pairs))})


def _outliers(p, df):
    info = ae.outliers_iqr(df, p["column"])
    summary = (f"{info['outlier_count']:,} rows ({info['outlier_percent']}%) have unusual {p['column']} "
               f"values ({info['unusual_when']}, by the 1.5×IQR rule).")
    facts = {k: v for k, v in info.items() if k != "rows"}
    return AnalysisResult("outliers", f"Unusual values in {p['column']}", summary,
                          info["rows"].head(MAX_N), cg.box_plot(df, p["column"]), facts=facts)


def _missing_values(p, df):
    table = ae.missing_values(df)
    if table.empty:
        return AnalysisResult("missing_values", "Missing values", "There are no missing values in this dataset.")
    total = int(table["Missing"].sum())
    summary = (f"{total:,} missing cells across {len(table)} column(s). Most affected: "
               f"{table.iloc[0]['Column']} ({table.iloc[0]['Missing']:,} missing, {table.iloc[0]['Missing %']}%).")
    chart = cg.bar_chart(table, "Column", "Missing", "Missing values per column")
    return AnalysisResult("missing_values", "Missing values", summary, table, chart, facts={"missing_cells": total})


def _duplicates(p, df):
    count, rows = ae.duplicate_rows(df)
    summary = (f"There are {count:,} duplicate rows (exact copies of an earlier row)."
               if count else "There are no duplicate rows.")
    return AnalysisResult("duplicates", "Duplicate rows", summary, rows.head(MAX_N) if count else None,
                          facts={"duplicate_rows": count})


def _chart(p, df):
    chart = p["chart_type"]
    if chart == "histogram":
        s = ae.numeric_column_stats(df, p["column"])
        summary = (f"{p['column']} ranges from {ae.fmt(s['min'])} to {ae.fmt(s['max'])}, "
                   f"with a median of {ae.fmt(s['median'])}.")
        return AnalysisResult("chart", f"Distribution of {p['column']}", summary,
                              chart=cg.histogram(df, p["column"]), facts=s)
    if chart == "box":
        s = ae.numeric_column_stats(df, p["column"])
        summary = f"Median {p['column']} is {ae.fmt(s['median'])} (min {ae.fmt(s['min'])}, max {ae.fmt(s['max'])})."
        return AnalysisResult("chart", f"Spread of {p['column']}", summary,
                              chart=cg.box_plot(df, p["column"], p["group_by"]), facts=s)
    # scatter
    r = float(df[[p["x"], p["y"]]].corr().iloc[0, 1])
    summary = (f"Each dot is one row. Correlation between {p['x']} and {p['y']}: {r:.3f} "
               f"({ae.describe_correlation(r)}).")
    return AnalysisResult("chart", f"{p['y']} vs {p['x']}", summary,
                          chart=cg.scatter_plot(df, p["x"], p["y"]), facts={"r": r})


def _chart_for_table(chart_type, table, x, y, title):
    if chart_type == "pie" and (table[y] >= 0).all():
        return cg.pie_chart(table, x, y, title)
    if chart_type == "line":
        return cg.line_chart(table, x, y, title)
    return cg.bar_chart(table, x, y, title)


_RUNNERS = {
    "dataset_summary": _dataset_summary,
    "column_stats": _column_stats,
    "aggregate": _aggregate,
    "group_aggregate": _group_aggregate,
    "sort_rows": _sort_rows,
    "value_counts": _value_counts,
    "count_rows": _count_rows,
    "time_trend": _time_trend,
    "correlation": _correlation,
    "outliers": _outliers,
    "missing_values": _missing_values,
    "duplicates": _duplicates,
    "chart": _chart,
}


# --------------------------------------------------------------------------
# Show the equivalent Pandas code (for learning/transparency — never executed)
# --------------------------------------------------------------------------

def plan_to_pandas(p: dict) -> str:
    lines = []
    for f in p.get("filters") or []:
        op = f["operator"]
        val = json.dumps(f["value"])
        if op == "contains":
            lines.append(f'df = df[df["{f["column"]}"].str.contains({val}, case=False)]')
        else:
            lines.append(f'df = df[df["{f["column"]}"] {op} {val}]')
    op = p["operation"]
    asc = p.get("ascending", False)
    n = p.get("n")
    head = f".head({n})" if n else ""
    if op == "dataset_summary":
        lines += ["df.shape", "df.dtypes", "df.isna().sum()", "df.duplicated().sum()"]
    elif op == "column_stats":
        lines.append(f'df["{p["column"]}"].describe()')
    elif op == "aggregate":
        lines.append(f'df["{p["column"]}"].{p["aggregation"]}()')
    elif op == "group_aggregate":
        if p["aggregation"] == "count" or not p["value_column"]:
            lines.append(f'df.groupby("{p["group_by"]}").size().sort_values(ascending={asc}){head}')
        else:
            lines.append(f'df.groupby("{p["group_by"]}")["{p["value_column"]}"].{p["aggregation"]}()'
                         f'.sort_values(ascending={asc}){head}')
    elif op == "sort_rows":
        lines.append(f'df.sort_values("{p["column"]}", ascending={asc}).head({n or 10})')
    elif op == "value_counts":
        lines.append(f'df["{p["column"]}"].value_counts().head({n or 10})')
    elif op == "count_rows":
        lines.append("len(df)")
    elif op == "time_trend":
        period = f'df["{p["date_column"]}"].dt.to_period("{p["freq"]}")'
        if p["value_column"] and p["aggregation"] != "count":
            lines.append(f'df.groupby({period})["{p["value_column"]}"].{p["aggregation"]}()')
        else:
            lines.append(f"df.groupby({period}).size()")
    elif op == "correlation":
        if p["column"] and p["value_column"]:
            lines.append(f'df["{p["column"]}"].corr(df["{p["value_column"]}"])')
        else:
            lines.append('df.select_dtypes("number").corr()')
    elif op == "outliers":
        c = p["column"]
        lines += [f'q1, q3 = df["{c}"].quantile([0.25, 0.75])', "iqr = q3 - q1",
                  f'df[(df["{c}"] < q1 - 1.5 * iqr) | (df["{c}"] > q3 + 1.5 * iqr)]']
    elif op == "missing_values":
        lines.append("df.isna().sum()")
    elif op == "duplicates":
        lines.append("df[df.duplicated(keep=False)]")
    elif op == "chart":
        lines.append(f"# Plotly {p['chart_type']} chart of the selected column(s)")
    return "\n".join(lines)
