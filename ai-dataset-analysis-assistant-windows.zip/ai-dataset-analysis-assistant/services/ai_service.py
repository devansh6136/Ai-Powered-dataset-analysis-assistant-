"""Talk to a Large Language Model (Claude or Gemini) — with strict boundaries.

The AI has exactly three jobs:
  1. plan_question()   question  -> JSON analysis plan   (no numbers involved)
  2. explain_result()  verified result -> short explanation
  3. write_insights()  verified findings -> readable report section

It never receives the full dataset — only column names/types, a few example
values (optional), and the small result tables Python already calculated.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod

import pandas as pd

import config
from services import analysis_engine as ae
from services.query_planner import OPERATIONS, PLAN_SCHEMA, AnalysisResult


class AIError(Exception):
    """Something went wrong talking to the AI provider (message is user-safe)."""


# --------------------------------------------------------------------------
# Provider interface — add a new provider by subclassing LLMProvider
# --------------------------------------------------------------------------

class LLMProvider(ABC):
    name: str = ""
    model: str = ""

    @abstractmethod
    def complete(self, system: str, prompt: str, json_schema: dict | None = None,
                 effort: str = "low", max_tokens: int = 4000) -> str:
        """Return the model's text reply (a JSON string when json_schema is given)."""


# Models that support Anthropic's server-side refusal fallback.
_FALLBACK_MODELS = {"claude-opus-5-5", "claude-opus-5", "claude-fable-5-1", "claude-sonnet-5-5"}


class ClaudeProvider(LLMProvider):
    name = "Anthropic Claude"

    def __init__(self, api_key: str, model: str):
        import anthropic  # imported lazily so the app runs without the package
        self._anthropic = anthropic
        self.model = model
        self.client = anthropic.Anthropic(api_key=api_key, timeout=90.0, max_retries=2)

    def complete(self, system, prompt, json_schema=None, effort="low", max_tokens=4000):
        anthropic = self._anthropic
        output_config: dict = {"effort": effort}
        if json_schema:
            output_config["format"] = {"type": "json_schema", "schema": json_schema}
        request = dict(model=self.model, max_tokens=max_tokens, system=system,
                       messages=[{"role": "user", "content": prompt}], output_config=output_config)
        try:
            if self.model in _FALLBACK_MODELS:
                # If a safety classifier declines, the API retries on a suitable model.
                response = self.client.beta.messages.create(
                    **request, betas=["server-side-fallback-2026-07-01"], fallbacks="default")
            else:
                response = self.client.messages.create(**request)
        except anthropic.AuthenticationError:
            raise AIError("The Anthropic API key was rejected. Check ANTHROPIC_API_KEY in your .env file.")
        except anthropic.PermissionDeniedError:
            raise AIError("This API key doesn't have access to the requested model.")
        except anthropic.NotFoundError:
            raise AIError(f"Model '{self.model}' was not found. Check ANTHROPIC_MODEL in your .env file.")
        except anthropic.RateLimitError:
            raise AIError("The AI provider's rate limit was reached. Wait a minute and try again.")
        except anthropic.BadRequestError as exc:
            raise AIError(f"The AI provider rejected the request: {exc.message[:200]}")
        except anthropic.APIStatusError as exc:
            raise AIError(f"The AI provider returned an error ({exc.status_code}). Please try again.")
        except anthropic.APIConnectionError:
            raise AIError("Couldn't reach the AI provider. Check your internet connection.")

        if response.stop_reason == "refusal":
            raise AIError("The AI model declined to answer this request.")
        if response.stop_reason == "max_tokens" and json_schema:
            raise AIError("The AI response was cut off. Try a shorter question.")
        return "".join(block.text for block in response.content if block.type == "text")


class GeminiProvider(LLMProvider):
    name = "Google Gemini"
    # Our effort names -> Gemini "thinking levels". Turning a question into a plan needs little
    # reasoning, and less thinking makes answers much faster (seconds instead of minutes).
    THINKING_LEVELS = {"low": "MINIMAL", "medium": "LOW", "high": "MEDIUM"}

    def __init__(self, api_key: str, model: str, fallback_model: str | None = None):
        from google import genai
        from google.genai import types
        self._types = types
        self.model = model
        # Backup model used when the main one is overloaded (503) or out of free quota (429).
        # Each model has its own free daily quota, so this also doubles the questions per day.
        self.fallback_model = fallback_model if fallback_model and fallback_model != model else None
        self.last_model = model           # which model answered the latest request
        import httpx
        # - Connect over IPv4: on networks that advertise IPv6 but don't route it, the default
        #   client tries every IPv6 address first and each new connection takes ~40 s.
        # - Fail fast: 60 s timeout and only 1 retry, so we switch to the backup model (or show a
        #   clear error) instead of silently retrying for minutes.
        self.client = genai.Client(api_key=api_key, http_options=types.HttpOptions(
            timeout=60_000,
            retry_options=types.HttpRetryOptions(attempts=2, max_delay=4),
            client_args={"transport": httpx.HTTPTransport(local_address="0.0.0.0")},
        ))
        self._use_thinking_level = True

    def _generate(self, model, system, prompt, json_schema, effort, max_tokens):
        from google.genai import errors
        types = self._types
        thinking = (types.ThinkingConfig(thinking_level=self.THINKING_LEVELS.get(effort, "LOW"))
                    if self._use_thinking_level else None)
        cfg = types.GenerateContentConfig(
            system_instruction=system,
            max_output_tokens=max_tokens,
            thinking_config=thinking,
            # With a schema, Gemini is constrained to return a valid analysis plan.
            response_mime_type="application/json" if json_schema else None,
            response_json_schema=json_schema,
        )
        try:
            return self.client.models.generate_content(model=model, contents=prompt, config=cfg)
        except errors.ClientError as exc:
            # Older models (e.g. Gemini 2.5) don't accept thinking levels: retry once without.
            if thinking is not None and exc.code == 400 and "thinking" in str(exc).lower():
                self._use_thinking_level = False
                return self._generate(model, system, prompt, json_schema, effort, max_tokens)
            raise

    def complete(self, system, prompt, json_schema=None, effort="low", max_tokens=4000):
        from google.genai import errors
        model = self.model
        try:
            try:
                response = self._generate(model, system, prompt, json_schema, effort, max_tokens)
            except errors.APIError as exc:
                if exc.code not in (429, 503) or not self.fallback_model:
                    raise
                model = self.fallback_model   # main model busy or out of quota: use the backup
                response = self._generate(model, system, prompt, json_schema, effort, max_tokens)
            self.last_model = model
        except errors.APIError as exc:
            code = getattr(exc, "code", None)
            if code in (401, 403) or "API key" in str(exc):
                raise AIError("The Gemini API key was rejected. Check GEMINI_API_KEY in your .env file.")
            if code == 404:
                raise AIError(f"Gemini model '{model}' was not found. Check GEMINI_MODEL in your .env file.")
            if code == 429 and "PerDay" in str(exc):
                raise AIError(f"The free-tier daily quota for '{model}' is used up (it resets daily). "
                              "Set another model with GEMINI_MODEL in .env, or enable billing.")
            if code == 429:
                raise AIError("The Gemini rate limit was reached. Wait a minute and try again.")
            if code == 503:
                raise AIError(f"Gemini model '{model}' is overloaded right now. Try again shortly, "
                              "or set another model with GEMINI_MODEL in .env.")
            if code and code >= 500:
                raise AIError("Gemini had a server error. Please try again.")
            raise AIError(f"Gemini rejected the request ({code}): {getattr(exc, 'message', '') or str(exc)[:200]}")
        except Exception as exc:  # network problems (DNS, timeout, no internet)
            raise AIError(f"Couldn't reach Gemini ({type(exc).__name__}). Check your internet connection.")

        text = response.text
        if not text:
            reason = response.candidates[0].finish_reason if response.candidates else "no candidates"
            raise AIError(f"Gemini returned no text (finish reason: {reason}). Try rephrasing.")
        return text


def get_provider() -> tuple[LLMProvider | None, str]:
    """Create the configured provider. Returns (provider or None, status message)."""
    import os
    choice = config.AI_PROVIDER
    try:
        if choice == "anthropic":
            key = os.getenv("ANTHROPIC_API_KEY", "").strip()
            if not key:
                return None, "ANTHROPIC_API_KEY is not set in .env"
            return ClaudeProvider(key, config.ANTHROPIC_MODEL), f"Claude · {config.ANTHROPIC_MODEL}"
        if choice == "gemini":
            key = (os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY") or "").strip()
            if not key:
                return None, "GEMINI_API_KEY is not set in .env"
            backup = config.GEMINI_FALLBACK_MODEL
            status = f"Gemini · {config.GEMINI_MODEL}" + (f" (backup: {backup})" if backup else "")
            return GeminiProvider(key, config.GEMINI_MODEL, backup), status
    except ImportError as exc:
        return None, f"The SDK for '{choice}' is not installed ({exc.name}). Run: pip install -r requirements.txt"
    return None, "AI is turned off (AI_PROVIDER=none)"


# --------------------------------------------------------------------------
# Prompts
# --------------------------------------------------------------------------

PLANNER_SYSTEM = """You translate a user's question about a tabular dataset into a JSON analysis plan.
Python executes the plan with Pandas; you never calculate or guess any numbers yourself.

Available operations:
{operations}

Rules:
- Use column names exactly as written in the schema. Never invent columns.
- Choose the single operation that best answers the question. Set every unused field to null and filters to [].
- Field meanings: "column" = the single column for aggregate / column_stats / value_counts / sort_rows / outliers;
  "group_by" + "value_column" = the grouping and the measured column for group_aggregate and time_trend.
- Use filters for conditions such as "in the North region" or "where price > 100".
- "Which X has the highest Y" -> group_aggregate with group_by=X, value_column=Y, aggregation=sum (or mean if the user says average), ascending=false, n=null.
- For "top N"/"bottom N" set n and ascending. For trends over time use time_trend.
- If the user asks for a chart of grouped values, use group_aggregate/time_trend and set chart_type.
- If the user refers to a previous answer ("show that as a pie chart"), reuse the previous plan and change only what they asked.
- If the question is ambiguous (e.g. several columns could match), use operation "clarify" with a short question in message.
- If it needs predictions, outside knowledge, or reasons why something happened, use "unsupported" and explain briefly in message."""

EXPLAINER_SYSTEM = """You explain the result of a data analysis that Python has already calculated.
- Use ONLY the numbers in the provided result. Never invent, estimate or recompute numbers.
- Answer the question directly in the first sentence, then add at most 3 short supporting points.
- Bold the key values with **markdown**. Keep numbers formatted as given (thousands separators).
- Don't add currency symbols unless the column name includes one.
- Don't claim causes. If you mention a possible reason, clearly label it as a possibility to verify.
- If the result is empty, say that no matching data was found.
- No headings. Keep it under 120 words."""

INSIGHTS_SYSTEM = """You write the "Key findings" section of a data-analysis report for a non-technical reader.
You receive findings that Python has already calculated. Use ONLY those numbers.
Structure (markdown, no top-level heading):
**Overview** — 1–2 sentences.
**Key findings** — 3–6 bullets, most important first.
**Data quality** — 1–3 bullets.
**Worth investigating** — 1–3 bullets, phrased as questions or hypotheses, clearly not as facts.
Rules: never invent numbers; don't state that correlation implies causation; no recommendations
that the findings don't support; under 300 words."""


def describe_schema(df: pd.DataFrame) -> str:
    """Column names, types and (optionally) a few example values — never full rows."""
    lines = [f"Rows: {len(df):,}", "Columns:"]
    for col in df.columns:
        kind = ae.column_kind(df[col])
        line = f'- "{col}" ({kind})'
        if kind == "numeric":
            line += f" range {ae.fmt(df[col].min())} to {ae.fmt(df[col].max())}"
        elif kind == "datetime":
            s = df[col].dropna()
            if len(s):
                line += f" from {s.min().date()} to {s.max().date()}"
        elif config.AI_SHARE_SAMPLE_VALUES:
            values = df[col].dropna().astype(str).value_counts().head(5).index.tolist()
            unique = df[col].nunique()
            line += f" {unique:,} unique values, e.g. {json.dumps([v[:30] for v in values])}"
        lines.append(line)
    return "\n".join(lines)


class AIService:
    def __init__(self, provider: LLMProvider):
        self.provider = provider

    @property
    def label(self) -> str:
        model = getattr(self.provider, "last_model", None) or self.provider.model
        return f"{self.provider.name} ({model})"

    def plan_question(self, question: str, df: pd.DataFrame, previous_plan: dict | None = None) -> dict:
        ops = "\n".join(f"- {name}: {desc}" for name, desc in OPERATIONS.items())
        prompt = f"Dataset schema:\n{describe_schema(df)}\n\n"
        if previous_plan:
            prompt += f"Previous plan (for follow-up questions):\n{json.dumps(previous_plan, default=str)}\n\n"
        prompt += f"User question: {question}"
        text = self.provider.complete(PLANNER_SYSTEM.format(operations=ops), prompt,
                                      json_schema=PLAN_SCHEMA, effort="low", max_tokens=4000)
        try:
            return json.loads(_strip_code_fence(text))
        except json.JSONDecodeError:
            raise AIError("The AI returned an analysis plan that wasn't valid JSON. Please rephrase.")

    def explain_result(self, question: str, result: AnalysisResult) -> str:
        prompt = (f"User question: {question}\n\n"
                  f"Verified result (computed by Python):\n{result.facts_for_ai(config.MAX_RESULT_ROWS_FOR_AI)}")
        return self.provider.complete(EXPLAINER_SYSTEM, prompt, effort="low", max_tokens=3000).strip()

    def write_insights(self, dataset_name: str, findings: list[str]) -> str:
        prompt = (f"Dataset: {dataset_name}\n\nFindings calculated by Python:\n"
                  + "\n".join(f"- {f}" for f in findings))
        return self.provider.complete(INSIGHTS_SYSTEM, prompt, effort="medium", max_tokens=6000).strip()


def _strip_code_fence(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1].rsplit("```", 1)[0]
    return text.strip()
