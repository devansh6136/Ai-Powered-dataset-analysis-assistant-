"""Read an uploaded CSV / Excel file into a pandas DataFrame, safely.

The loader never edits the user's file. It works on an in-memory copy and
records every change it makes (renamed headers, detected dates/numbers) in
`LoadResult.notes`, so the UI can tell the user exactly what happened.
"""

from __future__ import annotations

import csv
import io
import warnings
from dataclasses import dataclass, field

import pandas as pd

import config


class DatasetError(Exception):
    """A problem with the uploaded file that the user can fix (shown in the UI)."""


@dataclass
class LoadResult:
    df: pd.DataFrame
    filename: str
    notes: list[str] = field(default_factory=list)


def load_dataset(file_bytes: bytes, filename: str) -> LoadResult:
    """Validate and parse an uploaded file. Raises DatasetError on bad input."""
    name = (filename or "").strip()
    ext = "." + name.rsplit(".", 1)[-1].lower() if "." in name else ""

    if ext not in config.ALLOWED_EXTENSIONS:
        raise DatasetError(
            f"Unsupported file type '{ext or 'none'}'. Please upload a .csv or .xlsx file."
        )
    if not file_bytes or not file_bytes.strip():
        raise DatasetError("The file is empty.")
    size_mb = len(file_bytes) / (1024 * 1024)
    if size_mb > config.MAX_FILE_MB:
        raise DatasetError(f"File is {size_mb:.1f} MB; the limit is {config.MAX_FILE_MB} MB.")

    df = _read_csv(file_bytes) if ext == ".csv" else _read_excel(file_bytes)

    if df.shape[1] == 0:
        raise DatasetError("No columns were found. Check that the first row contains headers.")
    if df.shape[0] == 0:
        raise DatasetError("The file has headers but no data rows.")
    if df.shape[0] > config.MAX_ROWS:
        raise DatasetError(f"The file has {df.shape[0]:,} rows; the limit is {config.MAX_ROWS:,}.")

    notes: list[str] = []
    df = _normalize_columns(df, notes)
    df = _infer_types(df, notes)
    return LoadResult(df=df, filename=name, notes=notes)


# --------------------------------------------------------------------------
# Readers
# --------------------------------------------------------------------------

def _read_csv(file_bytes: bytes) -> pd.DataFrame:
    text = _decode(file_bytes)
    delimiter = _sniff_delimiter(text)
    try:
        return pd.read_csv(io.StringIO(text), sep=delimiter, skipinitialspace=True)
    except pd.errors.EmptyDataError:
        raise DatasetError("The file is empty.")
    except pd.errors.ParserError as exc:
        # Keep the message short — never echo raw file contents back.
        raise DatasetError(
            "The CSV could not be parsed (rows have inconsistent numbers of columns). "
            f"Details: {str(exc).splitlines()[0][:150]}"
        )


def _read_excel(file_bytes: bytes) -> pd.DataFrame:
    try:
        # First sheet only; keeps the UI simple.
        return pd.read_excel(io.BytesIO(file_bytes), sheet_name=0, engine="openpyxl")
    except ValueError as exc:
        raise DatasetError(f"The Excel file could not be read: {str(exc)[:150]}")
    except Exception:
        raise DatasetError("The file is not a valid .xlsx workbook (it may be corrupted).")


def _decode(file_bytes: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return file_bytes.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise DatasetError("Could not detect the text encoding of this CSV file.")


def _sniff_delimiter(text: str) -> str:
    """Detect , ; tab or | from the first few KB. Defaults to a comma."""
    sample = text[:20_000]
    try:
        return csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
    except csv.Error:
        return ","


# --------------------------------------------------------------------------
# Cleaning that is always safe (and always reported)
# --------------------------------------------------------------------------

def _normalize_columns(df: pd.DataFrame, notes: list[str]) -> pd.DataFrame:
    """Trim header whitespace, name blank headers, and make names unique."""
    new_names: list[str] = []
    seen: dict[str, int] = {}
    renamed = []
    for i, original in enumerate(df.columns):
        name = str(original).strip()
        if not name or name.lower().startswith("unnamed:"):
            name = f"Column_{i + 1}"
        base = name
        if base in seen:
            seen[base] += 1
            name = f"{base}_{seen[base]}"
        else:
            seen[base] = 1
        if name != str(original):
            renamed.append(f"'{original}' → '{name}'")
        new_names.append(name)

    if renamed:
        shown = ", ".join(renamed[:6]) + (" …" if len(renamed) > 6 else "")
        notes.append(f"Renamed {len(renamed)} column header(s) to be clean and unique: {shown}")
    df = df.copy()
    df.columns = new_names
    return df


def is_text_column(series: pd.Series) -> bool:
    """True for text columns (works for pandas 2 'object' and pandas 3 'str' dtypes)."""
    return not (
        pd.api.types.is_bool_dtype(series)
        or pd.api.types.is_numeric_dtype(series)
        or pd.api.types.is_datetime64_any_dtype(series)
    )


def _infer_types(df: pd.DataFrame, notes: list[str]) -> pd.DataFrame:
    """Turn text columns that are really numbers or dates into proper types."""
    for col in df.columns:
        series = df[col]
        if not is_text_column(series):
            continue
        non_null = series.dropna().astype(str).str.strip()
        non_null = non_null[non_null != ""]
        if non_null.empty:
            continue

        # Numbers stored as text, e.g. "1,200" or "₹ 5,000"
        cleaned = non_null.str.replace(r"[,\s₹$€£%]", "", regex=True)
        numeric = pd.to_numeric(cleaned, errors="coerce")
        if numeric.notna().mean() >= 0.95:
            full = series.astype(str).str.replace(r"[,\s₹$€£%]", "", regex=True)
            df[col] = pd.to_numeric(full, errors="coerce")  # blanks / "nan" become NaN
            notes.append(f"'{col}' contained numbers stored as text; converted to numeric.")
            continue

        # Dates: only try when values look date-like (contain digits and a separator)
        sample = non_null.head(200)
        if not sample.str.contains(r"\d", regex=True).all():
            continue
        if not sample.str.contains(r"[-/.:]|\d{4}", regex=True).all():
            continue
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            parsed_sample = pd.to_datetime(sample, errors="coerce")
            if parsed_sample.notna().mean() >= 0.9:
                df[col] = pd.to_datetime(series, errors="coerce")
                notes.append(f"'{col}' looks like dates; converted to a date type for time analysis.")
    return df
