"""Optional cleaning steps. Nothing runs automatically — the user picks them.

suggest_cleaning() lists the steps that would actually change something,
with the impact spelled out. apply_cleaning() runs only the chosen ones and
returns a log, so the user always knows how their data was changed.
"""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from services import analysis_engine as ae


@dataclass
class CleaningSuggestion:
    action: str
    label: str
    impact: str


def _plural(count: int, word: str) -> str:
    return f"{count:,} {word}{'' if count == 1 else 's'}"


def _non_empty_columns(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if not df[c].isna().all()]


def suggest_cleaning(df: pd.DataFrame) -> list[CleaningSuggestion]:
    out = []
    types = ae.column_types(df)
    dupes = int(df.duplicated().sum())
    if dupes:
        out.append(CleaningSuggestion("drop_duplicates", "Remove duplicate rows", f"removes {_plural(dupes, 'row')}"))
    empty_cols = [c for c in df.columns if df[c].isna().all()]
    if empty_cols:
        out.append(CleaningSuggestion("drop_empty_columns", "Remove completely empty columns",
                                      f"removes {_plural(len(empty_cols), 'column')}: {', '.join(empty_cols[:5])}"))
    empty_rows = int(df.isna().all(axis=1).sum())
    if empty_rows:
        out.append(CleaningSuggestion("drop_empty_rows", "Remove completely empty rows", f"removes {_plural(empty_rows, 'row')}"))
    text_cols = types["categorical"]
    untrimmed = sum(int((df[c].dropna().astype(str) != df[c].dropna().astype(str).str.strip()).sum())
                    for c in text_cols)
    if untrimmed:
        out.append(CleaningSuggestion("trim_text", "Trim extra spaces in text values", f"fixes {_plural(untrimmed, 'value')}"))
    num_missing = int(df[types["numeric"]].isna().sum().sum()) if types["numeric"] else 0
    if num_missing:
        out.append(CleaningSuggestion("fill_numeric_median", "Fill missing numbers with the column median",
                                      f"fills {_plural(num_missing, 'cell')}"))
    text_missing = int(df[text_cols].isna().sum().sum()) if text_cols else 0
    if text_missing:
        out.append(CleaningSuggestion("fill_text_unknown", "Fill missing text with 'Unknown'",
                                      f"fills {_plural(text_missing, 'cell')}"))
    # Completely empty columns are ignored here, otherwise every row would count as "missing".
    rows_with_missing = int(df[_non_empty_columns(df)].isna().any(axis=1).sum())
    if rows_with_missing:
        out.append(CleaningSuggestion("drop_rows_with_missing", "Remove rows that have any missing value",
                                      f"removes {_plural(rows_with_missing, 'row')} "
                                      f"({rows_with_missing / len(df) * 100:.1f}%)"))
    return out


def apply_cleaning(df: pd.DataFrame, actions: list[str]) -> tuple[pd.DataFrame, list[str]]:
    """Apply the chosen actions in a safe order. Returns (new DataFrame, change log)."""
    data = df.copy()
    log: list[str] = []
    types = ae.column_types(data)

    def record(message: str, before: int) -> None:
        removed = before - len(data)
        log.append(f"{message} ({_plural(removed, 'row')} removed)" if removed else message)

    if "drop_empty_columns" in actions:
        cols = [c for c in data.columns if data[c].isna().all()]
        data = data.drop(columns=cols)
        log.append(f"Removed empty columns: {', '.join(cols) or 'none'}")
        types = ae.column_types(data)
    if "drop_empty_rows" in actions:
        before = len(data)
        data = data.dropna(how="all")
        record("Removed completely empty rows", before)
    if "trim_text" in actions:
        for c in types["categorical"]:
            data[c] = data[c].map(lambda v: v.strip() if isinstance(v, str) else v)
        log.append("Trimmed spaces in text columns")
    if "drop_duplicates" in actions:
        before = len(data)
        data = data.drop_duplicates()
        record("Removed duplicate rows", before)
    if "drop_rows_with_missing" in actions:
        before = len(data)
        data = data.dropna(subset=_non_empty_columns(data))
        record("Removed rows with missing values", before)
    if "fill_numeric_median" in actions:
        for c in types["numeric"]:
            if c in data and data[c].isna().any():
                median = data[c].median()
                data[c] = data[c].fillna(median)
                log.append(f"Filled missing '{c}' with median {ae.fmt(median)}")
    if "fill_text_unknown" in actions:
        for c in types["categorical"]:
            if c in data and data[c].isna().any():
                data[c] = data[c].fillna("Unknown")
                log.append(f"Filled missing '{c}' with 'Unknown'")
    return data.reset_index(drop=True), log
