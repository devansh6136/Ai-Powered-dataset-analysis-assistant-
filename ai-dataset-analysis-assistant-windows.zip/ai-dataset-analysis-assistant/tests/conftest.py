import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


@pytest.fixture
def sales_df() -> pd.DataFrame:
    """The 5-row example from the project brief (answers are easy to verify by hand)."""
    return pd.DataFrame({
        "Product": ["Laptop", "Mobile", "Laptop", "Mobile", "Tablet"],
        "Month": ["January", "January", "February", "February", "February"],
        "Units Sold": [15, 30, 20, 25, 12],
        "Revenue": [750000, 450000, 1000000, 375000, 240000],
        "Date": pd.to_datetime(["2025-01-10", "2025-01-15", "2025-02-03", "2025-02-20", "2025-02-25"]),
    })


@pytest.fixture
def messy_df() -> pd.DataFrame:
    return pd.DataFrame({
        "City": ["Delhi", "Pune", None, "Delhi", "Delhi", "  Pune "],
        "Score": [10.0, None, 30.0, 10.0, 10.0, 50.0],
        "Empty": [None] * 6,
    })


@pytest.fixture
def sample_bytes():
    def read(name: str) -> bytes:
        return (ROOT / "sample_data" / name).read_bytes()
    return read
