"""AI integration tests use a fake provider — no network, no API key, no cost."""

import json

import pytest

import config
from services import ai_service
from services.ai_service import AIError, AIService, LLMProvider, describe_schema
from services.chat_engine import answer_question
from services.query_planner import empty_plan
from services.report_generator import build_html_report
from services.insights import compute_findings


class FakeProvider(LLMProvider):
    name, model = "Fake", "fake-1"

    def __init__(self, plan=None, explanation="Laptop earned the most.", fail_on=None):
        self.plan, self.explanation, self.fail_on = plan, explanation, fail_on
        self.prompts = []

    def complete(self, system, prompt, json_schema=None, effort="low", max_tokens=4000):
        self.prompts.append(prompt)
        kind = "plan" if json_schema else "explain"
        if self.fail_on == kind:
            raise AIError("simulated outage")
        return json.dumps(self.plan) if json_schema else self.explanation


def test_ai_path_plans_computes_and_explains(sales_df):
    plan = empty_plan("group_aggregate", group_by="Product", value_column="Revenue", aggregation="sum")
    provider = FakeProvider(plan)
    answer = answer_question("Which product has the highest revenue?", sales_df, AIService(provider))
    assert answer.kind == "answer"
    assert answer.text == "Laptop earned the most."
    assert answer.table.iloc[0]["Total Revenue"] == 1_750_000          # number came from Pandas
    assert answer.ai_calls == 2
    # The explanation prompt contains the verified numbers…
    assert "1750000" in provider.prompts[1].replace(",", "").replace(".0", "")
    # …but the planning prompt never contains individual row values (only column ranges).
    for row_value in ("750,000", "450,000", "375,000", "750000", "450000", "375000"):
        assert row_value not in provider.prompts[0]


def test_hallucinated_column_is_caught(sales_df):
    plan = empty_plan("aggregate", column="Profit Margin", aggregation="mean")
    answer = answer_question("What's the profit margin?", sales_df, AIService(FakeProvider(plan)))
    assert answer.kind == "clarify" and "Profit Margin" in answer.text
    assert answer.table is None


def test_unsupported_question_is_not_answered(sales_df):
    plan = empty_plan("unsupported", message="I can only analyse the uploaded data, not forecast it.")
    answer = answer_question("Predict next year's sales", sales_df, AIService(FakeProvider(plan)))
    assert answer.kind == "clarify" and "forecast" in answer.text


def test_planning_failure_is_reported(sales_df):
    answer = answer_question("anything", sales_df, AIService(FakeProvider(fail_on="plan")))
    assert answer.kind == "error" and "simulated outage" in answer.text


def test_ai_outage_falls_back_to_rule_matcher(sales_df):
    answer = answer_question("Which product has the highest revenue?", sales_df,
                             AIService(FakeProvider(fail_on="plan")))
    assert answer.kind == "answer"
    assert answer.table.iloc[0]["Total Revenue"] == 1_750_000
    assert "rule matcher" in answer.source and answer.warnings


def test_explanation_failure_falls_back_to_calculated_summary(sales_df):
    plan = empty_plan("aggregate", column="Revenue", aggregation="mean")
    answer = answer_question("average revenue?", sales_df, AIService(FakeProvider(plan, fail_on="explain")))
    assert answer.kind == "answer"
    assert "563,000" in answer.text
    assert answer.warnings


def test_invalid_json_from_ai_raises(sales_df):
    class Garbage(FakeProvider):
        def complete(self, *args, **kwargs):
            return "Sure! Here is your plan: operation=sum"
    with pytest.raises(AIError):
        AIService(Garbage()).plan_question("q", sales_df)


def test_long_questions_are_rejected(sales_df):
    answer = answer_question("x" * (config.MAX_QUESTION_CHARS + 1), sales_df, None)
    assert answer.kind == "error"


def test_schema_description_respects_privacy_setting(sales_df, monkeypatch):
    monkeypatch.setattr(config, "AI_SHARE_SAMPLE_VALUES", False)
    text = describe_schema(sales_df)
    assert '"Product" (categorical)' in text and "Laptop" not in text
    monkeypatch.setattr(config, "AI_SHARE_SAMPLE_VALUES", True)
    assert "Laptop" in describe_schema(sales_df)


def test_no_key_means_no_provider(monkeypatch):
    monkeypatch.setattr(config, "AI_PROVIDER", "anthropic")
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    provider, status = ai_service.get_provider()
    assert provider is None and "ANTHROPIC_API_KEY" in status


def test_report_is_escaped_and_secret_free(sales_df, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-secret-should-not-leak")
    html = build_html_report("<script>alert(1)</script>.csv", sales_df, compute_findings(sales_df), [],
                             ai_summary="**Laptop** leads.\n- point one")
    assert "<script>alert(1)</script>" not in html
    assert "sk-ant-secret" not in html
    assert "<strong>Laptop</strong>" in html and "<li>point one</li>" in html


def _gemini_with_fake_client(responses):
    """A GeminiProvider whose network client is replaced by a fake (no API calls, no quota used)."""
    from types import SimpleNamespace
    from services.ai_service import GeminiProvider
    provider = GeminiProvider("fake-key", "main-model", "backup-model")
    calls = []

    def generate_content(model, contents, config):
        calls.append(model)
        outcome = responses[model]
        if isinstance(outcome, Exception):
            raise outcome
        return SimpleNamespace(text=outcome, candidates=[])

    provider.client = SimpleNamespace(models=SimpleNamespace(generate_content=generate_content))
    return provider, calls


def _gemini_error(code):
    from google.genai import errors
    body = {"error": {"code": code, "message": "busy", "status": "UNAVAILABLE"}}
    return errors.ServerError(code, body) if code >= 500 else errors.ClientError(code, body)


def test_gemini_switches_to_backup_model_when_busy():
    provider, calls = _gemini_with_fake_client({"main-model": _gemini_error(503), "backup-model": "OK"})
    assert provider.complete("system", "prompt") == "OK"
    assert calls == ["main-model", "backup-model"]
    assert AIService(provider).label == "Google Gemini (backup-model)"


def test_gemini_reports_clear_error_when_both_models_fail():
    provider, _ = _gemini_with_fake_client({"main-model": _gemini_error(429), "backup-model": _gemini_error(503)})
    with pytest.raises(AIError, match="backup-model.*overloaded"):
        provider.complete("system", "prompt")


def test_gemini_bad_key_does_not_use_backup():
    provider, calls = _gemini_with_fake_client({"main-model": _gemini_error(403), "backup-model": "OK"})
    with pytest.raises(AIError, match="key was rejected"):
        provider.complete("system", "prompt")
    assert calls == ["main-model"]


def test_explanations_can_be_switched_off(sales_df, monkeypatch):
    monkeypatch.setattr(config, "AI_EXPLAIN_ANSWERS", False)
    plan = empty_plan("aggregate", column="Revenue", aggregation="mean")
    steps = []
    answer = answer_question("average revenue?", sales_df, AIService(FakeProvider(plan)), on_step=steps.append)
    assert answer.ai_calls == 1 and "563,000" in answer.text
    assert any("Understanding" in s for s in steps) and not any("explanation" in s for s in steps)
