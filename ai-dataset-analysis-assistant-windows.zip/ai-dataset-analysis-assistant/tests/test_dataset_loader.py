import io

import pandas as pd
import pytest

import config
from services.dataset_loader import DatasetError, load_dataset


def test_loads_csv(sample_bytes):
    result = load_dataset(sample_bytes("sales_dataset.csv"), "sales_dataset.csv")
    assert result.df.shape == (604, 11)
    assert pd.api.types.is_datetime64_any_dtype(result.df["Order Date"])
    assert any("Order Date" in n for n in result.notes)   # the conversion is reported


def test_loads_excel(sample_bytes):
    result = load_dataset(sample_bytes("employees.xlsx"), "employees.xlsx")
    assert result.df.shape == (150, 7)
    assert pd.api.types.is_numeric_dtype(result.df["Annual Salary"])


@pytest.mark.parametrize("name", ["data.txt", "data.json", "data", "report.pdf"])
def test_rejects_unsupported_types(name):
    with pytest.raises(DatasetError, match="Unsupported file type"):
        load_dataset(b"a,b\n1,2\n", name)


@pytest.mark.parametrize("content", [b"", b"   \n  "])
def test_rejects_empty_file(content):
    with pytest.raises(DatasetError, match="empty"):
        load_dataset(content, "empty.csv")


def test_rejects_header_only_file():
    with pytest.raises(DatasetError, match="no data rows"):
        load_dataset(b"Name,Age\n", "header_only.csv")


def test_rejects_malformed_csv():
    bad = b'a,b\n1,2\n3,4,5,6\n"unclosed,7\n'
    with pytest.raises(DatasetError):
        load_dataset(bad, "bad.csv")


def test_rejects_corrupt_excel():
    with pytest.raises(DatasetError, match="xlsx|Excel"):
        load_dataset(b"this is not a real workbook", "broken.xlsx")


def test_rejects_too_large(monkeypatch):
    monkeypatch.setattr(config, "MAX_FILE_MB", 0.00001)
    with pytest.raises(DatasetError, match="limit"):
        load_dataset(b"a,b\n" + b"1,2\n" * 100, "big.csv")


def test_detects_semicolon_delimiter():
    df = load_dataset(b"Name;Score\nAsha;90\nRavi;85\n", "semi.csv").df
    assert list(df.columns) == ["Name", "Score"]
    assert df["Score"].sum() == 175


def test_normalizes_messy_headers(sample_bytes):
    result = load_dataset(sample_bytes("messy_dataset.csv"), "messy_dataset.csv")
    cols = list(result.df.columns)
    assert "Product Name" in cols                 # whitespace trimmed
    assert "Column_4" in cols                     # blank header named
    assert len(cols) == len(set(cols))            # all unique
    assert any("Renamed" in n for n in result.notes)


def test_converts_numbers_stored_as_text(sample_bytes):
    df = load_dataset(sample_bytes("messy_dataset.csv"), "messy_dataset.csv").df
    assert pd.api.types.is_numeric_dtype(df["Price"])
    assert df["Price"].iloc[0] == 1200            # "1,200" -> 1200


def test_duplicate_header_names_made_unique():
    df = load_dataset(b"Score,Score,Score\n1,2,3\n", "dupe.csv").df
    assert list(df.columns) == ["Score", "Score_2", "Score_3"] or len(set(df.columns)) == 3


def test_excel_roundtrip_with_dates():
    buffer = io.BytesIO()
    pd.DataFrame({"When": pd.to_datetime(["2025-01-01", "2025-02-01"]), "Value": [1, 2]}).to_excel(buffer, index=False)
    df = load_dataset(buffer.getvalue(), "dates.xlsx").df
    assert pd.api.types.is_datetime64_any_dtype(df["When"])
