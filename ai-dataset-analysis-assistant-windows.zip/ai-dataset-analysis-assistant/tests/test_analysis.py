"""Every calculation is checked against a value computed independently (by hand or plain Pandas)."""

import math

import pandas as pd
import pytest

from services import analysis_engine as ae
from services.data_cleaner import apply_cleaning, suggest_cleaning
from services.dataset_loader import load_dataset
from services.insights import compute_findings


def test_overview_counts(sales_df, messy_df):
    o = ae.dataset_overview(sales_df)
    assert (o["rows"], o["columns"], o["missing_cells"], o["duplicate_rows"]) == (5, 5, 0, 0)
    assert o["numeric_columns"] == 2 and o["datetime_columns"] == 1

    m = ae.dataset_overview(messy_df)
    assert m["missing_cells"] == 1 + 1 + 6
    assert m["duplicate_rows"] == 2      # rows 3 and 4 copy row 0


def test_column_types(sales_df):
    t = ae.column_types(sales_df)
    assert t["numeric"] == ["Units Sold", "Revenue"]
    assert t["categorical"] == ["Product", "Month"]
    assert t["datetime"] == ["Date"]


def test_revenue_by_product_matches_hand_calculation(sales_df):
    table = ae.group_aggregate(sales_df, "Product", "Revenue", "sum")
    assert list(table["Product"]) == ["Laptop", "Mobile", "Tablet"]
    assert list(table["Total Revenue"]) == [1_750_000, 825_000, 240_000]


def test_group_aggregate_top_n_and_ascending(sales_df):
    bottom = ae.group_aggregate(sales_df, "Product", "Revenue", "sum", ascending=True, n=1)
    assert bottom.iloc[0]["Product"] == "Tablet"
    counts = ae.group_aggregate(sales_df, "Month", None, "count")
    assert dict(zip(counts["Month"], counts["Number of rows"])) == {"February": 3, "January": 2}


def test_group_aggregate_rejects_text_sum(sales_df):
    with pytest.raises(ae.AnalysisError):
        ae.group_aggregate(sales_df, "Month", "Product", "sum")


@pytest.mark.parametrize("agg,expected", [
    ("mean", 563_000.0), ("sum", 2_815_000.0), ("max", 1_000_000.0),
    ("min", 240_000.0), ("median", 450_000.0), ("count", 5),
])
def test_aggregate_column(sales_df, agg, expected):
    assert ae.aggregate_column(sales_df, "Revenue", agg) == pytest.approx(expected)


def test_filters(sales_df):
    rows, desc = ae.filter_rows(sales_df, [{"column": "Product", "operator": "==", "value": "laptop"}])
    assert len(rows) == 2 and desc == ["Product == laptop"]          # case-insensitive
    rows, _ = ae.filter_rows(sales_df, [{"column": "Revenue", "operator": ">=", "value": "450000"}])
    assert sorted(rows["Revenue"]) == [450000, 750000, 1000000]
    rows, _ = ae.filter_rows(sales_df, [{"column": "Month", "operator": "contains", "value": "jan"}])
    assert len(rows) == 2
    rows, _ = ae.filter_rows(sales_df, [{"column": "Date", "operator": ">", "value": "2025-02-01"}])
    assert len(rows) == 3


def test_filter_validation(sales_df):
    with pytest.raises(ae.AnalysisError):
        ae.filter_rows(sales_df, [{"column": "Revenue", "operator": ">", "value": "lots"}])
    with pytest.raises(ae.AnalysisError):
        ae.filter_rows(sales_df, [{"column": "Product", "operator": ">", "value": "A"}])


def test_time_trend_monthly(sales_df):
    trend = ae.time_trend(sales_df, "Date", "Revenue", "sum", "M")
    assert list(trend["Total Revenue"]) == [1_200_000, 1_615_000]
    assert ae.period_label(trend["Period"].iloc[1], "M") == "Feb 2025"


def test_correlation_matches_pandas(sales_df):
    pairs = ae.strongest_correlations(sales_df)
    expected = sales_df["Units Sold"].corr(sales_df["Revenue"])
    assert pairs.iloc[0]["Correlation"] == pytest.approx(round(expected, 3))


def test_correlation_needs_two_numeric_columns():
    with pytest.raises(ae.AnalysisError):
        ae.correlation_matrix(pd.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]}))


def test_outliers_iqr():
    df = pd.DataFrame({"v": [10, 11, 12, 13, 12, 11, 500]})
    info = ae.outliers_iqr(df, "v")
    assert info["outlier_count"] == 1 and info["rows"]["v"].iloc[0] == 500


def test_missing_and_duplicates(messy_df):
    missing = ae.missing_values(messy_df)
    assert dict(zip(missing["Column"], missing["Missing"])) == {"Empty": 6, "City": 1, "Score": 1}
    count, rows = ae.duplicate_rows(messy_df)
    assert count == 2 and len(rows) == 3


def test_identifier_columns_are_not_measures(sample_bytes):
    df = load_dataset(sample_bytes("sales_dataset.csv"), "s.csv").df
    assert "Order ID" not in ae.grouping_columns(df)
    assert "Revenue" in ae.measure_columns(df)


@pytest.mark.parametrize("value,text", [(1234567.891, "1,234,567.89"), (5.0, "5"), (42, "42"),
                                        (None, "—"), (float("nan"), "—")])
def test_fmt(value, text):
    assert ae.fmt(value) == text


def test_cleaning_is_opt_in_and_logged(messy_df):
    actions = {s.action for s in suggest_cleaning(messy_df)}
    assert {"drop_duplicates", "drop_empty_columns", "trim_text", "fill_numeric_median"} <= actions
    cleaned, log = apply_cleaning(messy_df, ["drop_duplicates", "drop_empty_columns", "trim_text"])
    assert "Empty" not in cleaned.columns
    assert len(cleaned) == 4
    assert "Pune" in set(cleaned["City"].dropna())
    assert log and messy_df.shape == (6, 3)        # original untouched


def test_drop_missing_ignores_fully_empty_columns(messy_df):
    impact = {s.action: s.impact for s in suggest_cleaning(messy_df)}
    assert impact["drop_rows_with_missing"].startswith("removes 2 rows")   # not all 6
    cleaned, _ = apply_cleaning(messy_df, ["drop_rows_with_missing"])
    assert len(cleaned) == 4


def test_findings_use_real_numbers(sample_bytes):
    df = load_dataset(sample_bytes("sales_dataset.csv"), "s.csv").df
    findings = compute_findings(df)
    text = " ".join(f.text for f in findings)
    total = df["Revenue"].sum()
    assert ae.fmt(total) in text                                     # overall total is quoted exactly
    top_product = df.groupby("Product")["Revenue"].sum().idxmax()
    assert f"'{top_product}' has the highest total Revenue" in text
    assert any(f.category == "Data quality" and "duplicate" in f.text for f in findings)
    assert not math.isnan(total)
