import pytest

from services.query_planner import (OPERATIONS, PLAN_SCHEMA, PlanError, empty_plan, execute_plan,
                                    plan_to_pandas, validate_plan)
from services.rule_planner import plan_from_rules


def run(plan, df):
    return execute_plan(validate_plan(plan, df), df)


def test_schema_requires_every_field():
    assert set(PLAN_SCHEMA["required"]) == set(PLAN_SCHEMA["properties"])
    assert PLAN_SCHEMA["additionalProperties"] is False
    assert set(PLAN_SCHEMA["properties"]["operation"]["enum"]) == set(OPERATIONS)


def test_column_names_resolve_forgivingly(sales_df):
    plan = validate_plan(empty_plan("aggregate", column="units_sold", aggregation="sum"), sales_df)
    assert plan["column"] == "Units Sold"


def test_unknown_column_is_rejected(sales_df):
    with pytest.raises(PlanError, match="couldn't find a column called 'Profit'"):
        validate_plan(empty_plan("aggregate", column="Profit", aggregation="sum"), sales_df)


def test_unknown_operation_is_rejected(sales_df):
    with pytest.raises(PlanError):
        validate_plan(empty_plan("exec_python", column="Revenue"), sales_df)
    with pytest.raises(PlanError):
        validate_plan("import os; os.system('rm -rf /')", sales_df)


def test_numeric_aggregation_on_text_is_rejected(sales_df):
    with pytest.raises(PlanError, match="isn't numeric"):
        validate_plan(empty_plan("aggregate", column="Product", aggregation="mean"), sales_df)


def test_bad_aggregation_and_filter_operator_rejected(sales_df):
    with pytest.raises(PlanError):
        validate_plan(empty_plan("aggregate", column="Revenue", aggregation="DROP TABLE"), sales_df)
    bad_filter = empty_plan("count_rows", filters=[{"column": "Revenue", "operator": "=~", "value": 1}])
    with pytest.raises(PlanError):
        validate_plan(bad_filter, sales_df)


def test_n_is_clamped(sales_df):
    plan = validate_plan(empty_plan("value_counts", column="Product", n=10_000), sales_df)
    assert plan["n"] == 100


def test_highest_revenue_product(sales_df):
    result = run(empty_plan("group_aggregate", group_by="Product", value_column="Revenue",
                            aggregation="sum"), sales_df)
    assert result.table.iloc[0].tolist() == ["Laptop", 1_750_000]
    assert "**Laptop** has the highest total revenue: **1,750,000** (62.2% of the overall total)" in result.summary
    assert result.chart is not None


def test_filters_are_applied_before_the_operation(sales_df):
    plan = empty_plan("aggregate", column="Revenue", aggregation="sum",
                      filters=[{"column": "Month", "operator": "==", "value": "February"}])
    result = run(plan, sales_df)
    assert result.facts["value"] == 1_000_000 + 375_000 + 240_000
    assert result.rows_used == 3


def test_no_matching_rows_does_not_invent_anything(sales_df):
    plan = empty_plan("aggregate", column="Revenue", aggregation="sum",
                      filters=[{"column": "Product", "operator": "==", "value": "Spaceship"}])
    result = run(plan, sales_df)
    assert "No rows match" in result.summary and result.table is None


def test_bar_chart_request_reroutes_to_group_aggregate(sales_df):
    plan = validate_plan(empty_plan("chart", chart_type="bar", x="Product", y="Revenue"), sales_df)
    assert plan["operation"] == "group_aggregate" and plan["aggregation"] == "sum"


def test_time_trend_picks_date_column(sales_df):
    result = run(empty_plan("time_trend", value_column="Revenue"), sales_df)
    assert list(result.table.iloc[:, 1]) == [1_200_000, 1_615_000]
    assert "Feb 2025" in result.summary


def test_time_trend_without_dates_asks_for_help(sales_df):
    with pytest.raises(PlanError, match="no date column"):
        validate_plan(empty_plan("time_trend"), sales_df.drop(columns="Date"))


def test_every_operation_executes(sales_df):
    plans = [
        empty_plan("dataset_summary"), empty_plan("column_stats", column="Revenue"),
        empty_plan("column_stats", column="Product"), empty_plan("aggregate", column="Revenue", aggregation="mean"),
        empty_plan("sort_rows", column="Revenue", n=2), empty_plan("value_counts", column="Month"),
        empty_plan("count_rows"), empty_plan("correlation"), empty_plan("outliers", column="Revenue"),
        empty_plan("missing_values"), empty_plan("duplicates"),
        empty_plan("chart", chart_type="histogram", column="Revenue"),
        empty_plan("chart", chart_type="scatter", x="Units Sold", y="Revenue"),
        empty_plan("chart", chart_type="box", column="Revenue"),
        empty_plan("group_aggregate", group_by="Product", value_column="Revenue", chart_type="pie"),
    ]
    for plan in plans:
        result = run(plan, sales_df)
        assert result.summary, plan["operation"]


def test_clarify_and_unsupported_pass_through(sales_df):
    plan = validate_plan(empty_plan("unsupported", message="I can't predict the future."), sales_df)
    assert plan["message"] == "I can't predict the future."


def test_pandas_code_preview(sales_df):
    plan = validate_plan(empty_plan("group_aggregate", group_by="Product", value_column="Revenue",
                                    aggregation="sum", n=5), sales_df)
    assert plan_to_pandas(plan) == 'df.groupby("Product")["Revenue"].sum().sort_values(ascending=False).head(5)'


@pytest.mark.parametrize("question,operation", [
    ("Which product has the highest revenue?", "group_aggregate"),
    ("What is the average revenue?", "aggregate"),
    ("Are there missing values?", "missing_values"),
    ("Find duplicate rows", "duplicates"),
    ("Summarize this dataset", "dataset_summary"),
    ("Show the correlation between numerical columns", "correlation"),
    ("Show monthly revenue trend", "time_trend"),
    ("Show a histogram of revenue", "chart"),
    ("Top 2 products by units sold", "group_aggregate"),
    ("What's the capital of France?", "clarify"),
])
def test_rule_planner(sales_df, question, operation):
    plan = plan_from_rules(question, sales_df)
    assert plan["operation"] == operation
    if operation != "clarify":
        run(plan, sales_df)          # every rule-made plan must also validate and run


def test_rule_planner_top_n(sales_df):
    plan = plan_from_rules("Show the top 2 products by units sold", sales_df)
    assert (plan["group_by"], plan["value_column"], plan["n"]) == ("Product", "Units Sold", 2)


def test_column_given_in_neighbouring_field_is_accepted(sales_df):
    # Real model output seen with Gemini: the column was put in value_column for "aggregate".
    plan = empty_plan("aggregate", value_column="Revenue", aggregation="sum",
                      filters=[{"column": "Month", "operator": "==", "value": "January"}])
    result = run(plan, sales_df)
    assert result.facts["value"] == 750_000 + 450_000
