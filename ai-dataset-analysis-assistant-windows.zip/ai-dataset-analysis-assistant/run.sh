#!/usr/bin/env bash
# Start the app with the project's own Python environment.
#
# The environment lives OUTSIDE the project folder (~/.venvs/...) on purpose:
# if the project sits in an iCloud-synced folder (Desktop/Documents), iCloud
# offloads the thousands of small library files and every import becomes very slow.
set -e
cd "$(dirname "$0")"

VENV="${VENV:-$HOME/.venvs/ai-dataset-analysis-assistant}"

if [ ! -x "$VENV/bin/streamlit" ]; then
  echo "First run: creating the Python environment in $VENV ..."
  python3 -m venv "$VENV"
  "$VENV/bin/pip" install --quiet --upgrade pip
  "$VENV/bin/pip" install --quiet -r requirements.txt
  echo "Environment ready."
fi

if [ "$1" = "check" ]; then          # ./run.sh check  -> test the AI provider in .env
  exec "$VENV/bin/python" scripts/check_ai.py
fi
if [ "$1" = "test" ]; then           # ./run.sh test   -> run the automated tests
  exec "$VENV/bin/python" -m pytest -q
fi

exec "$VENV/bin/streamlit" run app.py "$@"
