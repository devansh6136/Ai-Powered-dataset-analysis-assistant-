import os
import json
import re
from io import BytesIO

import pandas as pd
import plotly.express as px
import streamlit as st
from dotenv import load_dotenv

load_dotenv()

APP_TITLE = "AI-Powered Dataset Analysis Assistant"
MAX_PREVIEW_ROWS = 100

st.set_page_config(page_title=APP_TITLE, page_icon="📊", layout="wide")

# ---------- Data helpers ----------
def clean_column_names(df):
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df

def dataset_profile(df):
    profile = {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "column_names": [str(c) for c in df.columns],
        "data_types": {str(k): str(v) for k, v in df.dtypes.items()},
        "missing_values": {str(k): int(v) for k, v in df.isna().sum().items()},
        "duplicate_rows": int(df.duplicated().sum()),
    }
    numeric = df.select_dtypes(include="number")
    if not numeric.empty:
        profile["numeric_summary"] = numeric.describe().round(3).to_dict()
    profile["sample_rows"] = df.head(5).fillna("").astype(str).to_dict(orient="records")
    return profile

def detect_column(df, keywords):
    """Find a column whose name includes one of the supplied keywords."""
    for keyword in keywords:
        for col in df.columns:
            if keyword.lower() in str(col).lower():
                return col
    return None

def basic_analysis(df, question):
    """
    Perform safe, common data operations with pandas.
    Returns a result dictionary that the LLM can explain.
    """
    q = question.lower()
    numeric_cols = list(df.select_dtypes(include="number").columns)
    date_cols = list(df.select_dtypes(include=["datetime", "datetimetz"]).columns)

    # Try to parse date-looking object columns for chart/trend questions.
    for col in df.columns:
        if col not in date_cols and any(k in str(col).lower() for k in ["date", "time", "month", "year"]):
            try:
                parsed = pd.to_datetime(df[col], errors="coerce")
                if parsed.notna().sum() >= max(3, int(len(df) * 0.5)):
                    df = df.copy()
                    df[col] = parsed
                    date_cols.append(col)
            except Exception:
                pass

    # Dataset overview / missing / duplicates
    if any(k in q for k in ["missing", "null", "empty", "blank", "duplicate", "data quality", "overview", "summary", "describe", "dataset"]):
        profile = dataset_profile(df)
        return {
            "kind": "overview",
            "answer_title": "Dataset overview and data quality",
            "result": {
                "rows": profile["rows"],
                "columns": profile["columns"],
                "column_names": profile["column_names"],
                "data_types": profile["data_types"],
                "missing_values": profile["missing_values"],
                "duplicate_rows": profile["duplicate_rows"],
                "numeric_summary": profile.get("numeric_summary", {}),
            },
            "chart": None,
            "note": "This result was calculated from the uploaded data using Python and pandas."
        }

    # Correlation
    if "correlation" in q or "correlat" in q or "relationship between" in q:
        if len(numeric_cols) >= 2:
            corr = df[numeric_cols].corr(numeric_only=True).round(3)
            return {
                "kind": "correlation",
                "answer_title": "Correlation between numeric columns",
                "result": corr.to_dict(),
                "chart": {"type": "correlation", "columns": numeric_cols},
                "note": "Correlation ranges from -1 to 1. Correlation does not prove causation."
            }
        return {"kind": "text", "answer_title": "Correlation", "result": "This dataset needs at least two numeric columns for correlation analysis.", "chart": None}

    # Find a numeric metric requested by the user
    metric = None
    metric_keywords = {
        "sales": ["sales", "revenue", "amount", "turnover"],
        "profit": ["profit", "income", "margin"],
        "quantity": ["quantity", "qty", "units"],
        "discount": ["discount"],
        "price": ["price", "cost"],
        "age": ["age"],
    }
    for _, words in metric_keywords.items():
        if any(word in q for word in words):
            metric = detect_column(df, words)
            if metric in numeric_cols:
                break
            metric = None

    if metric is None and numeric_cols:
        # Prefer a numeric column explicitly mentioned in the question.
        for col in numeric_cols:
            if str(col).lower() in q:
                metric = col
                break

    # Group-by questions: by category/region/product/country/etc.
    group_keywords = ["category", "region", "product", "country", "city", "segment", "department", "month", "year", "by "]
    wants_group = any(k in q for k in group_keywords) and any(k in q for k in ["by", "per", "each", "compare", "highest", "lowest", "most", "least", "top", "group", "trend", "chart", "graph"])
    group_col = None
    preferred_group_terms = ["category", "region", "product", "country", "city", "segment", "department", "customer", "state", "month", "year"]
    for term in preferred_group_terms:
        if term in q:
            group_col = detect_column(df, [term])
            if group_col:
                break
    if group_col is None and wants_group:
        # If the question contains "by <column name>", use that column.
        for col in df.columns:
            if str(col).lower() in q and col != metric:
                group_col = col
                break
        if group_col is None:
            categorical = [c for c in df.columns if c not in numeric_cols and df[c].nunique(dropna=True) <= 100]
            if categorical:
                group_col = categorical[0]

    # Top/bottom or grouped metric
    if metric and group_col and (wants_group or any(k in q for k in ["highest", "lowest", "top", "most", "least", "compare", "chart", "graph"])):
        grouped = df.groupby(group_col, dropna=False)[metric].sum().sort_values(ascending=False)
        if any(k in q for k in ["lowest", "least", "bottom", "smallest"]):
            grouped = grouped.sort_values(ascending=True)
        top_match = re.search(r"\btop\s+(\d+)\b", q)
        limit = min(int(top_match.group(1)), 30) if top_match else 10
        grouped = grouped.head(limit)
        result_df = grouped.reset_index()
        return {
            "kind": "grouped",
            "answer_title": f"{metric} grouped by {group_col}",
            "result": result_df.round(3).to_dict(orient="records"),
            "chart": {"type": "bar", "x": str(group_col), "y": str(metric), "data": result_df.to_dict(orient="records")},
            "note": f"Values are calculated by summing '{metric}' for each '{group_col}'."
        }

    # Sum/average/min/max of a numeric column
    if metric:
        if any(k in q for k in ["average", "mean", "avg"]):
            value = float(df[metric].mean())
            operation = "average"
        elif any(k in q for k in ["minimum", "minimum value", "lowest value", "smallest value", "min "]):
            value = float(df[metric].min())
            operation = "minimum"
        elif any(k in q for k in ["maximum", "maximum value", "highest value", "largest value", "max "]):
            value = float(df[metric].max())
            operation = "maximum"
        elif any(k in q for k in ["count", "how many", "number of"]):
            value = int(df[metric].count())
            operation = "non-empty count"
        else:
            value = float(df[metric].sum())
            operation = "total"
        return {
            "kind": "metric",
            "answer_title": f"{operation.title()} {metric}",
            "result": {"column": str(metric), "operation": operation, "value": round(value, 3)},
            "chart": None,
            "note": "The value was calculated directly from the dataset using pandas."
        }

    # If no operation could be safely inferred, return a useful profile and ask a specific question.
    profile = dataset_profile(df)
    return {
        "kind": "needs_clarification",
        "answer_title": "I need a more specific question",
        "result": {
            "available_columns": profile["column_names"],
            "numeric_columns": numeric_cols,
            "categorical_columns": [str(c) for c in df.columns if c not in numeric_cols],
            "suggestions": [
                "What is the total sales?",
                "Which category has the highest sales?",
                "Show the top 5 products by profit.",
                "Are there missing values or duplicate rows?",
                "Show correlation between numeric columns."
            ]
        },
        "chart": None,
        "note": "I did not guess a calculation because the question did not clearly identify a supported operation."
    }

# ---------- LLM helper ----------
def ask_llm(question, result, language_hint="Auto-detect"):
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        return (
            "LLM explanation is not enabled yet because GEMINI_API_KEY is missing. "
            "The dataset calculation above was still performed by Python/pandas. "
            "To enable multilingual AI explanations, add your Gemini API key to the .env file and restart the app."
        )
    try:
        from google import genai
        client = genai.Client(api_key=api_key)
        prompt = f"""
You are the explanation assistant inside a dataset analysis application.
Explain the provided computed result clearly and briefly for a beginner.
The result has already been calculated by Python/pandas. Do not change numbers, invent results, or claim you executed a calculation.
If the user's question is in Hindi, answer in Hindi. If in Punjabi, answer in Punjabi. If the user uses Romanized Hindi/Punjabi, you may answer in the same style. Otherwise answer in English.
Language preference: {language_hint}
User question: {question}
Computed result (JSON):
{json.dumps(result, ensure_ascii=False, default=str)[:12000]}
Rules:
- Treat computed result as the source of truth.
- Mention important caveats if relevant.
- If the result says clarification is needed, suggest one or two clearer questions.
- Do not provide code.
"""
        response = client.models.generate_content(
            model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
            contents=prompt
        )
        return (getattr(response, "text", None) or "").strip() or "The LLM did not return an explanation."
    except Exception as exc:
        return (
            "The pandas calculation succeeded, but the LLM explanation failed. "
            f"Check your API key, internet connection, and model setting. Technical detail: {type(exc).__name__}: {exc}"
        )

def load_uploaded_file(uploaded_file):
    name = uploaded_file.name.lower()
    if name.endswith(".csv"):
        try:
            return pd.read_csv(uploaded_file)
        except UnicodeDecodeError:
            uploaded_file.seek(0)
            return pd.read_csv(uploaded_file, encoding="latin-1")
    if name.endswith(".xlsx") or name.endswith(".xls"):
        return pd.read_excel(uploaded_file)
    raise ValueError("Please upload a CSV, XLSX, or XLS file.")

# ---------- Interface ----------
st.title("📊 AI-Powered Dataset Analysis Assistant")
st.caption("Upload a dataset, explore its quality, ask questions in English/Hindi/Punjabi, and view charts.")

with st.sidebar:
    st.header("1. Load your data")
    uploaded = st.file_uploader("Upload CSV or Excel", type=["csv", "xlsx", "xls"])
    sample_button = st.button("Use built-in sample dataset", use_container_width=True)
    st.divider()
    language_hint = st.selectbox("Preferred answer language", ["Auto-detect", "English", "Hindi", "Punjabi"])
    st.caption("AI explanations require a Gemini API key in your local .env file.")

if "df" not in st.session_state:
    st.session_state.df = None
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

if sample_button:
    sample_path = os.path.join(os.path.dirname(__file__), "sample_data", "superstore_sample.csv")
    st.session_state.df = pd.read_csv(sample_path)
    st.session_state.chat_history = []

if uploaded is not None:
    try:
        st.session_state.df = clean_column_names(load_uploaded_file(uploaded))
        st.session_state.chat_history = []
    except Exception as exc:
        st.error(f"Could not read this file: {exc}")

df = st.session_state.df

if df is None:
    st.info("Start by uploading a CSV/Excel file or click **Use built-in sample dataset**.")
    c1, c2, c3 = st.columns(3)
    c1.metric("Feature 1", "Data cleaning")
    c2.metric("Feature 2", "AI Q&A")
    c3.metric("Feature 3", "Charts & insights")
    st.markdown("### Example questions")
    st.markdown("- Which category has the highest sales?\n- Show total profit by region.\n- Are there missing values or duplicates?\n- sales da total kina hai? (Punjabi/Hinglish-style example)\n- ਸਭ ਤੋਂ ਵੱਧ ਵਿਕਰੀ ਕਿਸ ਸ਼੍ਰੇਣੀ ਵਿੱਚ ਹੈ? (Punjabi example)")
    st.stop()

df = clean_column_names(df)
st.success(f"Dataset loaded: {len(df):,} rows × {len(df.columns)} columns")

tab_overview, tab_chat, tab_clean, tab_chart = st.tabs(["Overview", "Ask the dataset", "Data quality", "Quick chart"])

with tab_overview:
    a, b, c = st.columns(3)
    a.metric("Rows", f"{df.shape[0]:,}")
    b.metric("Columns", f"{df.shape[1]:,}")
    c.metric("Duplicate rows", f"{int(df.duplicated().sum()):,}")
    st.subheader("Preview")
    st.dataframe(df.head(MAX_PREVIEW_ROWS), use_container_width=True)
    st.subheader("Column types")
    type_df = pd.DataFrame({"Column": df.columns.astype(str), "Data type": [str(x) for x in df.dtypes]})
    st.dataframe(type_df, use_container_width=True)
    st.subheader("Numeric summary")
    numeric = df.select_dtypes(include="number")
    if numeric.empty:
        st.write("No numeric columns were detected.")
    else:
        st.dataframe(numeric.describe().T.round(3), use_container_width=True)

with tab_chat:
    st.subheader("Ask questions in English, Hindi, or Punjabi")
    st.caption("The app calculates common answers with pandas first. The LLM explains the computed result; it should not invent numbers.")
    examples = [
        "Which category has the highest sales?",
        "Show the top 5 products by profit",
        "What is the average discount?",
        "Are there missing values or duplicate rows?",
        "sales da total kina hai?",
        "सबसे ज्यादा sales किस category की है?",
        "ਸਭ ਤੋਂ ਵੱਧ ਵਿਕਰੀ ਕਿਸ ਸ਼੍ਰੇਣੀ ਵਿੱਚ ਹੈ?"
    ]
    selected_example = st.selectbox("Try an example question", ["Choose an example..."] + examples)
    with st.form("question_form", clear_on_submit=True):
        question = st.text_input("Your question", value="" if selected_example == "Choose an example..." else selected_example, placeholder="e.g. Which region has the highest sales?")
        submitted = st.form_submit_button("Analyze question", type="primary")
    if submitted and question.strip():
        with st.spinner("Calculating with pandas and preparing the explanation..."):
            result = basic_analysis(df.copy(), question.strip())
            explanation = ask_llm(question.strip(), result, language_hint)
        st.markdown("### Result")
        st.write(f"**{result.get('answer_title', 'Analysis result')}**")
        st.json(result.get("result", {}))
        if result.get("note"):
            st.caption(result["note"])
        st.markdown("### Explanation")
        st.write(explanation)
        chart = result.get("chart")
        if chart and chart.get("type") == "bar":
            chart_df = pd.DataFrame(chart["data"])
            if chart.get("x") in chart_df.columns and chart.get("y") in chart_df.columns:
                fig = px.bar(chart_df, x=chart["x"], y=chart["y"], title=result.get("answer_title", "Chart"))
                st.plotly_chart(fig, use_container_width=True)
        elif chart and chart.get("type") == "correlation":
            corr = df[chart["columns"]].corr(numeric_only=True)
            fig = px.imshow(corr, text_auto=True, aspect="auto", title="Correlation heatmap")
            st.plotly_chart(fig, use_container_width=True)
        st.download_button(
            "Download this result as JSON",
            data=json.dumps({"question": question, "result": result, "explanation": explanation}, ensure_ascii=False, indent=2, default=str),
            file_name="dataset_analysis_result.json",
            mime="application/json"
        )
    st.markdown("#### Question ideas")
    st.markdown("- Which category has the highest sales?\n- Show the top 5 products by profit.\n- What is the average discount?\n- Find missing values and duplicates.\n- Show correlation between numeric columns.")

with tab_clean:
    st.subheader("Data quality report")
    missing = df.isna().sum().rename("Missing values").to_frame()
    missing["Missing %"] = (df.isna().mean() * 100).round(2)
    missing["Data type"] = df.dtypes.astype(str)
    st.dataframe(missing, use_container_width=True)
    st.write(f"**Duplicate rows:** {int(df.duplicated().sum())}")
    st.caption("This report does not change your original uploaded file. Cleaning actions should be reviewed before saving.")
    if st.button("Create a cleaned copy (remove duplicate rows and trim text)"):
        cleaned = df.drop_duplicates().copy()
        for col in cleaned.select_dtypes(include=["object"]).columns:
            cleaned[col] = cleaned[col].map(lambda x: x.strip() if isinstance(x, str) else x)
        csv_bytes = cleaned.to_csv(index=False).encode("utf-8")
        st.success(f"Cleaned copy created: {len(df) - len(cleaned)} duplicate row(s) removed.")
        st.download_button("Download cleaned CSV", data=csv_bytes, file_name="cleaned_dataset.csv", mime="text/csv")

with tab_chart:
    st.subheader("Create a quick chart")
    all_cols = list(df.columns)
    numeric_cols = list(df.select_dtypes(include="number").columns)
    if not numeric_cols:
        st.warning("This dataset has no numeric columns to chart.")
    else:
        x_col = st.selectbox("Group by (X-axis)", all_cols)
        y_col = st.selectbox("Numeric value (Y-axis)", numeric_cols)
        agg = st.selectbox("Calculation", ["Sum", "Average", "Count"])
        chart_limit = st.slider("Number of groups to show", 3, 30, 10)
        if st.button("Build chart"):
            working = df.copy()
            if agg == "Sum":
                chart_data = working.groupby(x_col, dropna=False)[y_col].sum().reset_index()
            elif agg == "Average":
                chart_data = working.groupby(x_col, dropna=False)[y_col].mean().reset_index()
            else:
                chart_data = working.groupby(x_col, dropna=False)[y_col].count().reset_index()
            chart_data = chart_data.sort_values(y_col, ascending=False).head(chart_limit)
            fig = px.bar(chart_data, x=x_col, y=y_col, title=f"{agg} of {y_col} by {x_col}")
            st.plotly_chart(fig, use_container_width=True)
            st.dataframe(chart_data, use_container_width=True)

st.divider()
st.caption("Student project prototype. Always verify important decisions against the original data.")
