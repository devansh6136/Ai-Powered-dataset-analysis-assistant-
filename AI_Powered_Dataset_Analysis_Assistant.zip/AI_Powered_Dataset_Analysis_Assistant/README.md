# AI-Powered Dataset Analysis Assistant

**Research/project title:** *An LLM-Powered Framework for Automated Dataset Analysis, Statistical Insights, and Natural Language Querying*

A beginner-friendly Streamlit web app for uploading CSV/Excel files, viewing dataset quality, calculating common statistics with Python/Pandas, building charts, and asking questions in English, Hindi, or Punjabi. A Gemini LLM explains calculated results in natural language.

## What this version does

- Upload `.csv`, `.xlsx`, or `.xls` files.
- Preview rows and column data types.
- Show numeric summaries, missing values, and duplicate rows.
- Calculate common supported questions with Pandas.
- Explain results using a Gemini LLM (API key required).
- Try English, Hindi, Punjabi, and some Romanized Hindi/Punjabi questions.
- Create a cleaned CSV copy by trimming text and removing duplicate rows.
- Create bar charts and correlation heatmaps.
- Download a question's result as JSON.

## Important honesty / scope note

This is a **working student-project prototype**, not a general-purpose autonomous data scientist. The calculation engine intentionally supports common question patterns (totals, averages, highest/lowest grouped values, top-N groups, dataset overview, missing values, duplicates, and correlation). If a question is ambiguous or unsupported, it asks for a clearer question rather than executing arbitrary code. Expand `basic_analysis()` in `app.py` to add more question types.

The LLM explains the computed result; it is not supposed to invent or calculate the result itself. Hindi/Punjabi understanding depends on the LLM and wording. Some Romanized Punjabi/Hindi prompts may need to be phrased more clearly.

## Project folder

```text
AI_Powered_Dataset_Analysis_Assistant/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── sample_data/
    └── superstore_sample.csv
```

## Easiest setup on Windows

### Step 1 — Install Python
1. Install Python 3.11 or 3.12 from the official Python website: https://www.python.org/downloads/
2. During installation, tick **Add Python to PATH**.
3. Open Command Prompt and check:
   ```bat
   python --version
   ```
   You should see Python 3.11.x or 3.12.x. If `python` does not work, try `py --version`.

### Step 2 — Extract the project
1. Download and extract `AI_Powered_Dataset_Analysis_Assistant.zip`.
2. Open the extracted folder.
3. Click the folder address bar in File Explorer, type `cmd`, and press Enter. Command Prompt should open inside the project folder.

### Step 3 — Create a virtual environment
Run these commands one at a time:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If `python` is not recognized, use `py` instead for the first command:
```bat
py -m venv .venv
```

Wait for package installation to finish. Internet is required for installation.

### Step 4 — Start the app without an API key
Run:
```bat
streamlit run app.py
```

A browser page should open. If it does not, copy the local address shown in the terminal (usually `http://localhost:8501`) into your browser.

Click **Use built-in sample dataset** to test the project. The pandas calculations, data-quality report, and charts work without an API key. AI explanations will show a message explaining that the key is missing.

To stop the app, click the Command Prompt window and press `Ctrl + C`.

## Enable the LLM (Gemini)

### Step 5 — Get a Gemini API key
1. Open Google AI Studio: https://aistudio.google.com/
2. Sign in and create an API key, following the site's current instructions.
3. Keep the key private. Do not paste it into your report, screenshots, or public GitHub repository.

Availability, quotas, billing, and model access depend on Google's current terms and your account.

### Step 6 — Create your `.env` file
1. In the project folder, make a copy of `.env.example`.
2. Rename the copy to exactly `.env` (not `.env.txt`).
3. Open `.env` in Notepad.
4. Replace `PASTE_YOUR_GEMINI_API_KEY_HERE` with your actual key:
   ```text
   GEMINI_API_KEY=your_real_key_here
   GEMINI_MODEL=gemini-2.5-flash
   ```
5. Save the file and restart the app:
   ```bat
   streamlit run app.py
   ```

If the model name is not available, check the current model names in Google AI Studio and update `GEMINI_MODEL` in `.env`. Never share your key with anyone.

## How to use the project

1. Open the app in the browser.
2. In the left sidebar, upload your CSV or Excel file, or click **Use built-in sample dataset**.
3. Visit **Overview** to see the rows, columns, types, and numeric summary.
4. Visit **Data quality** to see missing values and duplicates.
5. Visit **Ask the dataset** and type a question.
6. Read the calculated result and the LLM explanation.
7. If a chart is available, it will appear below the answer.
8. Use **Quick chart** to choose a group column, numeric column, and calculation.
9. Download a cleaned CSV copy or an individual result when needed.

## Example questions to try

- `Which category has the highest sales?`
- `Show the top 5 products by profit`
- `What is the average discount?`
- `What is the total sales?`
- `Are there missing values or duplicate rows?`
- `Show correlation between numeric columns`
- `सबसे ज्यादा sales किस category की है?`
- `What is the total sales?` (then choose Hindi as preferred answer language)
- `ਸਭ ਤੋਂ ਵੱਧ ਵਿਕਰੀ ਕਿਸ ਸ਼੍ਰੇਣੀ ਵਿੱਚ ਹੈ?`

Question support depends on column names and wording. If the app asks for clarification, first check the exact column names in Overview and ask a simpler question.

## Troubleshooting

### `'python' is not recognized`
Reinstall Python and select **Add Python to PATH**, or use `py` instead of `python`.

### `streamlit` is not recognized
Activate the environment again:
```bat
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

### Port 8501 is already in use
Run:
```bat
streamlit run app.py --server.port 8502
```
Then open the local address shown in the terminal.

### LLM explanation fails
- Confirm `.env` is in the same folder as `app.py`.
- Confirm the variable is spelled `GEMINI_API_KEY`.
- Check that the key is valid and has access to the selected model.
- Check internet connectivity and account quota.
- Update `GEMINI_MODEL` if Google has changed model availability.
- Restart Streamlit after editing `.env`.

### Excel file will not load
Close the Excel file if it is open, confirm it is `.xlsx` or `.xls`, and try saving it as `.xlsx` or `.csv`.

### The answer is not what I expected
This prototype supports common question patterns and relies on column names. Review the result against the original data. Do not use it as the sole basis for financial, medical, or other high-stakes decisions.

## Project architecture

```text
CSV / Excel upload
        |
        v
Pandas data loading and quality checks
        |
        v
Question from user (English / Hindi / Punjabi)
        |
        v
Supported-operation detection
        |
        v
Pandas calculates the result
        |
        +---------------------> Plotly chart (when supported)
        |
        v
Gemini LLM explains the computed result
        |
        v
Answer + chart + downloadable result
```

## How to explain the LLM part in a viva

> “The LLM is used as the natural-language explanation layer. The user asks a question in English, Hindi, or Punjabi. The application identifies a supported analysis, computes the numerical result with Pandas, and then sends the question and computed result to the LLM. The LLM explains the result in simple language. This design reduces the risk of the LLM inventing numerical answers because the calculations come from Python.”

## Research evaluation you can perform

Create a small set of questions whose correct answers you calculate manually or with Pandas. Record:
- Correctness of numerical answers.
- Whether the explanation matches the calculated result.
- Whether missing values and duplicate rows are identified correctly.
- Response time.
- Whether the answer follows the selected language.

For a fair comparison, compare the grounded workflow (Pandas result + LLM explanation) with answers from an LLM alone. Document the sample size and method; do not claim an accuracy percentage before running tests.

## Future improvements

- More flexible natural-language question parsing.
- Better Hindi/Punjabi and Romanized-language support.
- Filters by date/category/region.
- More chart types and automatic chart selection.
- Export a complete PDF/Excel report.
- Add automated tests and a larger benchmark dataset.
